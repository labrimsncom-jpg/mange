/**
 * /formulaireconfig — candidatures configurables
 * Types : libre | qcm | exacte
 */
const {
  SlashCommandBuilder, PermissionFlagsBits, MessageFlags, ChannelType,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder,
  ChannelSelectMenuBuilder, RoleSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle,
  EmbedBuilder,
} = require('discord.js');
const { getGuild, setGuild, bag, setBag, read, write } = require('./storage.js');
const { isAdmin } = require('./perms.js');
const { emb, C, configCard, DIV } = require('./design.js');
const { openBtn } = require('./pickers.js');
const { E, CFG } = require('./emojis.js');

const EPH = { flags: MessageFlags.Ephemeral };
const pending = new Map(); // userId -> { guildId, answers, step }

function formsMap(gid) {
  const m = bag('forms.json', gid);
  return typeof m === 'object' && !Array.isArray(m) ? m : {};
}
function setForms(gid, data) {
  setBag('forms.json', gid, data);
}

function canReview(member, c) {
  if (isAdmin(member)) return true;
  const roles = c.formReviewerRoleIds || [];
  if (!roles.length) return member.permissions.has(PermissionFlagsBits.ManageGuild);
  return roles.some((r) => member.roles.cache.has(r));
}

function typeLabel(t) {
  if (t === 'qcm') return 'QCM';
  if (t === 'exacte') return 'Réponse exacte';
  return 'Libre';
}

function questionsList(c) {
  const qs = c.formQuestions || [];
  if (!qs.length) return '_Aucune question — ajoute-en dans la config._';
  return qs
    .map((q, i) => `**${i + 1}.** ${q.label}\n> Type : \`${typeLabel(q.type)}\`${q.type === 'qcm' && q.options?.length ? ` · options : ${q.options.join(', ')}` : ''}${q.type === 'exacte' && q.exact ? ` · attendu : \`${q.exact}\`` : ''}`)
    .join('\n\n');
}

function cfgEmbed(gid) {
  const c = getGuild(gid);
  return configCard(
    `${CFG.form} Formulaire config`,
    [
      '### Candidatures ManageX',
      '',
      '• Questions : **libre** / **QCM** / **réponse exacte**',
      '• Les candidatures arrivent dans un salon',
      '• Accepté → rôle + MP · Refusé → raison + détails staff',
    ].join('\n'),
    [
      { name: '📥 Salon candidatures', value: c.formChannelId ? `<#${c.formChannelId}>` : '`non défini`', inline: true },
      { name: '🎭 Rôle si accepté', value: c.formAcceptRoleId ? `<@&${c.formAcceptRoleId}>` : '`aucun`', inline: true },
      { name: '🛡️ Rôles qui acceptent/refusent', value: (c.formReviewerRoleIds || []).map((id) => `<@&${id}>`).join(' ') || '`Admin / Gérer serveur`' },
      { name: '📋 Titre', value: c.formTitle || 'Candidature', inline: true },
      { name: 'État', value: c.formClosed ? '🔒 **Fermées**' : '🔓 **Ouvertes**', inline: true },
      { name: `❓ Questions (${(c.formQuestions || []).length})`, value: questionsList(c).slice(0, 1000) },
    ],
    C.violet || C.primary
  );
}

function panelEmbed(guild) {
  const c = getGuild(guild.id);
  const closed = !!c.formClosed;
  const n = (c.formQuestions || []).length;
  const color = closed ? C.danger : (C.violet || C.primary);
  const title = closed
    ? `🔒 ${c.formTitle || 'Candidature'} — FERMÉES`
    : `📝 ${c.formTitle || 'Candidature'}`;

  if (closed) {
    return new EmbedBuilder()
      .setColor(color)
      .setTitle(title)
      .setDescription(
        [
          '### 🔒 Candidatures fermées',
          '',
          'Le recrutement est **temporairement suspendu**.',
          'Le formulaire ne peut plus être rempli pour le moment.',
          '',
          '```',
          '  ╔══════════════════════╗',
          '  ║   🔒  VERROUILLÉ     ║',
          '  ║  Candidatures OFF   ║',
          '  ╚══════════════════════╝',
          '```',
          '',
          '_Un membre autorisé peut **rouvrir** les candidatures._',
        ].join('\n')
      )
      .setThumbnail(guild.iconURL({ size: 128 }))
      .setFooter({ text: 'ManageX · Formulaire fermé' })
      .setTimestamp();
  }

  return new EmbedBuilder()
    .setColor(color)
    .setTitle(title)
    .setDescription(
      [
        '### 📝 Postuler maintenant',
        '',
        'Les candidatures sont **ouvertes**.',
        `**${n}** question(s) à compléter.`,
        '',
        '1️⃣ Clique sur **Remplir le formulaire**',
        '2️⃣ Réponds à chaque question',
        '3️⃣ Le staff reçoit ta candidature',
        '',
        '_Réponds honnêtement. Les réponses exactes sont vérifiées._',
      ].join('\n')
    )
    .setThumbnail(guild.iconURL({ size: 128 }))
    .setFooter({ text: 'ManageX · Formulaire ouvert' })
    .setTimestamp();
}

function panelComponents(guild) {
  const c = getGuild(guild.id);
  const closed = !!c.formClosed;
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('mx_form_start')
        .setLabel(closed ? 'Candidatures fermées' : 'Remplir le formulaire')
        .setStyle(closed ? ButtonStyle.Secondary : ButtonStyle.Primary)
        .setEmoji(closed ? '🔒' : '📝')
        .setDisabled(closed),
      new ButtonBuilder()
        .setCustomId(closed ? 'mx_form_open' : 'mx_form_close')
        .setLabel(closed ? 'Ouvrir les candidatures' : 'Fermer les candidatures')
        .setStyle(closed ? ButtonStyle.Success : ButtonStyle.Danger)
        .setEmoji(closed ? '🔓' : '🔒'),
    ),
  ];
}

async function refreshFormPanel(guild) {
  const c = getGuild(guild.id);
  if (!c.formPanelChannelId || !c.formPanelMessageId) return;
  const chn = await guild.channels.fetch(c.formPanelChannelId).catch(() => null);
  const msg = chn && await chn.messages.fetch(c.formPanelMessageId).catch(() => null);
  if (!msg) return;
  await msg.edit({
    embeds: [panelEmbed(guild)],
    components: panelComponents(guild),
  }).catch(() => null);
}

const command = {
  data: new SlashCommandBuilder()
    .setName('formulaireconfig')
    .setDescription('ManageX — configurer le formulaire de candidature')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  async execute(i) {
    if (!isAdmin(i.member)) {
      return i.reply({ content: '❌ Administrateur requis.', ...EPH });
    }
    await i.reply({
      embeds: [cfgEmbed(i.guild.id)],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('mx_form_panel').setLabel('Poster le panel').setStyle(ButtonStyle.Success).setEmoji('📨'),
          new ButtonBuilder().setCustomId('mx_form_addq').setLabel('Ajouter question').setStyle(ButtonStyle.Primary).setEmoji('➕'),
          new ButtonBuilder().setCustomId('mx_form_delq').setLabel('Supprimer').setStyle(ButtonStyle.Danger).setEmoji('🗑️'),
          new ButtonBuilder().setCustomId('mx_form_order').setLabel('Ordre').setStyle(ButtonStyle.Secondary).setEmoji('↕️'),
          new ButtonBuilder().setCustomId('mx_form_pagesize').setLabel('Par page').setStyle(ButtonStyle.Secondary).setEmoji('📄'),
        ),
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('mx_form_refresh').setLabel('Actualiser').setStyle(ButtonStyle.Secondary).setEmoji('🔄'),
          openBtn('ch', 'form_ch', '📥 Salon candidatures'),
          openBtn('role', 'form_accept', '🎭 Rôle accepté'),
          openBtn('role', 'form_review', '🛡️ Reviewers'),
        ),
        
      ],
      ...EPH,
    });
  },
};


async function startForm(i) {
  const c = getGuild(i.guild.id);
  const qs = c.formQuestions || [];
  if (!qs.length) {
    await i.reply({ content: '❌ Aucune question configurée.', ...EPH });
    return;
  }
  if (!c.formChannelId) {
    await i.reply({ content: '❌ Salon candidatures non configuré.', ...EPH });
    return;
  }
  const pageSize = Math.min(5, Math.max(1, Number(c.formPageSize) || 3));
  pending.set(i.user.id, {
    guildId: i.guild.id,
    answers: {}, // qId -> { q, a, ok }
    page: 0,
    pageSize,
  });
  await showFormPage(i, true);
}

function formPages(qs, pageSize) {
  const pages = [];
  for (let i = 0; i < qs.length; i += pageSize) pages.push(qs.slice(i, i + pageSize));
  return pages.length ? pages : [[]];
}

function pageEmbed(st, qs) {
  const pages = formPages(qs, st.pageSize);
  const page = st.page;
  const chunk = pages[page] || [];
  const lines = chunk.map((q, idx) => {
    const n = page * st.pageSize + idx + 1;
    const filled = st.answers[q.id] ? '✅' : '⬜';
    return `${filled} **${n}.** ${q.label}\n> \`${typeLabel(q.type)}\``;
  });
  const allFilled = chunk.every((q) => st.answers[q.id]);
  return emb(
    `📝 Fiche ${page + 1}/${pages.length}`,
    C.violet || C.primary
  ).setDescription(
    [
      '### Réponds à cette page',
      '',
      ...lines,
      '',
      allFilled
        ? '_Page complète — tu peux passer à la suivante._'
        : '_Clique **Remplir cette page** pour répondre._',
    ].join('\n')
  ).setFooter({ text: `ManageX · Formulaire · page ${page + 1}/${pages.length}` });
}

function pageNav(st, qs) {
  const pages = formPages(qs, st.pageSize);
  const page = st.page;
  const chunk = pages[page] || [];
  const allFilled = chunk.every((q) => st.answers[q.id]);
  const isLast = page >= pages.length - 1;
  const rows = [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('mx_form_page_fill')
        .setLabel('Remplir cette page')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('✏️'),
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('mx_form_page_prev')
        .setLabel('Précédente')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('◀️')
        .setDisabled(page <= 0),
      new ButtonBuilder()
        .setCustomId('mx_form_page_next')
        .setLabel(isLast ? 'Terminer' : 'Suivante')
        .setStyle(isLast ? ButtonStyle.Success : ButtonStyle.Primary)
        .setEmoji(isLast ? '✅' : '▶️')
        .setDisabled(isLast ? !Object.keys(st.answers).length : false),
    ),
  ];
  // QCM on this page → selects
  const qcms = chunk.filter((q) => q.type === 'qcm');
  for (const q of qcms.slice(0, 3)) {
    const opts = (q.options || []).slice(0, 25).map((o, idx) => ({
      label: String(o).slice(0, 100),
      value: `${q.id}::${idx}`,
    }));
    if (opts.length) {
      rows.push(
        new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId(`mx_form_page_qcm_${q.id}`)
            .setPlaceholder(`QCM : ${q.label}`.slice(0, 100))
            .addOptions(opts),
        ),
      );
    }
  }
  return rows.slice(0, 5);
}

async function showFormPage(i, first) {
  const st = pending.get(i.user.id);
  if (!st) return;
  const qs = getGuild(st.guildId).formQuestions || [];
  const payload = {
    embeds: [pageEmbed(st, qs)],
    components: pageNav(st, qs),
    ...EPH,
  };
  if (first && !i.replied && !i.deferred) await i.reply(payload);
  else if (i.isMessageComponent() && !i.isModalSubmit?.()) {
    try {
      await i.update(payload);
    } catch {
      await i.followUp(payload).catch(() => null);
    }
  } else {
    await i.followUp(payload).catch(() => i.reply(payload).catch(() => null));
  }
}

async function askStep() {
  /* legacy no-op — pages */
}


const FORM_VIEW_PER = 20;

function formViewPayload(entry, page, c) {
  const answers = Array.isArray(entry.answers) ? entry.answers : [];
  const maxPage = Math.max(0, Math.ceil(answers.length / FORM_VIEW_PER) - 1);
  page = Math.max(0, Math.min(maxPage, page));
  const slice = answers.slice(page * FORM_VIEW_PER, page * FORM_VIEW_PER + FORM_VIEW_PER);
  const isLast = page >= maxPage;
  const fields = slice.map((a, i) => {
    const n = page * FORM_VIEW_PER + i + 1;
    const mark = a.ok === false ? ' ⚠️' : a.ok === true ? ' ✅' : '';
    return {
      name: `${n}. ${String(a.q || 'Question').slice(0, 80)}${mark}`,
      value: String(a.a || '—').slice(0, 1020) || '—',
    };
  });
  const embed = emb(
    `👁️ Candidature ${entry.id} · page ${page + 1}/${maxPage + 1}`,
    C.info
  )
    .setDescription(
      [
        `**Candidat** · <@${entry.userId}> (\`${entry.userId}\`)`,
        `**Statut** · ${entry.status === 'pending' ? '⏳ En attente' : entry.status}`,
        `**${answers.length}** réponse(s)`,
      ].join('\n')
    )
    .addFields(fields.length ? fields : [{ name: '—', value: '_Aucune réponse_' }])
    .setFooter({ text: `ManageX · ${page + 1}/${maxPage + 1}` });

  const nav = [
    new ButtonBuilder()
      .setCustomId(`mx_form_view_${entry.id}_${page - 1}`)
      .setLabel('Précédente')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('◀️')
      .setDisabled(page <= 0),
    new ButtonBuilder()
      .setCustomId(`mx_form_view_${entry.id}_${page + 1}`)
      .setLabel('Suivante')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('▶️')
      .setDisabled(page >= maxPage),
  ];
  const rows = [new ActionRowBuilder().addComponents(nav)];
  if (isLast && entry.status === 'pending') {
    rows.push(new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`mx_form_ok_${entry.id}`).setLabel('Accepter').setStyle(ButtonStyle.Success).setEmoji('✅'),
      new ButtonBuilder().setCustomId(`mx_form_no_${entry.id}`).setLabel('Refuser').setStyle(ButtonStyle.Danger).setEmoji('❌'),
    ));
  }
  return { embeds: [embed], components: rows };
}

async function submitApplication(i, st) {
  pending.delete(i.user.id);
  const guild = i.guild || await i.client.guilds.fetch(st.guildId).catch(() => null);
  if (!guild) return;
  const c = getGuild(guild.id);
  const id = `F${Date.now().toString(36).toUpperCase()}`;
  const entry = {
    id,
    userId: i.user.id,
    tag: i.user.tag,
    answers: Array.isArray(st.answers) ? st.answers : Object.values(st.answers || {}),
    status: 'pending',
    at: Date.now(),
    remark: null,
    refuseReason: null,
    details: null,
    reviewedBy: null,
  };
  const map = formsMap(guild.id);
  map[id] = entry;
  setForms(guild.id, map);

  const ch = await guild.channels.fetch(c.formChannelId).catch(() => null);
  const answers = Array.isArray(entry.answers) ? entry.answers : [];
  const msg = await ch?.send({
    embeds: [
      emb(`📥 Candidature · ${c.formTitle || 'Formulaire'}`, C.info)
        .setAuthor({ name: i.user.tag, iconURL: i.user.displayAvatarURL({ size: 64 }) })
        .setDescription(
          [
            `**Candidat** · ${i.user} (\`${i.user.id}\`)`,
            `**ID** · \`${id}\``,
            `**Réponses** · **${answers.length}** question(s)`,
            '',
            'Clique sur **Voir** pour parcourir les réponses (20 / page), puis **Accepter** ou **Refuser**.',
          ].join('\n')
        )
        .addFields(
          { name: 'Statut', value: '⏳ En attente', inline: true },
          { name: 'Date', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
        )
        .setFooter({ text: 'ManageX · Formulaire' }),
    ],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`mx_form_view_${id}_0`).setLabel('Voir les réponses').setStyle(ButtonStyle.Primary).setEmoji('👁️'),
        new ButtonBuilder().setCustomId(`mx_form_ok_${id}`).setLabel('Accepter').setStyle(ButtonStyle.Success).setEmoji('✅'),
        new ButtonBuilder().setCustomId(`mx_form_no_${id}`).setLabel('Refuser').setStyle(ButtonStyle.Danger).setEmoji('❌'),
      ),
    ],
  }).catch(() => null);

  if (msg) {
    entry.messageId = msg.id;
    entry.channelId = msg.channel.id;
    map[id] = entry;
    setForms(guild.id, map);
  }

  const done = {
    embeds: [
      emb('✅ Candidature envoyée', C.success)
        .setDescription('Le staff a reçu ta candidature. Tu seras contacté en MP après décision.'),
    ],
    components: [],
    ...EPH,
  };
  if (i.isModalSubmit()) await i.reply(done).catch(() => i.followUp(done).catch(() => null));
  else if (i.isMessageComponent()) await i.update(done).catch(() => null);
  else await i.reply(done).catch(() => null);
}

async function handle(i) {
  const id = i.customId || '';
  if (!id.startsWith('mx_form_')) return false;
  const gid = i.guild?.id;
  const c = gid ? getGuild(gid) : {};

  if (id === 'mx_form_refresh') {
    if (!isAdmin(i.member)) return true;
    await i.update({ embeds: [cfgEmbed(gid)], components: i.message.components });
    return true;
  }
  if (id === 'mx_form_ch') {
    if (!isAdmin(i.member)) return true;
    setGuild(gid, { formChannelId: i.values[0] || null });
    await i.reply({ content: i.values[0] ? `✅ Salon candidatures : <#${i.values[0]}>` : '✅ Salon retiré.', ...EPH });
    return true;
  }
  if (id === 'mx_form_accept_role') {
    if (!isAdmin(i.member)) return true;
    setGuild(gid, { formAcceptRoleId: i.values[0] || null });
    await i.reply({ content: i.values[0] ? `✅ Rôle accepté : <@&${i.values[0]}>` : '✅ Rôle retiré.', ...EPH });
    return true;
  }
  if (id === 'mx_form_reviewers') {
    if (!isAdmin(i.member)) return true;
    setGuild(gid, { formReviewerRoleIds: i.values || [] });
    await i.reply({ content: `✅ Reviewers : ${(i.values || []).map((r) => `<@&${r}>`).join(' ') || 'Admin'}`, ...EPH });
    return true;
  }
  if (id === 'mx_form_panel') {
    if (!isAdmin(i.member)) return true;
    await i.deferReply({ ...EPH });
    try {
      if (!i.channel || !i.channel.send) {
        await i.editReply({ content: '❌ Impossible d’envoyer dans ce salon.' });
        return true;
      }
      const msg = await i.channel.send({
        embeds: [panelEmbed(i.guild)],
        components: panelComponents(i.guild),
      });
      setGuild(gid, { formPanelChannelId: i.channel.id, formPanelMessageId: msg.id });
      await i.editReply({ content: `✅ Panel posté → ${msg.url}` });
    } catch (e) {
      console.error('[form] panel', e);
      await i.editReply({ content: `❌ Échec post panel : \`${String(e.message || e).slice(0, 180)}\`` }).catch(() => null);
    }
    return true;
  }
  if (id === 'mx_form_addq') {
    if (!isAdmin(i.member)) return true;
    const modal = new ModalBuilder().setCustomId('mx_modal_form_addq').setTitle('Nouvelle question');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('label').setLabel('Intitulé de la question').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100),
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('type').setLabel('Type : libre / qcm / exacte').setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder('libre'),
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('options').setLabel('Options QCM (séparées par |)').setStyle(TextInputStyle.Paragraph).setRequired(false).setPlaceholder('Oui|Non|Peut-être'),
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('exact').setLabel('Réponse exacte attendue (si type exacte)').setStyle(TextInputStyle.Short).setRequired(false),
      ),
    );
    await i.showModal(modal);
    return true;
  }

  if (id === 'mx_form_delq' || id.startsWith('mx_form_delq_page_')) {
    if (!isAdmin(i.member)) return true;
    const qs = c.formQuestions || [];
    if (!qs.length) {
      await i.reply({ content: 'Aucune question à supprimer.', ...EPH });
      return true;
    }
    const PAGE = 10; // 10 visibles par page (menu max 25, on reste lisible)
    let page = 0;
    if (id.startsWith('mx_form_delq_page_')) {
      page = parseInt(id.replace('mx_form_delq_page_', ''), 10) || 0;
    }
    const maxPage = Math.max(0, Math.ceil(qs.length / PAGE) - 1);
    page = Math.max(0, Math.min(maxPage, page));
    const slice = qs.slice(page * PAGE, page * PAGE + PAGE);
    const listText = qs
      .map((q, idx) => {
        const mark = idx >= page * PAGE && idx < page * PAGE + PAGE ? '▸' : ' ';
        return `\`${mark} ${String(idx + 1).padStart(2, '0')}.\` ${q.label.slice(0, 80)} · _${typeLabel(q.type)}_`;
      })
      .join('\n')
      .slice(0, 3500);

    const payload = {
      embeds: [
        emb('🗑️ Supprimer une question', C.danger)
          .setDescription(
            [
              `**${qs.length}** question(s) · page **${page + 1}/${maxPage + 1}**`,
              '',
              listText,
              '',
              '_Choisis ci-dessous la question à **supprimer** (page actuelle)._',
            ].join('\n')
          ),
      ],
      components: [
        new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('mx_form_delq_pick')
            .setPlaceholder(`Page ${page + 1} — question à supprimer…`)
            .addOptions(
              slice.map((q, i) => ({
                label: `${page * PAGE + i + 1}. ${q.label}`.slice(0, 100),
                value: q.id,
                description: typeLabel(q.type),
              }))
            ),
        ),
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`mx_form_delq_page_${page - 1}`)
            .setLabel('Précédent')
            .setStyle(ButtonStyle.Secondary)
            .setEmoji('◀️')
            .setDisabled(page <= 0),
          new ButtonBuilder()
            .setCustomId(`mx_form_delq_page_${page + 1}`)
            .setLabel('Suivant')
            .setStyle(ButtonStyle.Secondary)
            .setEmoji('▶️')
            .setDisabled(page >= maxPage),
        ),
      ],
      ...EPH,
    };
    if (id === 'mx_form_delq') await i.reply(payload);
    else await i.update(payload);
    return true;
  }

  if (id === 'mx_form_delq_pick') {
    if (!isAdmin(i.member)) return true;
    const qs = c.formQuestions || [];
    const removed = qs.find((q) => q.id === i.values[0]);
    const next = qs.filter((q) => q.id !== i.values[0]);
    setGuild(gid, { formQuestions: next });
    await i.update({
      content: null,
      embeds: [
        emb('✅ Question supprimée', C.success)
          .setDescription(
            [
              removed ? `Supprimée : **${removed.label}**` : 'Question retirée.',
              `Il reste **${next.length}** question(s).`,
              '',
              next.length
                ? next.map((q, n) => `**${n + 1}.** ${q.label}`).join('\n').slice(0, 3500)
                : '_Plus aucune question._',
            ].join('\n')
          ),
      ],
      components: next.length
        ? [
            new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId('mx_form_delq')
                .setLabel('Supprimer une autre')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('🗑️'),
            ),
          ]
        : [],
    });
    return true;
  }

  if (id === 'mx_form_pagesize') {
    if (!isAdmin(i.member)) return true;
    const modal = new ModalBuilder().setCustomId('mx_modal_form_pagesize').setTitle('Questions par page');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('n').setLabel('Nombre (1 à 5)').setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder('3')
      ),
    );
    await i.showModal(modal);
    return true;
  }
  if (id === 'mx_form_order') {
    if (!isAdmin(i.member)) return true;
    const qs = c.formQuestions || [];
    if (qs.length < 2) {
      await i.reply({ content: 'Il faut **au moins 2 questions** pour changer l’ordre.', ...EPH });
      return true;
    }
    await i.reply({
      embeds: [
        emb('↕️ Ordre des questions', C.info)
          .setDescription(
            [
              '**1.** Choisis la question à déplacer',
              '**2.** Choisis sa **nouvelle position** (1 = première)',
              '',
              questionsList(c),
            ].join('\n').slice(0, 4000)
          ),
      ],
      components: [
        new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('mx_form_order_pick')
            .setPlaceholder('Question à déplacer…')
            .addOptions(
              qs.slice(0, 25).map((q, idx) => ({
                label: `${idx + 1}. ${q.label}`.slice(0, 100),
                value: q.id,
                description: typeLabel(q.type),
              }))
            ),
        ),
      ],
      ...EPH,
    });
    return true;
  }

  if (id === 'mx_form_order_pick') {
    if (!isAdmin(i.member)) return true;
    const qs = c.formQuestions || [];
    const qid = i.values[0];
    const from = qs.findIndex((q) => q.id === qid);
    if (from < 0) {
      await i.update({ content: 'Question introuvable.', embeds: [], components: [] });
      return true;
    }
    const positions = qs.map((_, idx) => ({
      label: `Position ${idx + 1}`,
      value: String(idx),
      description: idx === from ? 'Position actuelle' : `Actuellement : ${(qs[idx].label || '').slice(0, 40)}`,
      default: idx === from,
    }));
    await i.update({
      content: `Question **${from + 1}** sélectionnée. Nouvelle position :`,
      embeds: [],
      components: [
        new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId(`mx_form_order_to_${qid}`)
            .setPlaceholder('Nouvelle position…')
            .addOptions(positions.slice(0, 25)),
        ),
      ],
    });
    return true;
  }

  {
    const mTo = id.match(/^mx_form_order_to_(.+)$/);
    if (mTo) {
      if (!isAdmin(i.member)) return true;
      const qid = mTo[1];
      const to = parseInt(i.values[0], 10);
      const qs = [...(c.formQuestions || [])];
      const from = qs.findIndex((q) => q.id === qid);
      if (from < 0 || !Number.isFinite(to) || to < 0 || to >= qs.length) {
        await i.update({ content: 'Déplacement impossible.', components: [], embeds: [] });
        return true;
      }
      if (from === to) {
        await i.update({ content: 'Déjà à cette position.', components: [], embeds: [] });
        return true;
      }
      const [item] = qs.splice(from, 1);
      qs.splice(to, 0, item);
      setGuild(gid, { formQuestions: qs });
      await i.update({
        content: null,
        embeds: [
          emb('✅ Ordre mis à jour', C.success)
            .setDescription(questionsList(getGuild(gid)).slice(0, 4000)),
        ],
        components: [],
      });
      return true;
    }
  }


  if (id === 'mx_form_start') {
    if (getGuild(gid).formClosed) {
      await i.reply({ content: '🔒 Les candidatures sont **fermées**.', ...EPH });
      return true;
    }
    await startForm(i);
    return true;
  }

  if (id === 'mx_form_page_prev') {
    const st = pending.get(i.user.id);
    if (!st) { await i.reply({ content: 'Session expirée.', ...EPH }); return true; }
    st.page = Math.max(0, st.page - 1);
    pending.set(i.user.id, st);
    await showFormPage(i, false);
    return true;
  }
  if (id === 'mx_form_page_next') {
    const st = pending.get(i.user.id);
    if (!st) { await i.reply({ content: 'Session expirée.', ...EPH }); return true; }
    const qs = getGuild(st.guildId).formQuestions || [];
    const pages = formPages(qs, st.pageSize);
    const chunk = pages[st.page] || [];
    const missing = chunk.filter((q) => !st.answers[q.id]);
    if (missing.length) {
      await i.reply({ content: `❌ Réponds d’abord à : **${missing.map((q) => q.label).join(', ')}**`, ...EPH });
      return true;
    }
    if (st.page >= pages.length - 1) {
      const st2 = { ...st, answers: Object.values(st.answers) };
      await submitApplication(i, st2);
      return true;
    }
    st.page += 1;
    pending.set(i.user.id, st);
    await showFormPage(i, false);
    return true;
  }
  if (id === 'mx_form_page_fill') {
    const st = pending.get(i.user.id);
    if (!st) { await i.reply({ content: 'Session expirée.', ...EPH }); return true; }
    const qs = getGuild(st.guildId).formQuestions || [];
    const pages = formPages(qs, st.pageSize);
    const chunk = (pages[st.page] || []).filter((q) => q.type !== 'qcm');
    if (!chunk.length) {
      await i.reply({ content: 'Utilise les menus **QCM** de cette page, ou passe à la suivante.', ...EPH });
      return true;
    }
    const modal = new ModalBuilder().setCustomId('mx_modal_form_page').setTitle(`Fiche ${st.page + 1}`.slice(0, 45));
    for (const q of chunk.slice(0, 5)) {
      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId(`a_${q.id}`)
            .setLabel(q.label.slice(0, 45) || 'Réponse')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setMaxLength(1000)
            .setValue((st.answers[q.id]?.a || '').slice(0, 1000)),
        ),
      );
    }
    await i.showModal(modal);
    return true;
  }
  if (id.startsWith('mx_form_page_qcm_')) {
    const st = pending.get(i.user.id);
    if (!st) { await i.reply({ content: 'Session expirée.', ...EPH }); return true; }
    const raw = i.values[0] || '';
    const [qid, idxS] = raw.split('::');
    const qs = getGuild(st.guildId).formQuestions || [];
    const q = qs.find((x) => x.id === qid);
    const opt = q?.options?.[parseInt(idxS, 10)];
    st.answers[qid] = { q: q?.label || qid, a: String(opt ?? raw), ok: null };
    pending.set(i.user.id, st);
    await showFormPage(i, false);
    return true;
  }


  if (id === 'mx_form_close' || id === 'mx_form_open') {
    if (!canReview(i.member, c)) {
      await i.reply({ content: '❌ Seuls les rôles autorisés (reviewers) peuvent ouvrir / fermer les candidatures.', ...EPH });
      return true;
    }
    const closing = id === 'mx_form_close';
    setGuild(gid, { formClosed: closing });
    await refreshFormPanel(i.guild);
    await i.reply({
      embeds: [
        emb(closing ? '🔒 Candidatures fermées' : '🔓 Candidatures ouvertes', closing ? C.danger : C.success)
          .setDescription(
            closing
              ? 'Le panel est passé en **rouge** avec un cadenas. Plus personne ne peut postuler.'
              : 'Le panel est **rouvert**. Les candidats peuvent à nouveau remplir le formulaire.'
          ),
      ],
      ...EPH,
    });
    return true;
  }
  if (id === 'mx_form_ans_qcm') {
    const st = pending.get(i.user.id);
    if (!st) {
      await i.reply({ content: 'Session expirée. Recommence.', ...EPH });
      return true;
    }
    const qs = getGuild(st.guildId).formQuestions || [];
    const q = qs[st.step];
    const optIdx = parseInt(i.values[0], 10);
    const answer = q?.options?.[optIdx] ?? i.values[0];
    st.answers.push({ q: q?.label, a: String(answer), ok: null });
    st.step++;
    pending.set(i.user.id, st);
    await askStep(i, false);
    return true;
  }


  // Voir réponses (20 / page)
  if (id.startsWith('mx_form_view_')) {
    const rest = id.slice('mx_form_view_'.length);
    const lastUnd = rest.lastIndexOf('_');
    const fid = lastUnd >= 0 ? rest.slice(0, lastUnd) : rest;
    const page = lastUnd >= 0 ? (parseInt(rest.slice(lastUnd + 1), 10) || 0) : 0;
    if (!canReview(i.member, c)) {
      await i.reply({ content: '❌ Reviewer uniquement.', ...EPH });
      return true;
    }
    const e = formsMap(gid)[fid];
    if (!e) {
      await i.reply({ content: 'Candidature introuvable.', ...EPH });
      return true;
    }
    const payload = formViewPayload(e, page, c);
    try {
      if (i.isMessageComponent() && i.message) {
        await i.update(payload);
      } else {
        await i.reply({ ...payload, ...EPH });
      }
    } catch {
      await i.reply({ ...payload, ...EPH }).catch(() =>
        i.followUp({ ...payload, ...EPH }).catch(() => null)
      );
    }
    return true;
  }

  // Accept / refuse / details
  const mOk = id.match(/^mx_form_ok_(.+)$/);
  const mNo = id.match(/^mx_form_no_(.+)$/);
  const mDet = id.match(/^mx_form_det_(.+)$/);

  if (mOk) {
    if (!canReview(i.member, c)) {
      await i.reply({ content: '❌ Tu ne peux pas traiter les candidatures.', ...EPH });
      return true;
    }
    const fid = mOk[1];
    const modal = new ModalBuilder().setCustomId(`mx_modal_form_ok_${fid}`).setTitle('Accepter la candidature');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('remark')
          .setLabel('Remarque pour le candidat (obligatoire)')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(1000),
      ),
    );
    await i.showModal(modal);
    return true;
  }
  if (mNo) {
    if (!canReview(i.member, c)) {
      await i.reply({ content: '❌ Tu ne peux pas traiter les candidatures.', ...EPH });
      return true;
    }
    const fid = mNo[1];
    const modal = new ModalBuilder().setCustomId(`mx_modal_form_no_${fid}`).setTitle('Refuser la candidature');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('reason')
          .setLabel('Raison du refus (visible)')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(200),
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('details')
          .setLabel('Détails complets (obligatoire)')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(1500),
      ),
    );
    await i.showModal(modal);
    return true;
  }
  if (mDet) {
    const fid = mDet[1];
    const map = formsMap(gid);
    const e = map[fid];
    if (!e?.details) {
      await i.reply({ content: 'Aucun détail.', ...EPH });
      return true;
    }
    await i.reply({
      embeds: [
        emb('📄 Détails du refus', C.danger)
          .setDescription(e.details.slice(0, 4000))
          .addFields(
            { name: 'Raison', value: e.refuseReason || '—' },
            { name: 'Par', value: e.reviewedBy ? `<@${e.reviewedBy}>` : '—' },
          ),
      ],
      ...EPH,
    });
    return true;
  }

  return false;
}

async function handleModal(i) {
  const id = i.customId || '';
  if (!id.startsWith('mx_modal_form') && !id.startsWith('mx_modal_form_')) return false;

  if (id === 'mx_modal_form_addq') {
    if (!isAdmin(i.member)) {
      await i.reply({ content: '❌', ...EPH });
      return true;
    }
    const label = i.fields.getTextInputValue('label').trim();
    let type = (i.fields.getTextInputValue('type') || 'libre').trim().toLowerCase();
    if (!['libre', 'qcm', 'exacte'].includes(type)) type = 'libre';
    const optionsRaw = i.fields.getTextInputValue('options') || '';
    const options = optionsRaw.split('|').map((s) => s.trim()).filter(Boolean).slice(0, 25);
    const exact = (i.fields.getTextInputValue('exact') || '').trim() || null;
    const qs = [...(getGuild(i.guild.id).formQuestions || [])];
    qs.push({
      id: `q${Date.now().toString(36)}`,
      label,
      type,
      options: type === 'qcm' ? options : [],
      exact: type === 'exacte' ? exact : null,
    });
    setGuild(i.guild.id, { formQuestions: qs });
    await i.reply({ content: `✅ Question ajoutée (**${typeLabel(type)}**) : ${label}`, ...EPH });
    return true;
  }

  if (i.customId === 'mx_modal_form_pagesize' || id === 'mx_modal_form_pagesize') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    let n = parseInt(i.fields.getTextInputValue('n'), 10) || 3;
    n = Math.min(5, Math.max(1, n));
    setGuild(i.guild.id, { formPageSize: n });
    await i.reply({ content: `✅ **${n}** question(s) par page (fiche).`, ...EPH });
    return true;
  }

  if (i.customId === 'mx_modal_form_page' || id === 'mx_modal_form_page') {
    const st = pending.get(i.user.id);
    if (!st) {
      await i.reply({ content: 'Session expirée.', ...EPH });
      return true;
    }
    const qs = getGuild(st.guildId).formQuestions || [];
    const pages = formPages(qs, st.pageSize);
    const chunk = (pages[st.page] || []).filter((q) => q.type !== 'qcm');
    for (const q of chunk.slice(0, 5)) {
      let answer = '';
      try { answer = i.fields.getTextInputValue(`a_${q.id}`).trim(); } catch { continue; }
      let ok = null;
      if (q.type === 'exacte' && q.exact) {
        ok = answer.toLowerCase() === String(q.exact).toLowerCase();
      }
      st.answers[q.id] = { q: q.label, a: answer, ok };
    }
    pending.set(i.user.id, st);
    await i.reply({
      content: '✅ Page enregistrée.',
      embeds: [pageEmbed(st, qs)],
      components: pageNav(st, qs),
      ...EPH,
    });
    return true;
  }

  if (id === 'mx_modal_form_ans') {
    const st = pending.get(i.user.id);
    if (!st) {
      await i.reply({ content: 'Session expirée. Recommence le formulaire.', ...EPH });
      return true;
    }
    const qs = getGuild(st.guildId).formQuestions || [];
    const q = qs[st.step];
    const answer = i.fields.getTextInputValue('answer').trim();
    let ok = null;
    if (q?.type === 'exacte' && q.exact) {
      ok = answer.toLowerCase() === String(q.exact).toLowerCase();
    }
    st.answers.push({ q: q?.label, a: answer, ok });
    st.step++;
    pending.set(i.user.id, st);
    // Continuer : si encore des questions QCM ou modal
    if (st.step >= qs.length) {
      await submitApplication(i, st);
      return true;
    }
    const next = qs[st.step];
    if (next.type === 'qcm') {
      await i.reply({ content: `✅ Réponse enregistrée.${ok === false ? ' (réponse exacte incorrecte)' : ''}\nProchaine question…`, ...EPH });
      // need to send QCM as followUp
      const st2 = pending.get(i.user.id);
      await askStepFromFollowUp(i, st2);
      return true;
    }
    // next libre/exacte → show another modal not possible same interaction
    // reply then user clicks continue - auto show via followUp button
    await i.reply({
      content: `✅ Réponse enregistrée.${ok === false ? ' ⚠️ réponse exacte incorrecte' : ''}`,
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('mx_form_continue').setLabel('Question suivante').setStyle(ButtonStyle.Primary),
        ),
      ],
      ...EPH,
    });
    return true;
  }

  if (id === 'mx_form_continue' || id === 'mx_form_continue') {
    return false; // button handled in handle
  }

  const mOk = id.match(/^mx_modal_form_ok_(.+)$/);
  const mNo = id.match(/^mx_modal_form_no_(.+)$/);

  if (mOk) {
    if (!canReview(i.member, getGuild(i.guild.id))) {
      await i.reply({ content: '❌', ...EPH });
      return true;
    }
    const fid = mOk[1];
    const remark = i.fields.getTextInputValue('remark').trim();
    const map = formsMap(i.guild.id);
    const e = map[fid];
    if (!e || e.status !== 'pending') {
      await i.reply({ content: 'Candidature introuvable ou déjà traitée.', ...EPH });
      return true;
    }
    const c = getGuild(i.guild.id);
    e.status = 'accepted';
    e.remark = remark;
    e.reviewedBy = i.user.id;
    e.reviewedAt = Date.now();
    map[fid] = e;
    setForms(i.guild.id, map);

    // Rôle
    const member = await i.guild.members.fetch(e.userId).catch(() => null);
    if (member && c.formAcceptRoleId) {
      await member.roles.add(c.formAcceptRoleId, 'Formulaire accepté').catch(() => null);
    }

    // MP
    try {
      const user = await i.client.users.fetch(e.userId);
      await user.send({
        embeds: [
          emb('✅ Candidature acceptée', C.success)
            .setDescription(
              [
                `Serveur : **${i.guild.name}**`,
                c.formAcceptRoleId ? `Rôle reçu : <@&${c.formAcceptRoleId}>` : 'Aucun rôle supplémentaire.',
                '',
                '### Remarque du staff',
                remark,
              ].join('\n')
            ),
        ],
      });
    } catch {}

    // Update message
    await updateFormMessage(i, e, c, true);
    await i.reply({ content: `✅ Candidature **${fid}** acceptée.`, ...EPH });
    return true;
  }

  if (mNo) {
    if (!canReview(i.member, getGuild(i.guild.id))) {
      await i.reply({ content: '❌', ...EPH });
      return true;
    }
    const fid = mNo[1];
    const reason = i.fields.getTextInputValue('reason').trim();
    const details = i.fields.getTextInputValue('details').trim();
    const map = formsMap(i.guild.id);
    const e = map[fid];
    if (!e || e.status !== 'pending') {
      await i.reply({ content: 'Candidature introuvable ou déjà traitée.', ...EPH });
      return true;
    }
    const c = getGuild(i.guild.id);
    e.status = 'refused';
    e.refuseReason = reason;
    e.details = details;
    e.reviewedBy = i.user.id;
    e.reviewedAt = Date.now();
    map[fid] = e;
    setForms(i.guild.id, map);

    try {
      const user = await i.client.users.fetch(e.userId);
      await user.send({
        embeds: [
          emb('❌ Candidature refusée', C.danger)
            .setDescription(
              [
                `Serveur : **${i.guild.name}**`,
                `**Raison :** ${reason}`,
                '',
                '_Des détails complémentaires sont disponibles pour le staff sur le message de candidature (bouton Détails)._',
              ].join('\n')
            ),
        ],
      });
    } catch {}

    await updateFormMessage(i, e, c, false);
    await i.reply({ content: `✅ Candidature **${fid}** refusée.`, ...EPH });
    return true;
  }

  return false;
}

async function askStepFromFollowUp(i, st) {
  // recreate interaction-like flow via followUp for QCM after modal
  const c = getGuild(st.guildId);
  const qs = c.formQuestions || [];
  const q = qs[st.step];
  if (!q) return;
  if (q.type === 'qcm') {
    const opts = (q.options || []).slice(0, 25).map((o, idx) => ({ label: String(o).slice(0, 100), value: String(idx) }));
    await i.followUp({
      embeds: [emb(`${E.crayon} Question ${st.step + 1}/${qs.length}`, C.violet || C.primary).setDescription(`**${q.label}**`)],
      components: [
        new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder().setCustomId('mx_form_ans_qcm').setPlaceholder('Choisis…').addOptions(opts),
        ),
      ],
      ...EPH,
    });
  }
}

async function updateFormMessage(i, e, c, accepted) {
  if (!e.channelId || !e.messageId) return;
  const ch = await i.guild.channels.fetch(e.channelId).catch(() => null);
  const msg = ch && await ch.messages.fetch(e.messageId).catch(() => null);
  if (!msg) return;
  const color = accepted ? C.success : C.danger;
  const status = accepted ? '✅ Acceptée' : '❌ Refusée';
  const embed = EmbedBuilder.from(msg.embeds[0] || emb('Candidature', color))
    .setColor(color)
    .spliceFields(2, 1, { name: 'Statut', value: status, inline: true });
  if (accepted && e.remark) {
    embed.addFields({ name: 'Remarque staff', value: e.remark.slice(0, 500) });
  }
  if (!accepted && e.refuseReason) {
    embed.addFields({ name: 'Raison du refus', value: e.refuseReason.slice(0, 200) });
  }
  embed.addFields({ name: 'Traité par', value: `<@${e.reviewedBy}>` });

  await msg.edit({
    embeds: [embed],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`mx_form_ok_${e.id}`).setLabel('Accepter').setStyle(ButtonStyle.Success).setDisabled(true),
        new ButtonBuilder().setCustomId(`mx_form_no_${e.id}`).setLabel('Refuser').setStyle(ButtonStyle.Danger).setDisabled(true),
        new ButtonBuilder()
          .setCustomId(`mx_form_det_${e.id}`)
          .setLabel('Détails')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji('📄')
          .setDisabled(accepted || !e.details),
      ),
    ],
  }).catch(() => null);
}

// continue button
const _handle = handle;
async function handleWrapped(i) {
  if (i.customId === 'mx_form_continue') {
    const st = pending.get(i.user.id);
    if (!st) {
      await i.reply({ content: 'Session expirée.', ...EPH });
      return true;
    }
    await askStep(i, false);
    return true;
  }
  return _handle(i);
}

module.exports = { command, handle: handleWrapped, handleModal };
