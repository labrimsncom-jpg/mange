const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder,
  RoleSelectMenuBuilder, ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle,
  MessageFlags, PermissionFlagsBits, SlashCommandBuilder,
} = require('discord.js');
const { getGuild, setGuild } = require('./storage.js');
const { isAdmin } = require('./perms.js');
const { emb, C } = require('./design.js');
const { openBtn } = require('./pickers.js');
const { E, CFG } = require('./emojis.js');

const EPH = { flags: MessageFlags.Ephemeral };

function panel(gid) {
  const c = getGuild(gid);
  const { card, C: Col, ch, roles } = require('./design.js');
  return card({
    title: '⚙️ Configuration serveur',
    color: Col.config,
    description: [
      '### Bienvenue · Départ · Rôles · Logs · Automatisations',
      '',
      'Configure chaque module avec les menus et boutons ci-dessous.',
      '',
      '**Variables messages**',
      '`{user}` → mention du membre',
      '`{server}` → nom du serveur',
    ].join('\n'),
    fields: [
      { name: '👋 Salon bienvenue', value: ch(c.welcomeChannelId), inline: true },
      { name: '🚪 Salon départ', value: ch(c.leaveChannelId), inline: true },
      { name: '📜 Salon logs', value: ch(c.logChannelId), inline: true },
      { name: '🎭 Auto-rôles à l’arrivée', value: roles(c.autoRoleIds) },
      { name: '📣 Auto-ping', value: `**${(c.autoPing || []).length}** règle(s)\n_Ping + message temporaire_`, inline: true },
      { name: '📢 Annonces auto', value: `**${(c.autoAnnounce || []).length}** règle(s)\n_Messages répétées_`, inline: true },
      { name: '💬 Msg bienvenue', value: `\`\`\`\n${(c.welcomeMessage || '—').slice(0, 120)}\n\`\`\`` },
      { name: '💬 Msg départ', value: `\`\`\`\n${(c.leaveMessage || '—').slice(0, 120)}\n\`\`\`` },
      {
        name: '🔇 Anti-mention',
        value: c.antiMentionEnabled
          ? `🟢 **${String(c.antiMentionStartHour ?? 22).padStart(2,'0')}h → ${String(c.antiMentionEndHour ?? 8).padStart(2,'0')}h**`
          : '🔴 Désactivé',
        inline: true,
      },
    ],
    footer: 'ManageX · /serverconfig',
  });
}

function rows() {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('mx_srv_welcome_msg').setLabel('Texte bienvenue').setEmoji('👋').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('mx_srv_leave_msg').setLabel('Texte départ').setEmoji('🚪').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('mx_srv_ping_add').setLabel('Auto-ping').setEmoji('📣').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('mx_srv_ann_add').setLabel('Annonce auto').setEmoji('📢').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('mx_srv_antimention').setLabel('Anti-mention').setEmoji('🔇').setStyle(ButtonStyle.Danger),
    ),
    new ActionRowBuilder().addComponents(
      openBtn('ch', 'srv_welcome', '👋 Salon bienvenue'),
      openBtn('ch', 'srv_leave', '🚪 Salon départ'),
    ),
    new ActionRowBuilder().addComponents(
      openBtn('ch', 'srv_log', '📜 Salon logs'),
      openBtn('role', 'srv_autorole', '🎭 Auto-rôles'),
    ),
  ];
}

const command = {
  data: new SlashCommandBuilder()
    .setName('serverconfig')
    .setDescription('ManageX — bienvenue, auto-rôle, logs, auto-ping…')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(i) {
    if (!isAdmin(i.member)) return i.reply({ content: '❌ Admin requis.', ...EPH });
    await i.reply({ embeds: [panel(i.guild.id)], components: rows(), ...EPH });
  },
};

async function handle(i) {
  const id = i.customId || '';
  if (!id.startsWith('mx_srv_')) return false;
  if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
  const gid = i.guild.id;
  const c = getGuild(gid);

  if (id === 'mx_srv_refresh') {
    await i.update({ embeds: [panel(gid)], components: rows() });
    return true;
  }
  if (id === 'mx_srv_antimention') {
    const am = require('./antiMention.js');
    await i.reply({
      embeds: [am.configEmbed(gid)],
      components: am.configComponents(),
      ...EPH,
    });
    return true;
  }
  if (id === 'mx_srv_welcome_ch') {
    setGuild(gid, { welcomeChannelId: i.values[0] || null });
    await i.update({ embeds: [panel(gid)], components: rows() });
    return true;
  }
  if (id === 'mx_srv_leave_ch') {
    setGuild(gid, { leaveChannelId: i.values[0] || null });
    await i.update({ embeds: [panel(gid)], components: rows() });
    return true;
  }
  if (id === 'mx_srv_log') {
    setGuild(gid, { logChannelId: i.values[0] || null });
    await i.update({ embeds: [panel(gid)], components: rows() });
    return true;
  }
  if (id === 'mx_srv_autorole') {
    setGuild(gid, { autoRoleIds: i.values || [] });
    await i.update({ embeds: [panel(gid)], components: rows() });
    return true;
  }
  if (id === 'mx_srv_welcome_msg' || id === 'mx_srv_leave_msg') {
    const isW = id.includes('welcome');
    const modal = new ModalBuilder().setCustomId(isW ? 'mx_modal_welcome' : 'mx_modal_leave').setTitle(isW ? 'Message bienvenue' : 'Message départ');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('text').setLabel('Message ({user} {server})')
          .setStyle(TextInputStyle.Paragraph).setRequired(true)
          .setValue((isW ? c.welcomeMessage : c.leaveMessage) || '').setMaxLength(1000)
      )
    );
    await i.showModal(modal);
    return true;
  }
  if (id === 'mx_srv_ping_add') {
    const modal = new ModalBuilder().setCustomId('mx_modal_autoping').setTitle('Auto-ping');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('channel').setLabel('ID salon').setStyle(TextInputStyle.Short).setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('message').setLabel('Message (ping le membre avec {user})').setStyle(TextInputStyle.Paragraph).setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('sec').setLabel('Durée secondes avant delete').setStyle(TextInputStyle.Short).setValue('30')
      ),
    );
    await i.showModal(modal);
    return true;
  }
  if (id === 'mx_srv_ann_add') {
    const modal = new ModalBuilder().setCustomId('mx_modal_autoann').setTitle('Annonce auto');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('channel').setLabel('ID salon').setStyle(TextInputStyle.Short).setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('message').setLabel('Message').setStyle(TextInputStyle.Paragraph).setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('hours').setLabel('Intervalle heures').setStyle(TextInputStyle.Short).setValue('24')
      ),
    );
    await i.showModal(modal);
    return true;
  }
  return false;
}

async function handleModal(i) {
  const id = i.customId || '';
  if (!id.startsWith('mx_modal_')) return false;
  if (!['mx_modal_welcome', 'mx_modal_leave', 'mx_modal_autoping', 'mx_modal_autoann'].includes(id)) return false;
  if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
  const gid = i.guild.id;
  const c = getGuild(gid);

  if (id === 'mx_modal_welcome') {
    setGuild(gid, { welcomeMessage: i.fields.getTextInputValue('text') });
    await i.reply({ content: '✅ Message bienvenue OK.', ...EPH });
    return true;
  }
  if (id === 'mx_modal_leave') {
    setGuild(gid, { leaveMessage: i.fields.getTextInputValue('text') });
    await i.reply({ content: '✅ Message départ OK.', ...EPH });
    return true;
  }
  if (id === 'mx_modal_autoping') {
    const list = [...(c.autoPing || [])];
    list.push({
      channelId: i.fields.getTextInputValue('channel').trim(),
      message: i.fields.getTextInputValue('message'),
      durationSec: parseInt(i.fields.getTextInputValue('sec'), 10) || 30,
    });
    setGuild(gid, { autoPing: list.slice(0, 10) });
    await i.reply({ content: `✅ Auto-ping ajouté (${list.length}).`, ...EPH });
    return true;
  }
  if (id === 'mx_modal_autoann') {
    const list = [...(c.autoAnnounce || [])];
    list.push({
      channelId: i.fields.getTextInputValue('channel').trim(),
      message: i.fields.getTextInputValue('message'),
      intervalHours: parseInt(i.fields.getTextInputValue('hours'), 10) || 24,
      lastAt: 0,
    });
    setGuild(gid, { autoAnnounce: list.slice(0, 10) });
    await i.reply({ content: `✅ Annonce auto ajoutée (${list.length}).`, ...EPH });
    return true;
  }
  return false;
}

async function onMemberAdd(member) {
  const c = getGuild(member.guild.id);
  for (const rid of c.autoRoleIds || []) {
    await member.roles.add(rid, 'ManageX autorole').catch(() => null);
  }
  if (c.welcomeChannelId) {
    const chn = await member.guild.channels.fetch(c.welcomeChannelId).catch(() => null);
    const text = (c.welcomeMessage || 'Bienvenue {user} sur **{server}** !')
      .replace(/\{user\}/gi, `${member}`)
      .replace(/\{server\}/gi, member.guild.name);
    const accountAge = member.user?.createdTimestamp
      ? `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`
      : '—';
    const embed = new (require('discord.js').EmbedBuilder)()
      .setColor(c.welcomeColor || 0x57f287)
      .setAuthor({
        name: `Nouveau membre · ${member.guild.name}`,
        iconURL: member.guild.iconURL({ size: 64 }) || undefined,
      })
      .setTitle(`👋 Bienvenue, ${member.user.username} !`)
      .setDescription(text)
      .addFields(
        { name: '👤 Membre', value: `${member}\n\`${member.id}\``, inline: true },
        { name: '📅 Compte créé', value: accountAge, inline: true },
        { name: '👥 Membres', value: `**${member.guild.memberCount}**`, inline: true },
      )
      .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
      .setImage(member.guild.bannerURL({ size: 512 }) || null)
      .setFooter({ text: `ManageX · Arrivée · #${member.guild.memberCount}` })
      .setTimestamp();
    if (chn?.send) await chn.send({ content: `${member}`, embeds: [embed] }).catch(() => null);
  }
  for (const p of c.autoPing || []) {
    const chn = await member.guild.channels.fetch(p.channelId).catch(() => null);
    if (!chn?.send) continue;
    const text = (p.message || '{user}').replace(/\{user\}/gi, `${member}`);
    const m = await chn.send({ content: text }).catch(() => null);
    if (m && p.durationSec > 0) {
      setTimeout(() => m.delete().catch(() => null), (p.durationSec || 30) * 1000);
    }
  }
}

async function onMemberRemove(member) {
  const c = getGuild(member.guild.id);
  if (!c.leaveChannelId) return;
  const chn = await member.guild.channels.fetch(c.leaveChannelId).catch(() => null);
  const tag = member.user?.tag || member.id;
  const text = (c.leaveMessage || '{user} a quitté le serveur.')
    .replace(/\{user\}/gi, `**${tag}**`)
    .replace(/\{server\}/gi, member.guild.name);
  const joined = member.joinedTimestamp
    ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`
    : '—';
  const embed = new (require('discord.js').EmbedBuilder)()
    .setColor(c.leaveColor || 0xed4245)
    .setAuthor({
      name: `Départ · ${member.guild.name}`,
      iconURL: member.guild.iconURL({ size: 64 }) || undefined,
    })
    .setTitle(`🚪 ${tag} est parti`)
    .setDescription(text)
    .addFields(
      { name: '👤 Membre', value: `\`${member.id}\``, inline: true },
      { name: '📥 Avait rejoint', value: joined, inline: true },
      { name: '👥 Membres restants', value: `**${member.guild.memberCount}**`, inline: true },
    )
    .setThumbnail(member.user?.displayAvatarURL?.({ size: 256 }) || null)
    .setFooter({ text: 'ManageX · Départ' })
    .setTimestamp();
  if (chn?.send) await chn.send({ embeds: [embed] }).catch(() => null);
}

function startAnnounceTicker(client) {
  setInterval(async () => {
    for (const [, guild] of client.guilds.cache) {
      const c = getGuild(guild.id);
      const list = [...(c.autoAnnounce || [])];
      let changed = false;
      for (const a of list) {
        const ms = (a.intervalHours || 24) * 3600_000;
        if (Date.now() - (a.lastAt || 0) < ms) continue;
        const ch = await guild.channels.fetch(a.channelId).catch(() => null);
        if (ch?.send) {
          await ch.send({ content: a.message }).catch(() => null);
          a.lastAt = Date.now();
          changed = true;
        }
      }
      if (changed) setGuild(guild.id, { autoAnnounce: list });
    }
  }, 5 * 60_000);
}

module.exports = { command, handle, handleModal, onMemberAdd, onMemberRemove, startAnnounceTicker };
