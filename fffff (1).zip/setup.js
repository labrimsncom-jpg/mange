/**
 * /setup — installation guidée ManageX
 */
const {
  SlashCommandBuilder, PermissionFlagsBits, MessageFlags,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ChannelSelectMenuBuilder, RoleSelectMenuBuilder, ChannelType,
} = require('discord.js');
const { getGuild, setGuild } = require('./storage.js');
const { isAdmin } = require('./perms.js');
const { emb, C, card, ch, roles } = require('./design.js');
const { E, CFG } = require('./emojis.js');

const EPH = { flags: MessageFlags.Ephemeral };

function checklist(gid) {
  const c = getGuild(gid);
  const items = [
    [!!c.welcomeChannelId, 'Salon bienvenue', ch(c.welcomeChannelId)],
    [!!c.leaveChannelId, 'Salon départ', ch(c.leaveChannelId)],
    [!!c.logChannelId, 'Salon logs serveur', ch(c.logChannelId)],
    [!!c.ticketCategoryId, 'Catégorie tickets', c.ticketCategoryId ? `\`${c.ticketCategoryId}\`` : '—'],
    [!!c.ticketLogChannelId, 'Logs tickets', ch(c.ticketLogChannelId)],
    [(c.serverStaffRoleIds || []).length > 0, 'Rôles staff serveur', roles(c.serverStaffRoleIds)],
    [!!c.serviceRoleId || !!c.horsServiceRoleId, 'Rôles service', c.serviceRoleId ? `<@&${c.serviceRoleId}>` : '—'],
    [(c.autoRoleIds || []).length > 0, 'Auto-rôles', roles(c.autoRoleIds)],
  ];
  const ok = items.filter((x) => x[0]).length;
  return { items, ok, total: items.length };
}

function setupEmbed(guild) {
  const { items, ok, total } = checklist(guild.id);
  const lines = items.map(([done, label, val]) =>
    `${done ? '✅' : '❌'} **${label}** — ${val || '—'}`
  );
  return card({
    title: '🚀 Setup guidé ManageX',
    color: ok === total ? C.success : C.info,
    description: [
      `### Configuration de **${guild.name}**`,
      '',
      `Progression : **${ok}/${total}**`,
      '',
      ...lines,
      '',
      '_Utilise les menus ci-dessous, puis **Terminer**._',
    ].join('\n'),
    footer: 'ManageX · /setup',
  });
}

function setupRows() {
  return [
    new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId('mx_setup_welcome')
        .setPlaceholder('1️⃣ Salon bienvenue…')
        .addChannelTypes(ChannelType.GuildText)
        .setMinValues(0).setMaxValues(1)
    ),
    new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId('mx_setup_leave')
        .setPlaceholder('2️⃣ Salon départ…')
        .addChannelTypes(ChannelType.GuildText)
        .setMinValues(0).setMaxValues(1)
    ),
    new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId('mx_setup_log')
        .setPlaceholder('3️⃣ Salon logs serveur…')
        .addChannelTypes(ChannelType.GuildText)
        .setMinValues(0).setMaxValues(1)
    ),
    new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId('mx_setup_tkcat')
        .setPlaceholder('4️⃣ Catégorie parent des tickets…')
        .addChannelTypes(ChannelType.GuildCategory)
        .setMinValues(0).setMaxValues(1)
    ),
    new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId('mx_setup_tklog')
        .setPlaceholder('5️⃣ Salon logs tickets (+ transcripts)…')
        .addChannelTypes(ChannelType.GuildText)
        .setMinValues(0).setMaxValues(1)
    ),
  ];
}

function setupRows2() {
  return [
    new ActionRowBuilder().addComponents(
      new RoleSelectMenuBuilder()
        .setCustomId('mx_setup_staff')
        .setPlaceholder('6️⃣ Rôles staff serveur…')
        .setMinValues(0).setMaxValues(10)
    ),
    new ActionRowBuilder().addComponents(
      new RoleSelectMenuBuilder()
        .setCustomId('mx_setup_autorole')
        .setPlaceholder('7️⃣ Auto-rôles à l’arrivée…')
        .setMinValues(0).setMaxValues(10)
    ),
    new ActionRowBuilder().addComponents(
      new RoleSelectMenuBuilder()
        .setCustomId('mx_setup_service')
        .setPlaceholder('8️⃣ Rôle EN service…')
        .setMinValues(0).setMaxValues(1)
    ),
    new ActionRowBuilder().addComponents(
      new RoleSelectMenuBuilder()
        .setCustomId('mx_setup_hors')
        .setPlaceholder('9️⃣ Rôle HORS service…')
        .setMinValues(0).setMaxValues(1)
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('mx_setup_refresh').setLabel('Actualiser').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('mx_setup_done').setLabel('Terminer').setEmoji('✅').setStyle(ButtonStyle.Success),
    ),
  ];
}

const command = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('ManageX — installation guidée du serveur')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  async execute(i) {
    if (!isAdmin(i.member)) return i.reply({ content: '❌ Admin.', ...EPH });
    await i.reply({
      embeds: [setupEmbed(i.guild)],
      components: setupRows(),
      ...EPH,
    });
    await i.followUp({
      content: '**Staff · auto-rôles · service**',
      components: setupRows2(),
      ...EPH,
    });
  },
};

async function handle(i) {
  const id = i.customId || '';
  if (!id.startsWith('mx_setup_')) return false;
  if (!isAdmin(i.member)) {
    await i.reply({ content: '❌ Admin.', ...EPH });
    return true;
  }
  const gid = i.guild.id;

  const map = {
    mx_setup_welcome: 'welcomeChannelId',
    mx_setup_leave: 'leaveChannelId',
    mx_setup_log: 'logChannelId',
    mx_setup_tkcat: 'ticketCategoryId',
    mx_setup_tklog: 'ticketLogChannelId',
  };

  if (map[id]) {
    const val = i.values?.[0] || null;
    setGuild(gid, { [map[id]]: val });
    await i.reply({
      content: val ? `✅ **${map[id]}** → ${id.includes('tkcat') ? `\`${val}\`` : `<#${val}>`}` : `✅ ${map[id]} retiré.`,
      ...EPH,
    });
    return true;
  }

  if (id === 'mx_setup_staff') {
    setGuild(gid, { serverStaffRoleIds: i.values || [] });
    await i.reply({ content: `✅ Staff serveur : **${(i.values || []).length}** rôle(s)`, ...EPH });
    return true;
  }
  if (id === 'mx_setup_autorole') {
    setGuild(gid, { autoRoleIds: i.values || [] });
    await i.reply({ content: `✅ Auto-rôles : **${(i.values || []).length}**`, ...EPH });
    return true;
  }
  if (id === 'mx_setup_service') {
    setGuild(gid, { serviceRoleId: i.values?.[0] || null });
    await i.reply({ content: i.values?.[0] ? `✅ En service → <@&${i.values[0]}>` : '✅ Rôle service retiré.', ...EPH });
    return true;
  }
  if (id === 'mx_setup_hors') {
    setGuild(gid, { horsServiceRoleId: i.values?.[0] || null });
    await i.reply({ content: i.values?.[0] ? `✅ Hors service → <@&${i.values[0]}>` : '✅ Rôle hors service retiré.', ...EPH });
    return true;
  }
  if (id === 'mx_setup_refresh') {
    await i.update({ embeds: [setupEmbed(i.guild)], components: setupRows() });
    return true;
  }
  if (id === 'mx_setup_done') {
    const { ok, total } = checklist(gid);
    await i.reply({
      embeds: [card({
        title: `${CFG.ready} Setup terminé`,
        color: ok === total ? C.success : C.warn,
        description: [
          `**${ok}/${total}** points configurés.`,
          '',
          '### Suite recommandée',
          '• `/ticketsconfig` → poster le **panel** tickets',
          '• `/staffconfig` → panels service / absence / banreg',
          '• `/serverconfig` → messages bienvenue / anti-mention',
          '• `/niveauxconfig` → XP',
          '',
          ok < total ? '_Tu peux relancer `/setup` pour compléter._' : '_Serveur prêt._',
        ].join('\n'),
        footer: 'ManageX · setup',
      })],
      ...EPH,
    });
    return true;
  }

  return false;
}

module.exports = { command, handle };
