const {
  SlashCommandBuilder, PermissionFlagsBits, MessageFlags,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ChannelSelectMenuBuilder, ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle,
  EmbedBuilder,
} = require('discord.js');
const { getGuild, setGuild, read, write } = require('./storage.js');
const { isAdmin } = require('./perms.js');
const { emb, C, card, ch, status } = require('./design.js');
const { openBtn } = require('./pickers.js');
const { E, CFG } = require('./emojis.js');

const EPH = { flags: MessageFlags.Ephemeral };
const cd = new Map();

function getXp(gid) {
  return read('xp.json', {})[gid] || {};
}
function setXp(gid, data) {
  const all = read('xp.json', {});
  all[gid] = data;
  write('xp.json', all);
}
function xpForLevel(lvl) {
  return 100 * lvl * lvl;
}

function addXp(gid, uid, amount) {
  const map = getXp(gid);
  if (!map[uid]) map[uid] = { xp: 0, level: 0 };
  map[uid].xp += amount;
  let leveled = false;
  let newLevel = map[uid].level;
  while (map[uid].xp >= xpForLevel(map[uid].level + 1)) {
    map[uid].level += 1;
    newLevel = map[uid].level;
    leveled = true;
  }
  setXp(gid, map);
  return { ...map[uid], leveled, newLevel };
}

function configEmbed(gid) {
  const c = getGuild(gid);
  return card({
    title: '📈 Niveaux Config',
    color: C.success,
    description: [
      '### Système d’expérience & niveaux',
      '',
      'Les membres gagnent de l’XP en écrivant (cooldown).',
      'À chaque niveau, une annonce peut être envoyée dans un salon.',
      '',
      '**Récompenses** : rôle automatique à un niveau donné (via modal).',
    ].join('\n'),
    fields: [
      { name: 'Statut', value: c.levelsEnabled !== false ? '🟢 Activé' : '🔴 Désactivé', inline: true },
      { name: '📢 Salon annonces', value: ch(c.levelsChannelId) || '`Salon du message`', inline: true },
      { name: '⏱️ Cooldown', value: `**${c.levelsCooldownSec || 60}**s`, inline: true },
      { name: '✨ XP / message', value: `**${c.levelsXpMin || 15}** – **${c.levelsXpMax || 25}**`, inline: true },
      {
        name: '🎁 Récompenses rôles',
        value: (c.levelRewardRoles || []).length
          ? (c.levelRewardRoles || []).map((r) => `Niv. **${r.level}** → <@&${r.roleId}>`).join('\n')
          : '`Aucune`',
      },
    ],
    footer: 'ManageX · /niveauxconfig',
  });
}

const command = {
  data: new SlashCommandBuilder()
    .setName('niveauxconfig')
    .setDescription('ManageX — XP, niveaux, salon annonces, récompenses')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(i) {
    if (!isAdmin(i.member)) return i.reply({ content: '❌ Admin.', ...EPH });
    await i.reply({
      embeds: [configEmbed(i.guild.id)],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('mx_lvl_toggle').setLabel('Activer / Désactiver').setStyle(ButtonStyle.Primary).setEmoji('📈'),
          new ButtonBuilder().setCustomId('mx_lvl_xp').setLabel('XP & cooldown').setStyle(ButtonStyle.Secondary).setEmoji('⚙️'),
          new ButtonBuilder().setCustomId('mx_lvl_reward').setLabel('Ajouter récompense').setStyle(ButtonStyle.Success).setEmoji('🎁'),
          new ButtonBuilder().setCustomId('mx_lvl_refresh').setLabel('Actualiser').setStyle(ButtonStyle.Secondary),
        ),
        new ActionRowBuilder().addComponents(
          openBtn('ch', 'lvl_ch', '📢 Salon niveaux')
        ),
      ],
      ...EPH,
    });
  },
};

async function handle(i) {
  const id = i.customId || '';
  if (!id.startsWith('mx_lvl_')) return false;
  if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
  const gid = i.guild.id;
  const c = getGuild(gid);

  if (id === 'mx_lvl_toggle') {
    setGuild(gid, { levelsEnabled: c.levelsEnabled === false });
    await i.update({ embeds: [configEmbed(gid)] });
    return true;
  }
  if (id === 'mx_lvl_refresh') {
    await i.update({ embeds: [configEmbed(gid)] });
    return true;
  }
  if (id === 'mx_lvl_channel') {
    setGuild(gid, { levelsChannelId: i.values[0] || null });
    await i.reply({ content: i.values[0] ? `✅ Annonces → <#${i.values[0]}>` : '✅ Annonces dans le salon du message.', ...EPH });
    return true;
  }
  if (id === 'mx_lvl_xp') {
    const modal = new ModalBuilder().setCustomId('mx_modal_lvl_xp').setTitle('XP & cooldown');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('min').setLabel('XP minimum').setStyle(TextInputStyle.Short)
          .setValue(String(c.levelsXpMin || 15)).setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('max').setLabel('XP maximum').setStyle(TextInputStyle.Short)
          .setValue(String(c.levelsXpMax || 25)).setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('cd').setLabel('Cooldown (secondes)').setStyle(TextInputStyle.Short)
          .setValue(String(c.levelsCooldownSec || 60)).setRequired(true)
      ),
    );
    await i.showModal(modal);
    return true;
  }
  if (id === 'mx_lvl_reward') {
    const modal = new ModalBuilder().setCustomId('mx_modal_lvl_reward').setTitle('Récompense niveau');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('level').setLabel('Niveau requis').setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder('10')
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('role').setLabel('ID du rôle').setStyle(TextInputStyle.Short).setRequired(true)
      ),
    );
    await i.showModal(modal);
    return true;
  }
  return false;
}

async function handleModal(i) {
  if (i.customId === 'mx_modal_lvl_xp') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    let min = parseInt(i.fields.getTextInputValue('min'), 10) || 15;
    let max = parseInt(i.fields.getTextInputValue('max'), 10) || 25;
    let cdSec = parseInt(i.fields.getTextInputValue('cd'), 10) || 60;
    if (min > max) [min, max] = [max, min];
    setGuild(i.guild.id, {
      levelsXpMin: Math.max(1, min),
      levelsXpMax: Math.max(1, max),
      levelsCooldownSec: Math.max(10, Math.min(600, cdSec)),
    });
    await i.reply({ content: `✅ XP **${min}–${max}** · cooldown **${cdSec}s**`, ...EPH });
    return true;
  }
  if (i.customId === 'mx_modal_lvl_reward') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    const level = parseInt(i.fields.getTextInputValue('level'), 10);
    const roleId = i.fields.getTextInputValue('role').trim();
    if (!level || level < 1) { await i.reply({ content: 'Niveau invalide.', ...EPH }); return true; }
    const c = getGuild(i.guild.id);
    const list = [...(c.levelRewardRoles || []).filter((r) => r.level !== level), { level, roleId }];
    list.sort((a, b) => a.level - b.level);
    setGuild(i.guild.id, { levelRewardRoles: list });
    await i.reply({ content: `✅ Niveau **${level}** → <@&${roleId}>`, ...EPH });
    return true;
  }
  return false;
}

async function onMessage(message) {
  if (!message.guild || message.author.bot) return;
  const c = getGuild(message.guild.id);
  if (c.levelsEnabled === false) return;

  const key = `${message.guild.id}:${message.author.id}`;
  const last = cd.get(key) || 0;
  const cooldown = (c.levelsCooldownSec || 60) * 1000;
  if (Date.now() - last < cooldown) return;
  cd.set(key, Date.now());

  const min = c.levelsXpMin || 15;
  const max = c.levelsXpMax || 25;
  const amount = min + Math.floor(Math.random() * (max - min + 1));
  const r = addXp(message.guild.id, message.author.id, amount);
  if (!r.leveled) return;

  // rewards
  for (const rew of c.levelRewardRoles || []) {
    if (rew.level === r.newLevel) {
      await message.member?.roles.add(rew.roleId, `ManageX niveau ${r.newLevel}`).catch(() => null);
    }
  }

  const embed = new EmbedBuilder()
    .setColor(C.success)
    .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ size: 64 }) })
    .setTitle('🎉 Niveau supérieur !')
    .setDescription(
      [
        `### Bravo ${message.author} !`,
        '',
        `Tu passes niveau **${r.newLevel}**`,
        `XP total : **${r.xp}**`,
      ].join('\n')
    )
    .setThumbnail(message.author.displayAvatarURL({ size: 256 }))
    .setFooter({ text: 'ManageX · Niveaux' })
    .setTimestamp();

  const targetId = c.levelsChannelId || message.channel.id;
  const chn = await message.guild.channels.fetch(targetId).catch(() => message.channel);
  if (chn?.send) await chn.send({ embeds: [embed] }).catch(() => null);
}

module.exports = { command, handle, handleModal, onMessage, getXp, xpForLevel };
