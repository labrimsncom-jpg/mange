const { PermissionFlagsBits } = require('discord.js');
const { getGlobal, getGuild } = require('./storage.js');

function ensureOwnerFromEnv() {
  const oid = process.env.OWNER_ID;
  if (!oid) return;
  const g = getGlobal();
  if (!g.ownerIds.includes(oid)) {
    const { setGlobal } = require('./storage.js');
    setGlobal({ ownerIds: [...new Set([oid, ...g.ownerIds])] });
  }
}

function isOwner(userId) {
  ensureOwnerFromEnv();
  return getGlobal().ownerIds.includes(userId);
}
function isCoOwner(userId) {
  return isOwner(userId) || getGlobal().coOwnerIds.includes(userId);
}
function isDeveloper(userId) {
  return isCoOwner(userId) || getGlobal().developerIds.includes(userId);
}
function isBotStaff(userId) {
  return isDeveloper(userId) || getGlobal().staffIds.includes(userId);
}

/** Staff du SERVEUR (rôles configurés) */
function isServerStaff(member) {
  if (!member) return false;
  if (member.permissions?.has?.(PermissionFlagsBits.Administrator)) return true;
  if (member.permissions?.has?.(PermissionFlagsBits.ModerateMembers)) return true;
  if (member.permissions?.has?.(PermissionFlagsBits.ManageGuild)) return true;
  const cfg = getGuild(member.guild.id);
  return (cfg.serverStaffRoleIds || []).some((id) => member.roles.cache.has(id));
}

function isAdmin(member) {
  return member?.permissions?.has?.(PermissionFlagsBits.Administrator) ||
    member?.permissions?.has?.(PermissionFlagsBits.ManageGuild);
}

module.exports = {
  isOwner, isCoOwner, isDeveloper, isBotStaff, isServerStaff, isAdmin, ensureOwnerFromEnv,
};
