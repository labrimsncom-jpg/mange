/**
 * ManageX — Règlement
 * /reglementconfig : texte, rôle donné, rôle retiré, poster le panel
 * Bouton « Accepter le règlement » → rôles + confirmation
 */
const {
  SlashCommandBuilder, PermissionFlagsBits, MessageFlags,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder,
} = require('discord.js');
const { getGuild, setGuild } = require('./storage.js');
const { isAdmin } = require('./perms.js');
const { emb, C, configCard, role } = require('./design.js');
const { openBtn } = require('./pickers.js');

const EPH = { flags: MessageFlags.Ephemeral };

function panelEmbed(guild) {
  const c = getGuild(guild.id);
  const text = (c.reglementText || '_Aucun règlement configuré._').slice(0, 4000);
  return new EmbedBuilder()
    .setColor(c.reglementColor || C.primary)
    .setTitle(`📜 ${c.reglementTitle || 'Règlement du serveur'}`)
    .setDescription(text)
    .addFields(
      {
        name: '✅ En acceptant',
        value: [
          c.reglementAcceptRoleId ? `• Tu reçois : <@&${c.reglementAcceptRoleId}>` : null,
          c.reglementRemoveRoleId ? `• Tu perds : <@&${c.reglementRemoveRoleId}>` : null,
          !c.reglementAcceptRoleId && !c.reglementRemoveRoleId
            ? '• Confirmation enregistrée'
            : null,
        ].filter(Boolean).join('\n') || '—',
      },
    )
    .setThumbnail(guild.iconURL({ size: 128 }))
    .setFooter({ text: 'ManageX · Accepte le règlement pour continuer' })
    .setTimestamp();
}

function panelBtns() {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('mx_reg_accept')
        .setLabel('Accepter le règlement')
        .setStyle(ButtonStyle.Success)
        .setEmoji('✅'),
    ),
  ];
}

function cfgEmbed(gid) {
  const c = getGuild(gid);
  const preview = (c.reglementText || '').slice(0, 200);
  return configCard(
    '📜 Règlement config',
    'Rédige le règlement, choisis les rôles, puis poste le panel.',
    [
      { name: 'Titre', value: c.reglementTitle || 'Règlement du serveur', inline: true },
      { name: 'Rôle donné', value: role(c.reglementAcceptRoleId), inline: true },
      { name: 'Rôle retiré', value: role(c.reglementRemoveRoleId), inline: true },
      { name: 'Texte', value: preview ? `\`\`\`${preview}${(c.reglementText || '').length > 200 ? '…' : ''}\`\`\`` : '*vide*' },
      { name: 'Panel', value: c.reglementMessageId ? '✅ Posté' : '`pas encore posté`', inline: true },
    ],
    C.primary
  );
}

const command = {
  data: new SlashCommandBuilder()
    .setName('reglementconfig')
    .setDescription('ManageX — configurer le règlement + panel d’acceptation')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  async execute(i) {
    if (!isAdmin(i.member)) {
      return i.reply({ content: '❌ Administrateur requis.', ...EPH });
    }
    await i.reply({
      embeds: [cfgEmbed(i.guild.id)],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('mx_reg_edit').setLabel('Écrire le règlement').setStyle(ButtonStyle.Primary).setEmoji('✏️'),
          new ButtonBuilder().setCustomId('mx_reg_panel').setLabel('Poster le panel').setStyle(ButtonStyle.Success).setEmoji('📨'),
          new ButtonBuilder().setCustomId('mx_reg_refresh').setLabel('Actualiser').setStyle(ButtonStyle.Secondary).setEmoji('🔄'),
        ),
        new ActionRowBuilder().addComponents(
          openBtn('role', 'reg_accept', '✅ Rôle donné à l’acceptation'),
          openBtn('role', 'reg_remove', '🗑️ Rôle retiré à l’acceptation'),
        ),
      ],
      ...EPH,
    });
  },
};

async function refreshPanel(guild) {
  const c = getGuild(guild.id);
  if (!c.reglementChannelId || !c.reglementMessageId) return;
  const chn = await guild.channels.fetch(c.reglementChannelId).catch(() => null);
  const msg = chn && await chn.messages.fetch(c.reglementMessageId).catch(() => null);
  if (msg) {
    await msg.edit({ embeds: [panelEmbed(guild)], components: panelBtns() }).catch(() => null);
  }
}

async function handle(i) {
  const id = i.customId || '';
  if (!id.startsWith('mx_reg_')) return false;
  const gid = i.guild?.id;
  if (!gid) return false;
  const c = getGuild(gid);

  // ── Acceptation (membre) ──
  if (id === 'mx_reg_accept') {
    if (!c.reglementText) {
      await i.reply({ content: '❌ Règlement non configuré.', ...EPH });
      return true;
    }
    const member = i.member;
    const given = [];
    const removed = [];
    try {
      if (c.reglementAcceptRoleId && !member.roles.cache.has(c.reglementAcceptRoleId)) {
        await member.roles.add(c.reglementAcceptRoleId, 'Acceptation règlement ManageX');
        given.push(`<@&${c.reglementAcceptRoleId}>`);
      }
      if (c.reglementRemoveRoleId && member.roles.cache.has(c.reglementRemoveRoleId)) {
        await member.roles.remove(c.reglementRemoveRoleId, 'Acceptation règlement ManageX');
        removed.push(`<@&${c.reglementRemoveRoleId}>`);
      }
    } catch (e) {
      await i.reply({
        content: `❌ Impossible de modifier tes rôles (hiérarchie / permissions) : \`${String(e.message).slice(0, 100)}\``,
        ...EPH,
      });
      return true;
    }
    await i.reply({
      embeds: [
        emb('✅ Règlement accepté', C.success)
          .setDescription(
            [
              `Merci **${i.user.username}** — tu as accepté le règlement.`,
              given.length ? `Rôle reçu : ${given.join(' ')}` : null,
              removed.length ? `Rôle retiré : ${removed.join(' ')}` : null,
            ].filter(Boolean).join('\n')
          ),
      ],
      ...EPH,
    });
    return true;
  }

  // ── Config admin ──
  if (!isAdmin(i.member)) {
    await i.reply({ content: '❌ Admin.', ...EPH });
    return true;
  }

  if (id === 'mx_reg_refresh') {
    await i.update({ embeds: [cfgEmbed(gid)], components: i.message.components });
    return true;
  }

  if (id === 'mx_reg_edit') {
    const modal = new ModalBuilder().setCustomId('mx_modal_reg_edit').setTitle('Règlement du serveur');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('title')
          .setLabel('Titre')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(100)
          .setValue((c.reglementTitle || 'Règlement du serveur').slice(0, 100)),
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('body')
          .setLabel('Texte du règlement')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(4000)
          .setValue((c.reglementText || '').slice(0, 4000) || '1. Respecte les autres\n2. Pas de spam\n3. …'),
      ),
    );
    await i.showModal(modal);
    return true;
  }

  if (id === 'mx_reg_panel') {
    await i.deferReply({ ...EPH });
    try {
      if (!c.reglementText) {
        await i.editReply({ content: '❌ Écris d’abord le règlement (bouton **Écrire le règlement**).' });
        return true;
      }
      const msg = await i.channel.send({
        embeds: [panelEmbed(i.guild)],
        components: panelBtns(),
      });
      setGuild(gid, { reglementChannelId: i.channel.id, reglementMessageId: msg.id });
      await i.editReply({ content: `✅ Panel règlement posté → ${msg.url}` });
    } catch (e) {
      await i.editReply({ content: `❌ ${String(e.message || e).slice(0, 180)}` }).catch(() => null);
    }
    return true;
  }

  return false;
}

async function handleModal(i) {
  if (i.customId !== 'mx_modal_reg_edit') return false;
  if (!isAdmin(i.member)) {
    await i.reply({ content: '❌', ...EPH });
    return true;
  }
  const title = i.fields.getTextInputValue('title').trim().slice(0, 100);
  const body = i.fields.getTextInputValue('body').trim().slice(0, 4000);
  setGuild(i.guild.id, { reglementTitle: title, reglementText: body });
  await refreshPanel(i.guild);
  await i.reply({
    embeds: [
      emb('✅ Règlement enregistré', C.success)
        .setDescription(`**${title}**\n\n${body.slice(0, 500)}${body.length > 500 ? '…' : ''}`),
    ],
    ...EPH,
  });
  return true;
}

module.exports = { command, handle, handleModal, refreshPanel };
