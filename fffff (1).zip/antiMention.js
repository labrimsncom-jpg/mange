/**
 * Anti-mention horaires
 * Pendant la plage configurée : message avec @ → suppression + demande "Urgent ?"
 * Oui → embed urgence | Non / timeout → rien
 *
 * Note Discord : impossible d’intercepter AVANT l’envoi → delete + confirmation.
 */
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder,
  ChannelSelectMenuBuilder, RoleSelectMenuBuilder, ChannelType, MessageFlags,
  ModalBuilder, TextInputBuilder, TextInputStyle,
} = require('discord.js');
const { getGuild, setGuild } = require('./storage.js');
const { isAdmin, isServerStaff } = require('./perms.js');
const { emb, C, card, ch, roles, DIV } = require('./design.js');

const EPH = { flags: MessageFlags.Ephemeral };

/** pending confirmations: messageKey -> data */
const pending = new Map();
const TIMEOUT_MS = 60_000;

function inRestrictedHours(cfg, date = new Date()) {
  if (!cfg.antiMentionEnabled) return false;
  const h = date.getHours(); // heure locale serveur Node
  const start = cfg.antiMentionStartHour ?? 22;
  const end = cfg.antiMentionEndHour ?? 8;
  if (start === end) return true; // 24h
  if (start < end) return h >= start && h < end;
  // plage qui traverse minuit (ex 22 → 8)
  return h >= start || h < end;
}

function hasMention(message, cfg) {
  if (message.mentions.users.size > 0) return true;
  if (message.mentions.roles.size > 0) return true;
  if (!cfg.antiMentionAllowEveryone) {
    if (message.mentions.everyone) return true;
    // @here / @everyone in content
    if (/(^|\s)@(everyone|here)\b/i.test(message.content || '')) return true;
  }
  return false;
}

function canBypass(member, cfg) {
  if (!member) return false;
  if (isAdmin(member) || isServerStaff(member)) return true;
  return (cfg.antiMentionBypassRoleIds || []).some((id) => member.roles.cache.has(id));
}

function formatHours(cfg) {
  const s = cfg.antiMentionStartHour ?? 22;
  const e = cfg.antiMentionEndHour ?? 8;
  return `**${String(s).padStart(2, '0')}h** → **${String(e).padStart(2, '0')}h**`;
}

async function onMessage(message) {
  if (!message.guild || message.author.bot) return;
  const cfg = getGuild(message.guild.id);
  if (!cfg.antiMentionEnabled) return;
  if (!inRestrictedHours(cfg)) return;
  if (!hasMention(message, cfg)) return;
  if (canBypass(message.member, cfg)) return;

  const content = (message.content || '').slice(0, 1500);
  const author = message.author;
  const channelId = message.channel.id;
  const mentionedUsers = [...message.mentions.users.values()].map((u) => `${u} (\`${u.id}\`)`);
  const mentionedRoles = [...message.mentions.roles.values()].map((r) => `${r}`);
  const everyone = message.mentions.everyone;

  // Supprime le message original
  await message.delete().catch(() => null);

  const id = `${message.guild.id}_${author.id}_${Date.now().toString(36)}`;
  pending.set(id, {
    guildId: message.guild.id,
    channelId,
    authorId: author.id,
    content,
    mentionedUsers,
    mentionedRoles,
    everyone,
    createdAt: Date.now(),
  });

  const prompt = card({
    title: '🔇 Mention hors horaires',
    color: C.warn,
    description: [
      `### ${author}, ta mention a été **bloquée**`,
      '',
      `Les mentions sont restreintes de ${formatHours(cfg)}.`,
      '',
      '**Est-ce **urgent** ?**',
      '• **Oui** → un embed d’urgence sera publié (avec ton texte + les @)',
      '• **Non** → le message reste supprimé',
      '',
      `_${Math.floor(TIMEOUT_MS / 1000)}s pour répondre_`,
    ].join('\n'),
    fields: [
      {
        name: '📝 Ton message',
        value: content ? `\`\`\`\n${content.slice(0, 500)}\n\`\`\`` : '_vide / média seul_',
      },
    ],
    footer: 'ManageX · Anti-mention',
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`mx_am_yes_${id}`).setLabel('Oui, c’est urgent').setStyle(ButtonStyle.Danger).setEmoji('🚨'),
    new ButtonBuilder().setCustomId(`mx_am_no_${id}`).setLabel('Non').setStyle(ButtonStyle.Secondary).setEmoji('✅'),
  );

  let promptMsg;
  try {
    promptMsg = await message.channel.send({
      content: `${author}`,
      embeds: [prompt],
      components: [row],
    });
  } catch {
    pending.delete(id);
    return;
  }

  // Timeout
  setTimeout(async () => {
    const data = pending.get(id);
    if (!data) return;
    pending.delete(id);
    try {
      await promptMsg.edit({
        content: null,
        embeds: [card({
          title: '🔇 Mention annulée',
          color: C.dark,
          description: `${author} n’a pas confirmé l’urgence — message resté supprimé.`,
          footer: 'ManageX · Anti-mention',
        })],
        components: [],
      });
      setTimeout(() => promptMsg.delete().catch(() => null), 8000);
    } catch {}
  }, TIMEOUT_MS);
}

async function postUrgentEmbed(client, data) {
  const guild = client.guilds.cache.get(data.guildId) || await client.guilds.fetch(data.guildId).catch(() => null);
  if (!guild) return;
  const cfg = getGuild(guild.id);
  const targetId = cfg.antiMentionUrgentChannelId || cfg.logChannelId || data.channelId;
  const chn = await guild.channels.fetch(targetId).catch(() => null);
  if (!chn?.send) return;

  const mentions = [
    ...(data.mentionedUsers || []),
    ...(data.mentionedRoles || []),
    data.everyone ? '@everyone / @here' : null,
  ].filter(Boolean).join('\n') || '_Aucune cible parsée_';

  const embed = new EmbedBuilder()
    .setColor(C.danger)
    .setAuthor({ name: 'Urgence — mention hors horaires' })
    .setTitle('🚨 Message urgent autorisé')
    .setDescription(
      [
        '### Contenu signalé comme urgent',
        '',
        data.content ? `>>> ${data.content.slice(0, 1500)}` : '_Message sans texte_',
        '',
        DIV,
      ].join('\n')
    )
    .addFields(
      { name: '👤 Auteur', value: `<@${data.authorId}>`, inline: true },
      { name: '📍 Salon d’origine', value: `<#${data.channelId}>`, inline: true },
      { name: '🕐 Heure', value: `<t:${Math.floor(Date.now() / 1000)}:f>`, inline: true },
      { name: '📣 Mentions concernées', value: mentions.slice(0, 1024) },
      { name: '⏰ Plage anti-mention', value: formatHours(cfg), inline: true },
    )
    .setFooter({ text: 'ManageX · Anti-mention · urgence confirmée' })
    .setTimestamp();

  await chn.send({
    content: data.everyone ? null : undefined,
    embeds: [embed],
  }).catch(() => null);
}

async function handle(i) {
  const id = i.customId || '';
  if (!id.startsWith('mx_am_')) return false;

  // Config handlers
  if (id.startsWith('mx_am_cfg_') || id === 'mx_am_hours' || id === 'mx_am_toggle') {
    if (!isAdmin(i.member)) {
      await i.reply({ content: '❌ Admin.', ...EPH });
      return true;
    }
    const gid = i.guild.id;
    const cfg = getGuild(gid);

    if (id === 'mx_am_toggle') {
      setGuild(gid, { antiMentionEnabled: !cfg.antiMentionEnabled });
      const on = !cfg.antiMentionEnabled;
      await i.reply({ content: on ? '✅ Anti-mention **activé**.' : '🔴 Anti-mention **désactivé**.', ...EPH });
      return true;
    }
    if (id === 'mx_am_hours') {
      const modal = new ModalBuilder().setCustomId('mx_modal_am_hours').setTitle('Plage anti-mention');
      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('start').setLabel('Heure début (0-23)').setStyle(TextInputStyle.Short)
            .setValue(String(cfg.antiMentionStartHour ?? 22)).setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('end').setLabel('Heure fin (0-23)').setStyle(TextInputStyle.Short)
            .setValue(String(cfg.antiMentionEndHour ?? 8)).setRequired(true)
        ),
      );
      await i.showModal(modal);
      return true;
    }
    if (id === 'mx_am_cfg_urgent') {
      setGuild(gid, { antiMentionUrgentChannelId: i.values[0] || null });
      await i.reply({ content: i.values[0] ? `✅ Salon urgence : <#${i.values[0]}>` : '✅ Salon urgence retiré (logs / salon d’origine).', ...EPH });
      return true;
    }
    if (id === 'mx_am_cfg_bypass') {
      setGuild(gid, { antiMentionBypassRoleIds: i.values || [] });
      await i.reply({ content: `✅ Rôles bypass : **${(i.values || []).length}**`, ...EPH });
      return true;
    }
  }

  // Urgent yes / no
  const mYes = id.match(/^mx_am_yes_(.+)$/);
  const mNo = id.match(/^mx_am_no_(.+)$/);
  if (mYes || mNo) {
    const key = (mYes || mNo)[1];
    const data = pending.get(key);
    if (!data) {
      await i.update({ content: '⏳ Expiré ou déjà traité.', embeds: [], components: [] }).catch(() =>
        i.reply({ content: '⏳ Expiré.', ...EPH })
      );
      return true;
    }
    // Only author can confirm
    if (i.user.id !== data.authorId && !isAdmin(i.member)) {
      await i.reply({ content: '❌ Seul l’auteur du message peut confirmer.', ...EPH });
      return true;
    }
    pending.delete(key);

    if (mNo) {
      await i.update({
        content: null,
        embeds: [card({
          title: '✅ Mentions non urgentes',
          color: C.success,
          description: 'Le message reste **supprimé**. Merci de respecter les horaires.',
          footer: 'ManageX · Anti-mention',
        })],
        components: [],
      });
      setTimeout(() => i.message.delete().catch(() => null), 6000);
      return true;
    }

    // Yes urgent
    await i.update({
      content: null,
      embeds: [card({
        title: '🚨 Urgence confirmée',
        color: C.danger,
        description: 'Ton message est publié en **embed urgence**.',
        footer: 'ManageX · Anti-mention',
      })],
      components: [],
    });
    await postUrgentEmbed(i.client, data);
    setTimeout(() => i.message.delete().catch(() => null), 8000);
    return true;
  }

  return false;
}

async function handleModal(i) {
  if (i.customId !== 'mx_modal_am_hours') return false;
  if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
  let start = parseInt(i.fields.getTextInputValue('start'), 10);
  let end = parseInt(i.fields.getTextInputValue('end'), 10);
  if (Number.isNaN(start) || start < 0 || start > 23) start = 22;
  if (Number.isNaN(end) || end < 0 || end > 23) end = 8;
  setGuild(i.guild.id, { antiMentionStartHour: start, antiMentionEndHour: end });
  await i.reply({
    content: `✅ Plage anti-mention : **${String(start).padStart(2, '0')}h** → **${String(end).padStart(2, '0')}h**`,
    ...EPH,
  });
  return true;
}

/** UI block for serverconfig follow-up */
function configComponents() {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('mx_am_toggle').setLabel('Activer / Désactiver').setStyle(ButtonStyle.Primary).setEmoji('🔇'),
      new ButtonBuilder().setCustomId('mx_am_hours').setLabel('Plage horaire').setStyle(ButtonStyle.Secondary).setEmoji('⏰'),
    ),
    new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder().setCustomId('mx_am_cfg_urgent').setPlaceholder('🚨 Salon embeds urgence…')
        .addChannelTypes(ChannelType.GuildText).setMinValues(0).setMaxValues(1)
    ),
    new ActionRowBuilder().addComponents(
      new RoleSelectMenuBuilder().setCustomId('mx_am_cfg_bypass').setPlaceholder('Rôles qui peuvent mentionner quand même…')
        .setMinValues(0).setMaxValues(10)
    ),
  ];
}

function configEmbed(gid) {
  const c = getGuild(gid);
  return card({
    title: '🔇 Anti-mention (horaires)',
    color: C.warn,
    description: [
      '### Mentions restreintes selon l’heure',
      '',
      'Pendant la plage configurée :',
      '1. Message avec @ **supprimé**',
      '2. Le bot demande : **Urgent ?**',
      '3. **Oui** → embed urgence (texte + @)',
      '4. **Non** / timeout → rien',
      '',
      '_Discord ne permet pas de bloquer avant l’envoi — suppression immédiate + confirmation._',
    ].join('\n'),
    fields: [
      { name: 'Statut', value: c.antiMentionEnabled ? '🟢 Activé' : '🔴 Désactivé', inline: true },
      { name: 'Plage', value: formatHours(c), inline: true },
      { name: 'Salon urgence', value: ch(c.antiMentionUrgentChannelId) || ch(c.logChannelId), inline: true },
      { name: 'Bypass', value: roles(c.antiMentionBypassRoleIds) },
    ],
    footer: 'ManageX · Anti-mention',
  });
}

module.exports = {
  onMessage,
  handle,
  handleModal,
  configComponents,
  configEmbed,
  inRestrictedHours,
  formatHours,
};
