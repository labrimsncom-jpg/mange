const fs = require('fs');
const path = require('path');
const DATA = path.join(__dirname, 'data');
if (!fs.existsSync(DATA)) fs.mkdirSync(DATA, { recursive: true });

function read(file, fb) {
  try {
    const p = path.join(DATA, file);
    if (!fs.existsSync(p)) return fb;
    const raw = fs.readFileSync(p, 'utf8');
    if (!raw.trim()) return fb;
    return JSON.parse(raw);
  } catch (e) {
    console.warn('[storage read]', file, e.message);
    return fb;
  }
}

const BACKUP_DIR = path.join(DATA, 'backups');
if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

const CRITICAL = new Set(['guilds.json', 'global.json', 'tickets.json', 'services.json', 'absences.json', 'banreg.json', 'xp.json', 'forms.json']);

/** Écriture atomique + backup des fichiers critiques */
function write(file, data) {
  const p = path.join(DATA, file);
  const tmp = p + '.tmp';
  const payload = JSON.stringify(data, null, 2);
  fs.writeFileSync(tmp, payload);
  fs.renameSync(tmp, p);
  if (CRITICAL.has(file)) {
    try {
      const bak = path.join(BACKUP_DIR, file + '.bak');
      fs.writeFileSync(bak, payload);
      // copie horodatée légère (1 par jour max par fichier)
      const day = new Date().toISOString().slice(0, 10);
      const daily = path.join(BACKUP_DIR, `${file}.${day}.bak`);
      if (!fs.existsSync(daily)) fs.writeFileSync(daily, payload);
    } catch (e) {
      console.warn('[storage backup]', file, e.message);
    }
  }
}

/** Au démarrage : si un fichier critique manque mais qu’un .bak existe → restore */
function restoreFromBackup() {
  for (const file of CRITICAL) {
    const p = path.join(DATA, file);
    const bak = path.join(BACKUP_DIR, file + '.bak');
    if (!fs.existsSync(p) && fs.existsSync(bak)) {
      try {
        fs.copyFileSync(bak, p);
        console.log(`[storage] Restauré ${file} depuis backups/`);
      } catch (e) {
        console.warn('[storage restore]', file, e.message);
      }
    }
  }
}
restoreFromBackup();

const ARRAY_KEYS = [
  'autoRoleIds', 'serverStaffRoleIds', 'ticketSupportRoleIds', 'ticketCategories',
  'autoPing', 'autoAnnounce', 'suggestReviewRoleIds', 'avisStaffRoleIds',
  'antiMentionBypassRoleIds', 'levelRewardRoles', 'formQuestions', 'formAcceptRoleIds',
];

const GUILD_DEFAULTS = {
  welcomeChannelId: null,
  welcomeMessage: 'Bienvenue {user} sur **{server}** !',
  welcomeColor: 0x57f287,
  leaveChannelId: null,
  leaveMessage: '{user} a quitté le serveur.',
  leaveColor: 0xed4245,
  autoRoleIds: [],
  logChannelId: null,
  autoPing: [],
  autoAnnounce: [],

  serverStaffRoleIds: [],
  serviceChannelId: null,
  serviceMessageId: null,
  serviceRoleId: null,
  horsServiceRoleId: null,
  forceServiceRoleId: null,
  serviceMaxHours: 0,        // 0 = pas de limite / pas d'auto-warn
  serviceWarnRoleId: null,   // rôle warn si dépassement
  serviceAutoEnd: true,      // retire automatiquement du service
  serviceWarnLogChannelId: null,

  absenceChannelId: null,
  absenceMessageId: null,
  absenceRoleId: null,
  banregChannelId: null,
  banregMessageId: null,

  ticketCategoryId: null,
  ticketLogChannelId: null,
  ticketSupportRoleIds: [],
  ticketPanelChannelId: null,
  ticketPanelMessageId: null,
  ticketCategories: [
    { id: 'aide', label: 'Aide', emoji: '💬', closed: false, supportRoleIds: [] },
    { id: 'bug', label: 'Bug', emoji: '🐛', closed: false, supportRoleIds: [] },
  ],
  ticketCounter: 0,
  maxTicketsPerUser: 0, // 0 = illimité par user
  formChannelId: null,
  formPanelChannelId: null,
  formPanelMessageId: null,
  formAcceptRoleId: null,
  formReviewerRoleIds: [],
  formTitle: 'Candidature',
  formClosed: false,

  // Règlement
  reglementText: '',
  reglementTitle: 'Règlement du serveur',
  reglementAcceptRoleId: null,   // rôle donné à l'acceptation
  reglementRemoveRoleId: null,   // rôle retiré à l'acceptation
  reglementChannelId: null,
  reglementMessageId: null,
  reglementColor: 0x5865f2,

  formPageSize: 3, // questions par page (1-5)


  formQuestions: [
    { id: 'q1', label: 'Pourquoi postuler ?', type: 'libre', options: [], exact: null },
  ],

  ticketUnlimited: true,
  ticketOverflowParents: [], // catégories Discord supplémentaires si >50 salons

  ticketInactivityEnabled: true,
  ticketWarnAfterHours: 24,       // après Xh d'inactivité → message "toujours besoin ?"
  ticketCloseAfterWarnHours: 24,  // après le warning sans réponse → fermeture


  gwRequiredRoleId: null,
  gwPingRoleId: null,
  gwRewardRoleId: null,

  antiMentionEnabled: false,
  antiMentionStartHour: 22,
  antiMentionEndHour: 8,
  antiMentionBypassRoleIds: [],
  antiMentionUrgentChannelId: null,
  antiMentionAllowEveryone: false,

  reportChannelId: null,
  reportPanelChannelId: null,
  reportPanelMessageId: null,
  avisStaffChannelId: null,
  avisStaffRoleIds: [],
  avisServerChannelId: null,
  suggestChannelId: null,
  suggestPanelChannelId: null,
  suggestPanelMessageId: null,
  suggestReviewRoleIds: [],

  // niveaux
  levelsEnabled: true,
  levelsChannelId: null, // salon annonces niveau (null = salon du message)
  levelsXpMin: 15,
  levelsXpMax: 25,
  levelsCooldownSec: 60,
  levelRewardRoles: [], // [{ level: 5, roleId: '...' }]
};

function getGlobal() {
  const g = read('global.json', null);
  if (g) return g;
  const init = {
    ownerIds: [],
    coOwnerIds: [],
    developerIds: [],
    staffIds: [],
    supportInvite: '',
    supportGuildId: null,
    bilanChannelId: null,
    bilanHour: 21,
    lastBilanDate: null,
    stats: {
      serversJoined: 0,
      serversLeft: 0,
      commandsUsed: 0,
      ticketsOpened: 0,
      ticketsClosed: 0,
    },
  };
  write('global.json', init);
  return init;
}

function setGlobal(patch) {
  // merge uniquement le patch sur le fichier, pas les defaults
  const prev = read('global.json', {});
  const next = { ...prev, ...patch };
  if (patch.stats && prev.stats) next.stats = { ...prev.stats, ...patch.stats };
  write('global.json', next);
  return getGlobal();
}

/**
 * Lecture : defaults + sauvegarde (la sauvegarde gagne toujours).
 * Les tableaux vides sauvegardés sont conservés.
 */
function getGuild(gid) {
  const all = read('guilds.json', {});
  const saved = all[gid] && typeof all[gid] === 'object' ? all[gid] : {};
  const merged = { ...GUILD_DEFAULTS, ...saved };
  for (const key of ARRAY_KEYS) {
    if (Object.prototype.hasOwnProperty.call(saved, key)) {
      merged[key] = Array.isArray(saved[key]) ? saved[key] : GUILD_DEFAULTS[key];
    }
  }
  return merged;
}

/**
 * Écriture : patch UNIQUEMENT sur les données déjà en fichier.
 * → ne réécrit PAS tous les defaults à chaque set (évite d’écraser).
 */
function setGuild(gid, patch) {
  const all = read('guilds.json', {});
  const prev = all[gid] && typeof all[gid] === 'object' ? all[gid] : {};
  const next = { ...prev };
  for (const [k, v] of Object.entries(patch || {})) {
    if (v === undefined) continue; // ne jamais effacer avec undefined
    next[k] = v;
  }
  all[gid] = next;
  write('guilds.json', all);
  return getGuild(gid);
}

function bag(file, gid) {
  const all = read(file, {});
  if (file.includes('service')) return all[gid] || {};
  return all[gid] || [];
}

function setBag(file, gid, data) {
  const all = read(file, {});
  all[gid] = data;
  write(file, all);
}

module.exports = {
  read, write, DATA, GUILD_DEFAULTS, ARRAY_KEYS, restoreFromBackup,
  getGlobal, setGlobal, getGuild, setGuild, bag, setBag,
};
