/**
 * Sélecteurs paginés salons / rôles (page suivante / précédente)
 * customId:
 *  mx_pg_open_ch:KEY | mx_pg_open_role:KEY
 *  mx_pg_ch:KEY:PAGE | mx_pg_role:KEY:PAGE
 *  mx_pg_sel_ch:KEY | mx_pg_sel_role:KEY
 *  mx_pg_clear:KEY | mx_pg_done:KEY (multi)
 */
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder,
  ChannelType, MessageFlags, EmbedBuilder,
} = require('discord.js');
const { getGuild, setGuild } = require('./storage.js');
const { emb, C } = require('./design.js');

const EPH = { flags: MessageFlags.Ephemeral };
const PER_PAGE = 20;
const multiState = new Map(); // `${userId}:${key}` -> string[]

/** Applique le choix selon la clé */
function applyPick(key, guildId, value, multiValues) {
  const g = getGuild(guildId);
  switch (key) {
    // server
    case 'srv_welcome': setGuild(guildId, { welcomeChannelId: value }); break;
    case 'srv_leave': setGuild(guildId, { leaveChannelId: value }); break;
    case 'srv_log': setGuild(guildId, { logChannelId: value }); break;
    case 'srv_autorole': setGuild(guildId, { autoRoleIds: multiValues || [] }); break;
    // tickets
    case 'tk_cat': setGuild(guildId, { ticketCategoryId: value }); break;
    case 'tk_log': setGuild(guildId, { ticketLogChannelId: value }); break;
    case 'tk_roles': setGuild(guildId, { ticketSupportRoleIds: multiValues || [] }); break;
    // staff
    case 'stf_roles': setGuild(guildId, { serverStaffRoleIds: multiValues || [] }); break;
    case 'stf_on': setGuild(guildId, { serviceRoleId: value }); break;
    case 'stf_off': setGuild(guildId, { horsServiceRoleId: value }); break;
    case 'stf_abs': setGuild(guildId, { absenceRoleId: value }); break;
    case 'stf_force': setGuild(guildId, { forceServiceRoleId: value }); break;
    case 'stf_warn': setGuild(guildId, { serviceWarnRoleId: value }); break;
    case 'stf_banreg': setGuild(guildId, { banregChannelId: value }); break;
    // servavis
    case 'av_staff': setGuild(guildId, { avisStaffChannelId: value }); break;
    case 'av_server': setGuild(guildId, { avisServerChannelId: value }); break;
    case 'av_suggest': setGuild(guildId, { suggestChannelId: value }); break;
    case 'av_report': setGuild(guildId, { reportChannelId: value }); break;
    case 'av_suggest_roles': setGuild(guildId, { suggestReviewRoleIds: multiValues || [] }); break;
    case 'av_staff_roles': setGuild(guildId, { avisStaffTargetRoleIds: multiValues || [] }); break;
    // form
    case 'form_ch': setGuild(guildId, { formChannelId: value }); break;
    case 'form_accept': setGuild(guildId, { formAcceptRoleId: value }); break;
    case 'form_review': setGuild(guildId, { formReviewerRoleIds: multiValues || [] }); break;
    // levels
    case 'lvl_ch': setGuild(guildId, { levelsChannelId: value }); break;
    // giveaway
    case 'gw_req': setGuild(guildId, { gwRequiredRoleId: value }); break;
    case 'gw_ping': setGuild(guildId, { gwPingRoleId: value }); break;
    case 'gw_reward': setGuild(guildId, { gwRewardRoleId: value }); break;
    // antimention
    case 'am_urgent': setGuild(guildId, { antiMentionUrgentChannelId: value }); break;
    case 'am_bypass': setGuild(guildId, { antiMentionBypassRoleIds: multiValues || [] }); break;
    // bilan
    case 'bilan_ch': setGuild(guildId, { bilanChannelId: value }); break;
    case 'reg_accept': setGuild(guildId, { reglementAcceptRoleId: value }); break;
    case 'reg_remove': setGuild(guildId, { reglementRemoveRoleId: value }); break;
    // setup aliases
    case 'setup_welcome': setGuild(guildId, { welcomeChannelId: value }); break;
    case 'setup_leave': setGuild(guildId, { leaveChannelId: value }); break;
    case 'setup_log': setGuild(guildId, { logChannelId: value }); break;
    case 'setup_tklog': setGuild(guildId, { ticketLogChannelId: value }); break;
    case 'setup_tkcat': setGuild(guildId, { ticketCategoryId: value }); break;
    default:
      return false;
  }
  return true;
}

function labelFor(key) {
  const map = {
    srv_welcome: 'Salon bienvenue', srv_leave: 'Salon départ', srv_log: 'Salon logs',
    srv_autorole: 'Auto-rôles', tk_cat: 'Catégorie tickets', tk_log: 'Logs tickets',
    tk_roles: 'Rôles support tickets', stf_roles: 'Rôles staff serveur',
    stf_on: 'Rôle EN service', stf_off: 'Rôle HORS service', stf_abs: 'Rôle absence',
    stf_force: 'Rôle force fin service', stf_warn: 'Rôle warn service', stf_banreg: 'Salon registre ban',
    av_staff: 'Salon avis staff', av_server: 'Salon avis serveur', av_suggest: 'Salon suggestions',
    av_report: 'Salon reports', av_suggest_roles: 'Rôles review suggestions',
    av_staff_roles: 'Rôles ciblés avis staff', form_ch: 'Salon candidatures',
    form_accept: 'Rôle si accepté', form_review: 'Rôles reviewers formulaire',
    lvl_ch: 'Salon niveaux', gw_req: 'Rôle requis giveaway', gw_ping: 'Rôle ping GW',
    gw_reward: 'Rôle récompense GW', am_urgent: 'Salon urgence anti-mention',
    am_bypass: 'Rôles bypass anti-mention', bilan_ch: 'Salon bilan',
    reg_accept: 'Rôle donné (règlement)', reg_remove: 'Rôle retiré (règlement)',
    setup_welcome: 'Salon bienvenue', setup_leave: 'Salon départ', setup_log: 'Salon logs',
    setup_tklog: 'Logs tickets', setup_tkcat: 'Catégorie tickets',
  };
  return map[key] || key;
}

function isMulti(key) {
  return [
    'srv_autorole', 'tk_roles', 'stf_roles', 'av_suggest_roles', 'av_staff_roles',
    'form_review', 'am_bypass',
  ].includes(key);
}

function isCategory(key) {
  return key === 'tk_cat' || key === 'setup_tkcat';
}

function listChannels(guild, key) {
  let cols = [...guild.channels.cache.values()];
  if (isCategory(key)) {
    cols = cols.filter((c) => c.type === ChannelType.GuildCategory);
  } else {
    cols = cols.filter((c) => c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement);
  }
  cols.sort((a, b) => (a.rawPosition ?? 0) - (b.rawPosition ?? 0) || a.name.localeCompare(b.name));
  return cols;
}

function listRoles(guild) {
  return [...guild.roles.cache.values()]
    .filter((r) => r.id !== guild.id)
    .sort((a, b) => b.position - a.position);
}

function stateKey(userId, key) {
  return `${userId}:${key}`;
}

async function renderChannelPage(i, key, page) {
  const channels = listChannels(i.guild, key);
  const maxPage = Math.max(0, Math.ceil(channels.length / PER_PAGE) - 1);
  page = Math.max(0, Math.min(maxPage, page));
  const slice = channels.slice(page * PER_PAGE, page * PER_PAGE + PER_PAGE);

  const embed = emb(`📑 ${labelFor(key)}`, C.info)
    .setDescription(
      [
        `**${channels.length}** salon(s) · page **${page + 1}/${maxPage + 1}**`,
        '',
        slice.map((c, n) => `\`${String(page * PER_PAGE + n + 1).padStart(2, '0')}.\` ${c}`).join('\n') || '_Aucun salon_',
        '',
        '_Choisis un salon dans le menu, ou change de page._',
      ].join('\n')
    );

  const opts = slice.map((c) => ({
    label: c.name.slice(0, 100),
    value: c.id,
    description: isCategory(key) ? 'Catégorie' : `#${c.name}`.slice(0, 50),
  }));

  const rows = [];
  if (opts.length) {
    rows.push(new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(`mx_pg_sel_ch:${key}`)
        .setPlaceholder('Choisir un salon…')
        .addOptions(opts),
    ));
  }
  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`mx_pg_ch:${key}:${page - 1}`).setLabel('Précédent').setStyle(ButtonStyle.Secondary).setEmoji('◀️').setDisabled(page <= 0),
    new ButtonBuilder().setCustomId(`mx_pg_ch:${key}:${page + 1}`).setLabel('Suivant').setStyle(ButtonStyle.Secondary).setEmoji('▶️').setDisabled(page >= maxPage),
    new ButtonBuilder().setCustomId(`mx_pg_clear:${key}`).setLabel('Retirer').setStyle(ButtonStyle.Danger).setEmoji('🗑️'),
  ));

  const payload = { embeds: [embed], components: rows, ...EPH };
  if (i.replied || i.deferred) await i.editReply(payload).catch(() => i.followUp(payload));
  else if (i.isMessageComponent()) await i.update(payload).catch(async () => { await i.reply(payload); });
  else await i.reply(payload);
}

async function renderRolePage(i, key, page) {
  const roles = listRoles(i.guild);
  const maxPage = Math.max(0, Math.ceil(roles.length / PER_PAGE) - 1);
  page = Math.max(0, Math.min(maxPage, page));
  const slice = roles.slice(page * PER_PAGE, page * PER_PAGE + PER_PAGE);
  const multi = isMulti(key);
  const sk = stateKey(i.user.id, key);
  if (multi && !multiState.has(sk)) multiState.set(sk, []);
  const selected = multi ? multiState.get(sk) : [];

  const embed = emb(`🎭 ${labelFor(key)}`, C.info)
    .setDescription(
      [
        `**${roles.length}** rôle(s) · page **${page + 1}/${maxPage + 1}**`,
        multi ? `Sélection : **${selected.length}** → ${selected.map((id) => `<@&${id}>`).join(' ') || '*vide*'}` : '',
        '',
        slice.map((r, n) => {
          const mark = selected.includes(r.id) ? '✅' : '▫️';
          return `${mark} \`${String(page * PER_PAGE + n + 1).padStart(2, '0')}.\` ${r}`;
        }).join('\n') || '_Aucun rôle_',
        '',
        multi ? '_Sélectionne pour ajouter/retirer · **Terminer** pour valider._' : '_Choisis un rôle dans le menu._',
      ].filter(Boolean).join('\n')
    );

  const opts = slice.map((r) => ({
    label: r.name.slice(0, 100),
    value: r.id,
    description: selected.includes(r.id) ? 'Déjà sélectionné' : `Pos. ${r.position}`.slice(0, 50),
  }));

  const rows = [];
  if (opts.length) {
    rows.push(new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(`mx_pg_sel_role:${key}`)
        .setPlaceholder(multi ? 'Ajouter / retirer un rôle…' : 'Choisir un rôle…')
        .setMinValues(1)
        .setMaxValues(multi ? Math.min(10, opts.length) : 1)
        .addOptions(opts),
    ));
  }
  const nav = [
    new ButtonBuilder().setCustomId(`mx_pg_role:${key}:${page - 1}`).setLabel('Précédent').setStyle(ButtonStyle.Secondary).setEmoji('◀️').setDisabled(page <= 0),
    new ButtonBuilder().setCustomId(`mx_pg_role:${key}:${page + 1}`).setLabel('Suivant').setStyle(ButtonStyle.Secondary).setEmoji('▶️').setDisabled(page >= maxPage),
    new ButtonBuilder().setCustomId(`mx_pg_clear:${key}`).setLabel('Vider').setStyle(ButtonStyle.Danger).setEmoji('🗑️'),
  ];
  if (multi) {
    nav.push(new ButtonBuilder().setCustomId(`mx_pg_done:${key}`).setLabel('Terminer').setStyle(ButtonStyle.Success).setEmoji('✅'));
  }
  rows.push(new ActionRowBuilder().addComponents(nav));

  const payload = { embeds: [embed], components: rows, ...EPH };
  if (i.replied || i.deferred) await i.editReply(payload).catch(() => i.followUp(payload));
  else if (i.isMessageComponent()) await i.update(payload).catch(async () => { await i.reply(payload); });
  else await i.reply(payload);
}

/** Bouton d’ouverture standard pour les configs */
function openBtn(kind, key, label) {
  return new ButtonBuilder()
    .setCustomId(kind === 'ch' ? `mx_pg_open_ch:${key}` : `mx_pg_open_role:${key}`)
    .setLabel(label.slice(0, 80))
    .setStyle(ButtonStyle.Primary)
    .setEmoji(kind === 'ch' ? '📑' : '🎭');
}

async function handle(i) {
  const id = i.customId || '';
  if (!id.startsWith('mx_pg_')) return false;

  let m = id.match(/^mx_pg_open_ch:(.+)$/);
  if (m) {
    await renderChannelPage(i, m[1], 0);
    return true;
  }
  m = id.match(/^mx_pg_open_role:(.+)$/);
  if (m) {
    const key = m[1];
    if (isMulti(key)) {
      // préremplir depuis config
      const g = getGuild(i.guild.id);
      const pre = {
        srv_autorole: g.autoRoleIds,
        tk_roles: g.ticketSupportRoleIds,
        stf_roles: g.serverStaffRoleIds,
        av_suggest_roles: g.suggestReviewRoleIds,
        av_staff_roles: g.avisStaffTargetRoleIds,
        form_review: g.formReviewerRoleIds,
        am_bypass: g.antiMentionBypassRoleIds,
      }[key] || [];
      multiState.set(stateKey(i.user.id, key), [...pre]);
    }
    await renderRolePage(i, key, 0);
    return true;
  }
  m = id.match(/^mx_pg_ch:([^:]+):(\d+)$/);
  if (m) {
    await renderChannelPage(i, m[1], parseInt(m[2], 10));
    return true;
  }
  m = id.match(/^mx_pg_role:([^:]+):(\d+)$/);
  if (m) {
    await renderRolePage(i, m[1], parseInt(m[2], 10));
    return true;
  }
  m = id.match(/^mx_pg_sel_ch:(.+)$/);
  if (m) {
    const key = m[1];
    const value = i.values[0];
    applyPick(key, i.guild.id, value, null);
    await i.update({
      embeds: [emb('✅ Salon défini', C.success).setDescription(`**${labelFor(key)}** → <#${value}>`)],
      components: [],
    }).catch(() => i.reply({ content: `✅ <#${value}>`, ...EPH }));
    return true;
  }
  m = id.match(/^mx_pg_sel_role:(.+)$/);
  if (m) {
    const key = m[1];
    if (isMulti(key)) {
      const sk = stateKey(i.user.id, key);
      let sel = multiState.get(sk) || [];
      for (const rid of i.values) {
        if (sel.includes(rid)) sel = sel.filter((x) => x !== rid);
        else sel.push(rid);
      }
      multiState.set(sk, sel);
      // rester sur la même page approx
      await renderRolePage(i, key, 0);
      return true;
    }
    const value = i.values[0];
    applyPick(key, i.guild.id, value, null);
    await i.update({
      embeds: [emb('✅ Rôle défini', C.success).setDescription(`**${labelFor(key)}** → <@&${value}>`)],
      components: [],
    }).catch(() => i.reply({ content: `✅ <@&${value}>`, ...EPH }));
    return true;
  }
  m = id.match(/^mx_pg_clear:(.+)$/);
  if (m) {
    const key = m[1];
    if (isMulti(key)) {
      multiState.set(stateKey(i.user.id, key), []);
      applyPick(key, i.guild.id, null, []);
    } else {
      applyPick(key, i.guild.id, null, null);
      // set null fields - applyPick with null may need fix
      const nullMap = {
        srv_welcome: 'welcomeChannelId', srv_leave: 'leaveChannelId', srv_log: 'logChannelId',
        tk_cat: 'ticketCategoryId', tk_log: 'ticketLogChannelId', stf_on: 'serviceRoleId',
        stf_off: 'horsServiceRoleId', stf_abs: 'absenceRoleId', stf_force: 'forceServiceRoleId',
        stf_warn: 'serviceWarnRoleId', stf_banreg: 'banregChannelId', av_staff: 'avisStaffChannelId',
        av_server: 'avisServerChannelId', av_suggest: 'suggestChannelId', av_report: 'reportChannelId',
        form_ch: 'formChannelId', form_accept: 'formAcceptRoleId', lvl_ch: 'levelsChannelId',
        gw_req: 'gwRequiredRoleId', gw_ping: 'gwPingRoleId', gw_reward: 'gwRewardRoleId',
        am_urgent: 'antiMentionUrgentChannelId', bilan_ch: 'bilanChannelId', reg_accept: 'reglementAcceptRoleId', reg_remove: 'reglementRemoveRoleId',
      };
      if (nullMap[key]) setGuild(i.guild.id, { [nullMap[key]]: null });
    }
    await i.update({
      embeds: [emb('🗑️ Retiré', C.warn).setDescription(`**${labelFor(key)}** réinitialisé.`)],
      components: [],
    }).catch(() => null);
    return true;
  }
  m = id.match(/^mx_pg_done:(.+)$/);
  if (m) {
    const key = m[1];
    const sel = multiState.get(stateKey(i.user.id, key)) || [];
    applyPick(key, i.guild.id, null, sel);
    multiState.delete(stateKey(i.user.id, key));
    await i.update({
      embeds: [
        emb('✅ Rôles enregistrés', C.success)
          .setDescription(`**${labelFor(key)}**\n${sel.map((id) => `<@&${id}>`).join(' ') || '*aucun*'}`),
      ],
      components: [],
    }).catch(() => null);
    return true;
  }
  return false;
}

module.exports = { handle, openBtn, renderChannelPage, renderRolePage, labelFor };
