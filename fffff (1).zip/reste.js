/**
 * /reste — tout ce qui n'est pas dans les configs principales
 * (ex-ManageX : utilitaires, modo, XP, AFK, etc.)
 */
const {
  SlashCommandBuilder, PermissionFlagsBits, MessageFlags, ChannelType,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder,
  UserSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle,
  EmbedBuilder,
} = require('discord.js');
const { getGuild, setGuild, bag, setBag, read, write } = require('./storage.js');
const { isAdmin, isServerStaff } = require('./perms.js');
const { emb, C } = require('./design.js');
const { E, CFG } = require('./emojis.js');

const EPH = { flags: MessageFlags.Ephemeral };

// ── AFK ──
function getAfk() { return read('afk.json', {}); }
function setAfkMap(m) { write('afk.json', m); }

// ── XP / niveaux ──
function getXp(gid) { return read('xp.json', {})[gid] || {}; }
function setXp(gid, data) {
  const all = read('xp.json', {});
  all[gid] = data;
  write('xp.json', all);
}
function xpForLevel(lvl) { return 100 * lvl * lvl; }
function addXp(gid, uid, amount = 15) {
  const map = getXp(gid);
  if (!map[uid]) map[uid] = { xp: 0, level: 0 };
  map[uid].xp += amount;
  let leveled = false;
  while (map[uid].xp >= xpForLevel(map[uid].level + 1)) {
    map[uid].level += 1;
    leveled = true;
  }
  setXp(gid, map);
  return { ...map[uid], leveled };
}

const command = {
  data: new SlashCommandBuilder()
    .setName('reste')
    .setDescription('ManageX — utilitaires, modo, XP, AFK, etc.'),
  async execute(i) {
    await i.reply({
      embeds: [
        emb('📦 /reste — outils ManageX', C.primary)
          .setDescription(
            '### Tout ce qui n’est pas dans les configs\n' +
            'Choisis une **catégorie** ci-dessous pour afficher les outils.'
          )
          .addFields(
            { name: '🧰 Utilitaires', value: '`ping` `uptime` `botinfo` `serverinfo`\n`userinfo` `avatar` `invite` `support`' },
            { name: '🛡️ Modération', value: '`clear` `say` `announce`\n`lockdown` `unlock` `warns`' },
            { name: '🌟 Communauté', value: '`afk` `niveau` `classement`\n`membercount` `sticky`' },
            { name: '✨ Autres', value: '`embed` · `creeserv` (templates)' },
          )
          .setFooter({ text: 'ManageX · /reste' }),
      ],
      components: [
        new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('mx_reste_cat')
            .setPlaceholder('Catégorie…')
            .addOptions(
              { label: 'Utilitaires', value: 'util', emoji: '🧰' },
              { label: 'Modération', value: 'mod', emoji: '🛡️' },
              { label: 'Communauté', value: 'com', emoji: '🌟' },
              { label: 'Autres', value: 'other', emoji: '✨' },
            )
        ),
      ],
      ...EPH,
    });
  },
};

function utilRows() {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('mx_r_ping').setLabel('Ping').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('mx_r_uptime').setLabel('Uptime').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('mx_r_botinfo').setLabel('Botinfo').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('mx_r_serverinfo').setLabel('Serverinfo').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('mx_r_invite').setLabel('Invite bot').setStyle(ButtonStyle.Success),
  ), new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('mx_r_support').setLabel('Support').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('mx_r_avatar').setLabel('Avatar (toi)').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('mx_r_userinfo').setLabel('Userinfo (toi)').setStyle(ButtonStyle.Secondary),
  )];
}
function modRows() {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('mx_r_clear').setLabel('Clear').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('mx_r_say').setLabel('Say').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('mx_r_announce').setLabel('Announce').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('mx_r_lock').setLabel('Lockdown').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('mx_r_unlock').setLabel('Unlock').setStyle(ButtonStyle.Success),
  ), new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('mx_r_warn').setLabel('Warn').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('mx_r_warns').setLabel('Voir warns').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('mx_r_clearwarns').setLabel('Clear warns').setStyle(ButtonStyle.Danger),
  )];
}
function comRows() {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('mx_r_afk').setLabel('AFK').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('mx_r_niveau').setLabel('Mon niveau').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('mx_r_rank').setLabel('Classement').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('mx_r_mcount').setLabel('Membercount').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('mx_r_sticky').setLabel('Sticky').setStyle(ButtonStyle.Secondary),
  )];
}
function otherRows() {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('mx_r_embed').setLabel('Créer embed').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('mx_r_creeserv').setLabel('Créer structure serveur').setStyle(ButtonStyle.Danger),
  )];
}

async function handle(i) {
  const id = i.customId || '';
  if (!id.startsWith('mx_r') && id !== 'mx_reste_cat') return false;

  if (id === 'mx_reste_cat') {
    const v = i.values[0];
    const map = {
      util: { title: '🧰 Utilitaires', rows: utilRows() },
      mod: { title: '🛡️ Modération', rows: modRows() },
      com: { title: '🌟 Communauté', rows: comRows() },
      other: { title: '✨ Autres', rows: otherRows() },
    };
    const m = map[v];
    await i.update({
      embeds: [emb(m.title, C.primary).setDescription('Clique sur un outil :')],
      components: m.rows,
    });
    return true;
  }

  // ── Utilitaires ──
  if (id === 'mx_r_ping') {
    const sent = Date.now();
    await i.reply({ content: '🏓…', ...EPH });
    const rt = Date.now() - sent;
    await i.editReply({
      content: null,
      embeds: [emb('🏓 Pong', C.success).addFields(
        { name: 'Round-trip', value: `**${rt}ms**`, inline: true },
        { name: 'WebSocket', value: `**${i.client.ws.ping}ms**`, inline: true },
      )],
    });
    return true;
  }
  if (id === 'mx_r_uptime') {
    const s = Math.floor(process.uptime());
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    await i.reply({
      embeds: [emb('⏱️ Uptime', C.primary).setDescription(`**${h}h ${m}m ${s % 60}s**`)],
      ...EPH,
    });
    return true;
  }
  if (id === 'mx_r_botinfo') {
    const mem = (process.memoryUsage().heapUsed / 1048576).toFixed(1);
    await i.reply({
      embeds: [emb('🤖 Botinfo', C.primary).addFields(
        { name: 'Tag', value: i.client.user.tag, inline: true },
        { name: 'Serveurs', value: `**${i.client.guilds.cache.size}**`, inline: true },
        { name: 'Ping', value: `**${i.client.ws.ping}ms**`, inline: true },
        { name: 'Mémoire', value: `**${mem} Mo**`, inline: true },
        { name: 'Node', value: process.version, inline: true },
      ).setThumbnail(i.client.user.displayAvatarURL())],
      ...EPH,
    });
    return true;
  }
  if (id === 'mx_r_serverinfo') {
    const g = i.guild;
    await i.reply({
      embeds: [emb(`🏠 ${g.name}`, C.primary).addFields(
        { name: 'ID', value: g.id, inline: true },
        { name: 'Membres', value: `**${g.memberCount}**`, inline: true },
        { name: 'Salons', value: `**${g.channels.cache.size}**`, inline: true },
        { name: 'Rôles', value: `**${g.roles.cache.size}**`, inline: true },
        { name: 'Créé', value: `<t:${Math.floor(g.createdTimestamp / 1000)}:R>`, inline: true },
        { name: 'Owner', value: `<@${g.ownerId}>`, inline: true },
      ).setThumbnail(g.iconURL({ size: 128 }))],
      ...EPH,
    });
    return true;
  }
  if (id === 'mx_r_invite') {
    const url = `https://discord.com/api/oauth2/authorize?client_id=${i.client.user.id}&permissions=8&scope=bot%20applications.commands`;
    await i.reply({ embeds: [emb('🔗 Invite', C.success).setDescription(url)], ...EPH });
    return true;
  }
  if (id === 'mx_r_support') {
    const { getGlobal } = require('./storage.js');
    const inv = getGlobal().supportInvite || '*Non configuré (ownerconfig)*';
    await i.reply({ embeds: [emb('💬 Support', C.primary).setDescription(inv)], ...EPH });
    return true;
  }
  if (id === 'mx_r_avatar') {
    const url = i.user.displayAvatarURL({ size: 512 });
    await i.reply({
      embeds: [emb(`Avatar — ${i.user.tag}`, C.primary).setImage(url).setDescription(url)],
      ...EPH,
    });
    return true;
  }
  if (id === 'mx_r_userinfo') {
    const m = i.member;
    await i.reply({
      embeds: [emb(`👤 ${i.user.tag}`, C.primary).addFields(
        { name: 'ID', value: i.user.id, inline: true },
        { name: 'Compte', value: `<t:${Math.floor(i.user.createdTimestamp / 1000)}:R>`, inline: true },
        { name: 'A rejoint', value: m?.joinedTimestamp ? `<t:${Math.floor(m.joinedTimestamp / 1000)}:R>` : '—', inline: true },
        { name: 'Rôles', value: m ? [...m.roles.cache.filter((r) => r.id !== i.guild.id).values()].slice(0, 10).map((r) => `${r}`).join(', ') || '—' : '—' },
      ).setThumbnail(i.user.displayAvatarURL())],
      ...EPH,
    });
    return true;
  }

  // ── Modération ──
  if (id === 'mx_r_clear') {
    if (!isServerStaff(i.member)) { await i.reply({ content: '❌ Staff.', ...EPH }); return true; }
    const modal = new ModalBuilder().setCustomId('mx_modal_clear').setTitle('Clear');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('n').setLabel('Nombre (1-100)').setStyle(TextInputStyle.Short).setValue('10').setRequired(true)
    ));
    await i.showModal(modal);
    return true;
  }
  if (id === 'mx_r_say' || id === 'mx_r_announce') {
    if (!isServerStaff(i.member)) { await i.reply({ content: '❌ Staff.', ...EPH }); return true; }
    const isAnn = id === 'mx_r_announce';
    const modal = new ModalBuilder().setCustomId(isAnn ? 'mx_modal_announce' : 'mx_modal_say').setTitle(isAnn ? 'Annonce' : 'Say');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('text').setLabel('Message').setStyle(TextInputStyle.Paragraph).setRequired(true)
    ));
    await i.showModal(modal);
    return true;
  }
  if (id === 'mx_r_lock') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌ Admin.', ...EPH }); return true; }
    await i.deferReply({ ...EPH });
    const everyone = i.guild.roles.everyone;
    let n = 0;
    for (const [, ch] of i.guild.channels.cache) {
      if (!ch.isTextBased?.()) continue;
      try {
        await ch.permissionOverwrites.edit(everyone, { SendMessages: false, AddReactions: false });
        n++;
      } catch {}
    }
    setGuild(i.guild.id, { lockdown: true });
    await i.editReply({ content: `🔒 Lockdown — **${n}** salons.` });
    return true;
  }
  if (id === 'mx_r_unlock') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌ Admin.', ...EPH }); return true; }
    await i.deferReply({ ...EPH });
    const everyone = i.guild.roles.everyone;
    let n = 0;
    for (const [, ch] of i.guild.channels.cache) {
      if (!ch.isTextBased?.()) continue;
      try {
        await ch.permissionOverwrites.edit(everyone, { SendMessages: null, AddReactions: null });
        n++;
      } catch {}
    }
    setGuild(i.guild.id, { lockdown: false });
    await i.editReply({ content: `🔓 Unlock — **${n}** salons.` });
    return true;
  }
  if (id === 'mx_r_warn') {
    if (!isServerStaff(i.member)) { await i.reply({ content: '❌ Staff.', ...EPH }); return true; }
    await i.reply({
      content: 'Choisis le membre :',
      components: [new ActionRowBuilder().addComponents(
        new UserSelectMenuBuilder().setCustomId('mx_r_warn_user').setPlaceholder('Membre…').setMinValues(1).setMaxValues(1)
      )],
      ...EPH,
    });
    return true;
  }
  if (id === 'mx_r_warn_user') {
    const uid = i.values[0];
    // store pending and show modal - use customId with user
    const modal = new ModalBuilder().setCustomId(`mx_modal_warn_${uid}`).setTitle('Warn');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('reason').setLabel('Raison').setStyle(TextInputStyle.Paragraph).setRequired(true)
    ));
    await i.showModal(modal);
    return true;
  }
  if (id === 'mx_r_warns' || id === 'mx_r_clearwarns') {
    if (!isServerStaff(i.member)) { await i.reply({ content: '❌ Staff.', ...EPH }); return true; }
    await i.reply({
      content: id === 'mx_r_warns' ? 'Voir warns de :' : 'Clear warns de :',
      components: [new ActionRowBuilder().addComponents(
        new UserSelectMenuBuilder()
          .setCustomId(id === 'mx_r_warns' ? 'mx_r_warns_user' : 'mx_r_clearwarns_user')
          .setPlaceholder('Membre…').setMinValues(1).setMaxValues(1)
      )],
      ...EPH,
    });
    return true;
  }
  if (id === 'mx_r_warns_user') {
    const uid = i.values[0];
    const list = (bag('warns.json', i.guild.id) || {})[uid] || [];
    const lines = list.slice(0, 15).map((w, n) => `**${n + 1}.** ${w.reason} — <t:${Math.floor(w.at / 1000)}:R> par <@${w.by}>`).join('\n') || '*Aucun warn*';
    await i.update({ content: null, embeds: [emb(`Warns — <@${uid}>`, C.warn).setDescription(lines)], components: [] });
    return true;
  }
  if (id === 'mx_r_clearwarns_user') {
    const uid = i.values[0];
    const map = bag('warns.json', i.guild.id) || {};
    map[uid] = [];
    setBag('warns.json', i.guild.id, map);
    await i.update({ content: `✅ Warns de <@${uid}> effacés.`, embeds: [], components: [] });
    return true;
  }

  // ── Communauté ──
  if (id === 'mx_r_afk') {
    const modal = new ModalBuilder().setCustomId('mx_modal_afk').setTitle('AFK');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('reason').setLabel('Raison (vide = retirer AFK)').setStyle(TextInputStyle.Short).setRequired(false)
    ));
    await i.showModal(modal);
    return true;
  }
  if (id === 'mx_r_niveau') {
    const data = getXp(i.guild.id)[i.user.id] || { xp: 0, level: 0 };
    const next = xpForLevel(data.level + 1);
    await i.reply({
      embeds: [emb(`📈 Niveau — ${i.user.username}`, C.success).addFields(
        { name: 'Niveau', value: `**${data.level}**`, inline: true },
        { name: 'XP', value: `**${data.xp}** / ${next}`, inline: true },
      )],
      ...EPH,
    });
    return true;
  }
  if (id === 'mx_r_rank') {
    const map = getXp(i.guild.id);
    const sorted = Object.entries(map).sort((a, b) => (b[1].xp || 0) - (a[1].xp || 0)).slice(0, 10);
    const lines = sorted.map(([uid, d], n) => `**${n + 1}.** <@${uid}> — niv. **${d.level}** (${d.xp} XP)`).join('\n') || '*Personne*';
    await i.reply({ embeds: [emb('🏆 Classement XP', C.success).setDescription(lines)], ...EPH });
    return true;
  }
  if (id === 'mx_r_mcount') {
    await i.reply({
      embeds: [emb('👥 Membercount', C.primary).setDescription(`**${i.guild.memberCount}** membres`)],
      ...EPH,
    });
    return true;
  }
  if (id === 'mx_r_sticky') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌ Admin.', ...EPH }); return true; }
    const modal = new ModalBuilder().setCustomId('mx_modal_sticky').setTitle('Sticky message');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('text').setLabel('Message sticky (vide = retirer)').setStyle(TextInputStyle.Paragraph).setRequired(false)
    ));
    await i.showModal(modal);
    return true;
  }

  // ── Autres ──
  if (id === 'mx_r_embed') {
    if (!isServerStaff(i.member)) { await i.reply({ content: '❌ Staff.', ...EPH }); return true; }
    const modal = new ModalBuilder().setCustomId('mx_modal_embed').setTitle('Embed');
    modal.addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('title').setLabel('Titre').setStyle(TextInputStyle.Short).setRequired(true)),
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('desc').setLabel('Description').setStyle(TextInputStyle.Paragraph).setRequired(true)),
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('color').setLabel('Couleur hex (ex: 5865F2)').setStyle(TextInputStyle.Short).setValue('5865F2')),
    );
    await i.showModal(modal);
    return true;
  }
  if (id === 'mx_r_creeserv') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌ Admin.', ...EPH }); return true; }
    await i.reply({
      content: 'Template :',
      components: [new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId('mx_r_creeserv_pick').setPlaceholder('Type…')
          .addOptions(
            { label: 'Communautaire', value: 'com', emoji: '💬' },
            { label: 'Gaming', value: 'game', emoji: '🎮' },
            { label: 'RP / Classique', value: 'rp', emoji: '🎭' },
          )
      )],
      ...EPH,
    });
    return true;
  }
  if (id === 'mx_r_creeserv_pick') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    await i.deferReply({ ...EPH });
    const type = i.values[0];
    const templates = {
      com: [
        { cat: '📢 Informations', chans: ['annonces', 'règlement', 'bienvenue'] },
        { cat: '💬 Général', chans: ['général', 'médias', 'bots'] },
        { cat: '🎧 Vocal', chans: null, voice: ['Vocal 1', 'Vocal 2'] },
      ],
      game: [
        { cat: '📢 Infos', chans: ['annonces', 'looking-for-group'] },
        { cat: '🎮 Discussion', chans: ['général', 'clips'] },
        { cat: '🔊 Vocal', chans: null, voice: ['Lobby', 'Ranked', 'AFK'] },
      ],
      rp: [
        { cat: '📋 Accueil', chans: ['annonces', 'règlement', 'whitelist'] },
        { cat: '🏙️ RP', chans: ['général-hrp', 'annonces-rp'] },
        { cat: '📞 Support', chans: ['tickets-info'] },
      ],
    };
    const t = templates[type] || templates.com;
    try {
      for (const block of t) {
        const cat = await i.guild.channels.create({ name: block.cat, type: ChannelType.GuildCategory });
        for (const name of block.chans || []) {
          await i.guild.channels.create({ name, type: ChannelType.GuildText, parent: cat.id });
        }
        for (const name of block.voice || []) {
          await i.guild.channels.create({ name, type: ChannelType.GuildVoice, parent: cat.id });
        }
      }
      // rôles de base
      for (const [name, color] of [['Membre', 0x57f287], ['Staff', 0x5865f2], ['Admin', 0xed4245]]) {
        if (!i.guild.roles.cache.find((r) => r.name === name)) {
          await i.guild.roles.create({ name, colors: [color], reason: 'ManageX creeserv' }).catch(() => null);
        }
      }
      await i.editReply({ content: `✅ Structure **${type}** créée (catégories + salons + rôles).` });
    } catch (e) {
      await i.editReply({ content: `❌ ${e.message}` });
    }
    return true;
  }

  return false;
}

async function handleModal(i) {
  const id = i.customId || '';
  if (id === 'mx_modal_clear') {
    if (!isServerStaff(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    const n = Math.min(100, Math.max(1, parseInt(i.fields.getTextInputValue('n'), 10) || 10));
    await i.deferReply({ ...EPH });
    const deleted = await i.channel.bulkDelete(n, true).catch(() => null);
    await i.editReply({ content: `🧹 **${deleted?.size || 0}** messages supprimés.` });
    return true;
  }
  if (id === 'mx_modal_say' || id === 'mx_modal_announce') {
    if (!isServerStaff(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    const text = i.fields.getTextInputValue('text');
    if (id === 'mx_modal_announce') {
      await i.channel.send({ embeds: [emb('📢 Annonce', C.danger).setDescription(text)] });
    } else {
      await i.channel.send({ content: text });
    }
    await i.reply({ content: '✅', ...EPH });
    return true;
  }
  if (id.startsWith('mx_modal_warn_')) {
    if (!isServerStaff(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    const uid = id.replace('mx_modal_warn_', '');
    const reason = i.fields.getTextInputValue('reason');
    const map = bag('warns.json', i.guild.id) || {};
    if (!map[uid]) map[uid] = [];
    map[uid].unshift({ reason, by: i.user.id, at: Date.now() });
    setBag('warns.json', i.guild.id, map);
    await i.reply({ content: `⚠️ <@${uid}> warn (**${map[uid].length}**) — ${reason}`, ...EPH });
    return true;
  }
  if (id === 'mx_modal_afk') {
    const reason = (i.fields.getTextInputValue('reason') || '').trim();
    const map = getAfk();
    if (!reason) {
      delete map[i.user.id];
      setAfkMap(map);
      await i.reply({ content: '✅ AFK retiré.', ...EPH });
    } else {
      map[i.user.id] = { reason, at: Date.now(), guildId: i.guild.id };
      setAfkMap(map);
      await i.reply({ content: `💤 AFK : **${reason}**`, ...EPH });
    }
    return true;
  }
  if (id === 'mx_modal_sticky') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    const text = (i.fields.getTextInputValue('text') || '').trim();
    const all = read('sticky.json', {});
    if (!text) {
      delete all[i.channel.id];
      write('sticky.json', all);
      await i.reply({ content: '✅ Sticky retiré.', ...EPH });
    } else {
      all[i.channel.id] = { text, guildId: i.guild.id };
      write('sticky.json', all);
      await i.channel.send({ embeds: [emb('📌 Sticky', C.primary).setDescription(text)] });
      await i.reply({ content: '✅ Sticky défini.', ...EPH });
    }
    return true;
  }
  if (id === 'mx_modal_embed') {
    if (!isServerStaff(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    const color = parseInt((i.fields.getTextInputValue('color') || '5865F2').replace('#', ''), 16) || 0x5865f2;
    await i.channel.send({
      embeds: [new EmbedBuilder()
        .setTitle(i.fields.getTextInputValue('title'))
        .setDescription(i.fields.getTextInputValue('desc'))
        .setColor(color)
        .setTimestamp()],
    });
    await i.reply({ content: '✅ Embed posté.', ...EPH });
    return true;
  }
  return false;
}

/** XP passif + AFK mention + sticky */
async function onMessage(message) {
  if (!message.guild || message.author.bot) return;

  // AFK
  const afk = getAfk();
  if (afk[message.author.id]) {
    delete afk[message.author.id];
    setAfkMap(afk);
    await message.reply({ content: '👋 Welcome back, AFK retiré.' }).then((m) => setTimeout(() => m.delete().catch(() => null), 5000)).catch(() => null);
  }
  for (const [, user] of message.mentions.users) {
    if (afk[user.id]) {
      await message.reply({ content: `💤 **${user.username}** est AFK : ${afk[user.id].reason}` }).catch(() => null);
    }
  }

  // XP géré par levels.js

  // Sticky
  // Sticky
  const sticky = read('sticky.json', {})[message.channel.id];
  if (sticky?.text && message.id) {
    if (!onMessage._stickyCd) onMessage._stickyCd = new Map();
    const sk = message.channel.id;
    if (Date.now() - (onMessage._stickyCd.get(sk) || 0) > 15_000) {
      onMessage._stickyCd.set(sk, Date.now());
      // delete last sticky bot msg if tracked
      try {
        const msgs = await message.channel.messages.fetch({ limit: 15 });
        const prev = msgs.find((m) => m.author.id === message.client.user.id && m.embeds[0]?.title === '📌 Sticky');
        if (prev) await prev.delete().catch(() => null);
        await message.channel.send({ embeds: [emb('📌 Sticky', C.primary).setDescription(sticky.text)] });
      } catch {}
    }
  }
}


const sayCommand = {
  data: new SlashCommandBuilder()
    .setName('say')
    .setDescription('Envoyer un message dans un salon (mentions autorisées)')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addStringOption((o) =>
      o.setName('message').setDescription('Texte à envoyer (@ mentions ok)').setRequired(true).setMaxLength(2000)
    )
    .addChannelOption((o) =>
      o.setName('salon').setDescription('Salon cible (défaut : ici)').addChannelTypes(ChannelType.GuildText).setRequired(false)
    ),
  async execute(i) {
    if (!isAdmin(i.member) && !i.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      return i.reply({ content: '❌ Permission Gérer les messages requise.', ...EPH });
    }
    const text = i.options.getString('message');
    const ch = i.options.getChannel('salon') || i.channel;
    if (!ch?.send) {
      return i.reply({ content: '❌ Salon invalide.', ...EPH });
    }
    await ch.send({
      content: text,
      allowedMentions: { parse: ['users', 'roles', 'everyone'] },
    });
    await i.reply({ content: `✅ Message envoyé dans ${ch}.`, ...EPH });
  },
};

module.exports = { command, sayCommand, handle, handleModal, onMessage };
