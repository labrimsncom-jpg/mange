const { EmbedBuilder } = require('discord.js');
const { E, CFG, withAnim } = require('./emojis.js');

const C = {
  primary: 0x5865f2,
  success: 0x57f287,
  danger: 0xed4245,
  warn: 0xfee75c,
  info: 0x5865f2,
  service: 0x3ba55d,
  absence: 0xfaa61a,
  ban: 0xed4245,
  ticket: 0x9b59b6,
  soft: 0x2f3136,
  accent: 0x00d4aa,
  violet: 0xa855f7,
  pink: 0xeb459e,
  // aliases used by older modules
  config: 0x5865f2,
  dark: 0x2f3136,
};

const DIV = '────────────────────────';

const PRIORITY = {
  low: { label: 'Basse', emoji: '🟢', color: 0x57f287 },
  normal: { label: 'Normale', emoji: '🟡', color: 0xfee75c },
  high: { label: 'Haute', emoji: '🟠', color: 0xe67e22 },
  urgent: { label: 'Urgente', emoji: '🔴', color: 0xed4245 },
};

/** Salon → mention ou tiret */
function ch(id) {
  if (!id) return '`—`';
  return `<#${id}>`;
}

/** Rôle → mention ou tiret */
function role(id) {
  if (!id) return '`—`';
  return `<@&${id}>`;
}

/** Liste de rôles */
function roles(ids) {
  if (!ids || !ids.length) return '`aucun`';
  return ids.map((id) => `<@&${id}>`).join(' ');
}

/** Bool → emoji texte */
function status(on) {
  return on ? `${CFG.ok} **ON**` : `${CFG.no} **OFF**`;
}

function pickEmoji(color) {
  if (color === C.success) return CFG.ok;
  if (color === C.danger) return CFG.no;
  if (color === C.warn) return CFG.warn;
  if (color === C.ticket) return CFG.tickets;
  if (color === C.service) return CFG.staff;
  if (color === C.violet) return CFG.form;
  if (color === C.absence) return E.ampoule;
  return CFG.config;
}

function emb(title, color = C.primary) {
  return new EmbedBuilder()
    .setColor(color)
    .setTitle(withAnim(title, pickEmoji(color)))
    .setTimestamp()
    .setFooter({ text: `${CFG.config} ManageX` });
}

/**
 * card({ title, color, description, fields, footer })
 * API utilisée par serverConfig, giveaway, levels, setup…
 */
function card(opts = {}) {
  const {
    title = 'ManageX',
    color = C.primary,
    description = null,
    fields = [],
    footer = null,
  } = opts;
  const e = new EmbedBuilder()
    .setColor(color)
    .setTitle(withAnim(title, pickEmoji(color)))
    .setTimestamp()
    .setFooter({ text: footer || `${CFG.config} ManageX` });
  if (description) e.setDescription(description);
  if (fields?.length) {
    e.addFields(
      fields.map((f) => ({
        name: String(f.name || '—').slice(0, 256),
        value: String(f.value || '—').slice(0, 1024),
        inline: !!f.inline,
      }))
    );
  }
  return e;
}

function configCard(title, description, fields = [], color = C.primary) {
  const e = new EmbedBuilder()
    .setColor(color)
    .setTitle(withAnim(title, CFG.config))
    .setDescription(description || null)
    .setTimestamp()
    .setFooter({ text: `${CFG.config} ManageX · configuration` });
  if (fields?.length) {
    e.addFields(
      fields.map((f) => ({
        name: withAnim(f.name, CFG.info).slice(0, 256),
        value: f.value || '—',
        inline: !!f.inline,
      }))
    );
  }
  return e;
}

function panelHero(title, color, lines, guild) {
  return new EmbedBuilder()
    .setColor(color)
    .setTitle(withAnim(title, pickEmoji(color)))
    .setDescription([CFG.next, ...(lines || [])].filter(Boolean).join('\n'))
    .setThumbnail(guild?.iconURL?.({ size: 128 }) || null)
    .setTimestamp()
    .setFooter({ text: `${CFG.ok} ManageX · panel` });
}

module.exports = {
  C,
  DIV,
  PRIORITY,
  ch,
  role,
  roles,
  status,
  emb,
  card,
  configCard,
  panelHero,
  E,
  CFG,
  withAnim,
};
