/**
 * /servavisconfig — avis staff · avis serveur · suggestions
 * Design clair + panels complets + stats
 */
const {
  SlashCommandBuilder, PermissionFlagsBits, MessageFlags,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder,
  RoleSelectMenuBuilder, UserSelectMenuBuilder, ChannelType,
  ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder,
  StringSelectMenuBuilder,
} = require('discord.js');
const { getGuild, setGuild, bag, setBag } = require('./storage.js');
const { isAdmin } = require('./perms.js');
const { emb, C, configCard, ch, roles } = require('./design.js');
const { openBtn } = require('./pickers.js');
const { E, CFG } = require('./emojis.js');

const EPH = { flags: MessageFlags.Ephemeral };
const pending = new Map();

const stars = (n) => '⭐'.repeat(n) + '☆'.repeat(Math.max(0, 5 - n));
const starLabel = (n) => `${stars(n)} (**${n}/5**)`;

function avgNote(list) {
  if (!list?.length) return null;
  const s = list.reduce((a, x) => a + (x.note || 0), 0);
  return (s / list.length).toFixed(1);
}

function cfgEmbed(gid) {
  const c = getGuild(gid);
  const staffList = bag('avisstaff.json', gid) || [];
  const serverList = bag('avisserver.json', gid) || [];
  const suggestList = bag('suggestions.json', gid) || [];

  return configCard(
    '⭐ ServAvis Config',
    '### Avis & suggestions\nConfigure les salons, panels et rôles qui **acceptent / refusent** les suggestions.',
    [
      { name: '👮 Avis staff →', value: ch(c.avisStaffChannelId), inline: true },
      { name: '🌟 Avis serveur →', value: ch(c.avisServerChannelId), inline: true },
      { name: '💡 Suggestions →', value: ch(c.suggestChannelId), inline: true },
      { name: '👮 Rôles pouvant être notés (avis staff)', value: roles(c.avisStaffRoleIds) || '`Tous (pas de filtre)`' },
      { name: '🛡️ Rôles review suggestions', value: roles(c.suggestReviewRoleIds) },
      {
        name: '📊 Stats',
        value: [
          `Avis staff : **${staffList.length}**` + (avgNote(staffList) ? ` · moy. **${avgNote(staffList)}**/5` : ''),
          `Avis serveur : **${serverList.length}**` + (avgNote(serverList) ? ` · moy. **${avgNote(serverList)}**/5` : ''),
          `Suggestions : **${suggestList.length}**`,
        ].join('\n'),
      },
    ],
    C.gold
  );
}

function panelStaffEmbed(guild) {
  return new EmbedBuilder()
    .setColor(C.gold)
    .setAuthor({ name: guild.name, iconURL: guild.iconURL({ size: 64 }) || undefined })
    .setTitle('⭐ Avis staff')
    .setDescription(
      [
        '### Évalue un membre de l’équipe',
        '',
        'Ton retour aide le staff à progresser.',
        '',
        '**Étapes**',
        '1️⃣ Choisis le staff dans le menu',
        '2️⃣ Note de **1** à **5** étoiles',
        '3️⃣ Ajoute un commentaire constructif',
        '',
        '> Seuls les rôles configurés dans `/servavisconfig` peuvent être notés.',
      ].join('\n')
    )
    .setThumbnail(guild.iconURL({ size: 256 }))
    .setFooter({ text: 'ManageX · ServAvis · avis staff' })
    .setTimestamp();
}

function panelServerEmbed(guild) {
  return new EmbedBuilder()
    .setColor(C.cyan)
    .setAuthor({ name: guild.name, iconURL: guild.iconURL({ size: 64 }) || undefined })
    .setTitle('🌟 Avis serveur')
    .setDescription(
      [
        `### Que penses-tu de **${guild.name}** ?`,
        '',
        'Ton avis compte pour améliorer le serveur.',
        '',
        '**Comment faire**',
        '• Clique sur **Donner mon avis**',
        '• Note de **1** à **5**',
        '• Explique ce que tu aimes / ce qu’il manque',
      ].join('\n')
    )
    .setThumbnail(guild.iconURL({ size: 256 }))
    .setFooter({ text: 'ManageX · ServAvis · avis serveur' })
    .setTimestamp();
}

function panelSuggestEmbed(guild) {
  return new EmbedBuilder()
    .setColor(C.success)
    .setAuthor({ name: guild.name, iconURL: guild.iconURL({ size: 64 }) || undefined })
    .setTitle(`${E.ampoule} Boîte à suggestions`)
    .setDescription(
      [
        '### Une idée pour améliorer le serveur ?',
        '',
        'Event, salon, règle, partenariat… tout est bon à prendre.',
        '',
        '**Processus**',
        '1️⃣ Tu envoies ta suggestion',
        '2️⃣ Le staff la **review**',
        '3️⃣ Tu reçois un MP si elle est acceptée ou refusée',
        '',
        '> Sois clair et respectueux pour maximiser tes chances.',
      ].join('\n')
    )
    .setThumbnail(guild.iconURL({ size: 256 }))
    .setFooter({ text: 'ManageX · ServAvis · suggestions' })
    .setTimestamp();
}

function avisStaffResultEmbed({ targetId, note, comment, author }) {
  return new EmbedBuilder()
    .setColor(note >= 4 ? C.success : note <= 2 ? C.danger : C.warn)
    .setAuthor({ name: 'Nouvel avis staff', iconURL: author?.displayAvatarURL?.({ size: 64 }) })
    .setTitle(`⭐ ${starLabel(note)}`)
    .setDescription(`### Évaluation reçue\n\n${comment.slice(0, 1000) || '_Sans commentaire_'}`)
    .addFields(
      { name: '👮 Staff noté', value: `<@${targetId}>`, inline: true },
      { name: '📝 Par', value: `${author}`, inline: true },
      { name: '📅 Date', value: `<t:${Math.floor(Date.now() / 1000)}:f>`, inline: true },
    )
    .setTimestamp()
    .setFooter({ text: 'ManageX · Avis staff' });
}

function avisServerResultEmbed({ note, comment, author, guild }) {
  return new EmbedBuilder()
    .setColor(note >= 4 ? C.success : note <= 2 ? C.danger : C.cyan)
    .setAuthor({ name: guild.name, iconURL: guild.iconURL({ size: 64 }) || undefined })
    .setTitle(`🌟 ${starLabel(note)}`)
    .setDescription(`### Avis sur le serveur\n\n${comment.slice(0, 1000) || '_Sans commentaire_'}`)
    .addFields(
      { name: '📝 Auteur', value: `${author}`, inline: true },
      { name: '📅 Date', value: `<t:${Math.floor(Date.now() / 1000)}:f>`, inline: true },
    )
    .setThumbnail(guild.iconURL({ size: 128 }))
    .setTimestamp()
    .setFooter({ text: 'ManageX · Avis serveur' });
}

function suggestEmbed({ title, body, author, status }) {
  const colors = { pending: C.primary, accepted: C.success, rejected: C.danger };
  const titles = {
    pending: `💡 Suggestion · ${title}`,
    accepted: `✅ Acceptée · ${title}`,
    rejected: `❌ Refusée · ${title}`,
  };
  return new EmbedBuilder()
    .setColor(colors[status] || C.primary)
    .setTitle((titles[status] || title).slice(0, 256))
    .setDescription(body.slice(0, 4000))
    .addFields({ name: '👤 Proposé par', value: `${author}`, inline: true })
    .setTimestamp()
    .setFooter({ text: status === 'pending' ? 'ManageX · en attente de review' : `ManageX · ${status}` });
}

function suggestButtons(sid) {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`mx_sg_ok_${sid}`).setLabel('Accepter').setStyle(ButtonStyle.Success).setEmoji('✅'),
    new ButtonBuilder().setCustomId(`mx_sg_no_${sid}`).setLabel('Refuser').setStyle(ButtonStyle.Danger).setEmoji('❌'),
  )];
}

const command = {
  data: new SlashCommandBuilder()
    .setName('servavisconfig')
    .setDescription('ManageX — avis staff, avis serveur, suggestions')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(i) {
    if (!isAdmin(i.member)) return i.reply({ content: '❌ Administrateur requis.', ...EPH });
    await i.reply({
      embeds: [cfgEmbed(i.guild.id)],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('mx_av_panel_staff').setLabel('Panel avis staff').setStyle(ButtonStyle.Primary).setEmoji('⭐'),
          new ButtonBuilder().setCustomId('mx_av_panel_server').setLabel('Panel avis serveur').setStyle(ButtonStyle.Primary).setEmoji('🌟'),
          new ButtonBuilder().setCustomId('mx_av_panel_suggest').setLabel('Panel suggestions').setStyle(ButtonStyle.Success).setEmoji('💡'),
          new ButtonBuilder().setCustomId('mx_av_panel_report').setLabel('Panel report').setStyle(ButtonStyle.Danger).setEmoji('📣'),
          new ButtonBuilder().setCustomId('mx_av_stats').setLabel('Stats détaillées').setStyle(ButtonStyle.Secondary).setEmoji('📊'),
        ),
        new ActionRowBuilder().addComponents(
          openBtn('ch', 'av_staff', '⭐ Salon avis staff')
        ),
        new ActionRowBuilder().addComponents(
          openBtn('ch', 'av_server', '🌟 Salon avis serveur')
        ),
        new ActionRowBuilder().addComponents(
          openBtn('ch', 'av_suggest', '💡 Salon suggestions'),
        ),
        new ActionRowBuilder().addComponents(
          openBtn('role', 'av_suggest_roles', '🛡️ Rôles review suggestions')
        ),
      ],
      ...EPH,
    });
    await i.followUp({
      content: '**📣 Salon des reports**',
      components: [
        new ActionRowBuilder().addComponents(
          openBtn('ch', 'av_report', '📣 Salon reports')
        ),
      ],
      ...EPH,
    });
    await i.followUp({
      content: '**👮 Rôles qui peuvent recevoir un avis staff** (vide = tout le monde)',
      components: [
        new ActionRowBuilder().addComponents(
          new RoleSelectMenuBuilder()
            .setCustomId('mx_av_staff_roles')
            .setPlaceholder('Rôles notables (Modo, Staff, Helper…)…')
            .setMinValues(0)
            .setMaxValues(10)
        ),
      ],
      ...EPH,
    });
  },
};

function canReviewSuggest(member, c) {
  if (isAdmin(member)) return true;
  return (c.suggestReviewRoleIds || []).some((r) => member.roles.cache.has(r));
}

async function handle(i) {
  const id = i.customId || '';
  if (!id.startsWith('mx_av_') && !id.startsWith('mx_sg_')) return false;

  const gid = i.guild.id;
  const c = getGuild(gid);

  // ── Config admin ──
  if (id === 'mx_av_ch_staff') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    setGuild(gid, { avisStaffChannelId: i.values[0] || null });
    await i.reply({ content: i.values[0] ? `✅ Avis staff → <#${i.values[0]}>` : '✅ Salon avis staff retiré.', ...EPH });
    return true;
  }
  if (id === 'mx_av_ch_server') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    setGuild(gid, { avisServerChannelId: i.values[0] || null });
    await i.reply({ content: i.values[0] ? `✅ Avis serveur → <#${i.values[0]}>` : '✅ Salon retiré.', ...EPH });
    return true;
  }
  if (id === 'mx_av_ch_suggest') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    setGuild(gid, { suggestChannelId: i.values[0] || null });
    await i.reply({ content: i.values[0] ? `✅ Suggestions → <#${i.values[0]}>` : '✅ Salon retiré.', ...EPH });
    return true;
  }
  if (id === 'mx_av_suggest_roles') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    setGuild(gid, { suggestReviewRoleIds: i.values || [] });
    await i.reply({ content: `✅ Rôles review : **${(i.values || []).length}**`, ...EPH });
    return true;
  }
  if (id === 'mx_av_staff_roles') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    setGuild(gid, { avisStaffRoleIds: i.values || [] });
    await i.reply({
      content: (i.values || []).length
        ? `✅ Seuls les membres avec : ${(i.values || []).map((id) => `<@&${id}>`).join(' ')} peuvent **recevoir** un avis staff.`
        : '✅ Filtre retiré — n’importe qui peut être noté.',
      ...EPH,
    });
    return true;
  }

  if (id === 'mx_av_stats') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    const staffList = bag('avisstaff.json', gid) || [];
    const serverList = bag('avisserver.json', gid) || [];
    const byTarget = {};
    for (const a of staffList) {
      if (!a.target) continue;
      if (!byTarget[a.target]) byTarget[a.target] = [];
      byTarget[a.target].push(a.note);
    }
    const top = Object.entries(byTarget)
      .map(([uid, notes]) => {
        const avg = (notes.reduce((s, n) => s + n, 0) / notes.length).toFixed(1);
        return `<@${uid}> — **${avg}/5** (${notes.length} avis)`;
      })
      .slice(0, 10)
      .join('\n') || '*Aucun avis staff*';

    await i.reply({
      embeds: [
        emb('📊 Stats ServAvis', C.gold)
          .addFields(
            { name: '⭐ Avis staff', value: `**${staffList.length}** · moy. **${avgNote(staffList) || '—'}**/5`, inline: true },
            { name: '🌟 Avis serveur', value: `**${serverList.length}** · moy. **${avgNote(serverList) || '—'}**/5`, inline: true },
            { name: '💡 Suggestions', value: `**${(bag('suggestions.json', gid) || []).length}**`, inline: true },
            { name: '🏆 Top staff notés', value: top },
          ),
      ],
      ...EPH,
    });
    return true;
  }

  if (id === 'mx_av_panel_staff') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    await i.deferReply({ ...EPH });
    await i.channel.send({
      embeds: [panelStaffEmbed(i.guild)],
      components: [
        new ActionRowBuilder().addComponents(
          new UserSelectMenuBuilder()
            .setCustomId('mx_av_pick_staff')
            .setPlaceholder('👮 Choisir un staff à noter…')
            .setMinValues(1)
            .setMaxValues(1)
        ),
      ],
    });
    await i.editReply({ content: '✅ Panel **avis staff** posté dans ce salon.' });
    return true;
  }

  if (id === 'mx_av_panel_server') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    await i.deferReply({ ...EPH });
    await i.channel.send({
      embeds: [panelServerEmbed(i.guild)],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('mx_av_server_btn')
            .setLabel('Donner mon avis')
            .setStyle(ButtonStyle.Success)
            .setEmoji('🌟')
        ),
      ],
    });
    await i.editReply({ content: '✅ Panel **avis serveur** posté.' });
    return true;
  }

  if (id === 'mx_av_panel_suggest') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    await i.deferReply({ ...EPH });
    const msg = await i.channel.send({
      embeds: [panelSuggestEmbed(i.guild)],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('mx_sg_create')
            .setLabel('Faire une suggestion')
            .setStyle(ButtonStyle.Success)
            .setEmoji('💡')
        ),
      ],
    });
    setGuild(gid, { suggestPanelChannelId: i.channel.id, suggestPanelMessageId: msg.id });
    await i.editReply({ content: '✅ Panel **suggestions** posté.' });
    return true;
  }

  // ── User flows ──
  if (id === 'mx_av_pick_staff') {
    const target = i.values[0];
    if (target === i.user.id) {
      await i.reply({ content: '❌ Tu ne peux pas te noter toi-même.', ...EPH });
      return true;
    }
    // Rôles autorisés à recevoir un avis
    const allowedRoles = c.avisStaffRoleIds || [];
    if (allowedRoles.length) {
      const member = await i.guild.members.fetch(target).catch(() => null);
      const ok = member && allowedRoles.some((rid) => member.roles.cache.has(rid));
      if (!ok) {
        await i.reply({
          content: '❌ Ce membre n’a **pas** un rôle autorisé à recevoir un avis staff.\nConfigure les rôles dans `/servavisconfig`.',
          ...EPH,
        });
        return true;
      }
    }
    pending.set(i.user.id, { type: 'staff', target });
    // Note via select puis modal commentaire
    await i.reply({
      embeds: [emb('⭐ Note le staff', C.gold).setDescription(`Tu notes <@${target}>.\nChoisis une note :`)],
      components: [
        new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('mx_av_staff_note')
            .setPlaceholder('Note de 1 à 5…')
            .addOptions(
              { label: '1 — Très mauvais', value: '1', emoji: '⭐' },
              { label: '2 — Mauvais', value: '2', emoji: '⭐' },
              { label: '3 — Moyen', value: '3', emoji: '⭐' },
              { label: '4 — Bon', value: '4', emoji: '⭐' },
              { label: '5 — Excellent', value: '5', emoji: '⭐' },
            )
        ),
      ],
      ...EPH,
    });
    return true;
  }

  if (id === 'mx_av_staff_note') {
    const p = pending.get(i.user.id);
    if (!p || p.type !== 'staff') {
      await i.update({ content: 'Session expirée — recommence.', embeds: [], components: [] });
      return true;
    }
    p.note = parseInt(i.values[0], 10);
    pending.set(i.user.id, p);
    const modal = new ModalBuilder().setCustomId('mx_modal_avis_staff').setTitle(`Avis staff · ${p.note}/5`);
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('comment')
          .setLabel('Commentaire')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(800)
          .setPlaceholder('Ce qui s’est bien / mal passé…')
      )
    );
    await i.showModal(modal);
    return true;
  }

  if (id === 'mx_av_server_btn') {
    await i.reply({
      embeds: [emb('🌟 Note le serveur', C.cyan).setDescription(`Que penses-tu de **${i.guild.name}** ?`)],
      components: [
        new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('mx_av_server_note')
            .setPlaceholder('Note de 1 à 5…')
            .addOptions(
              { label: '1 — Très mauvais', value: '1', emoji: '⭐' },
              { label: '2 — Mauvais', value: '2', emoji: '⭐' },
              { label: '3 — Moyen', value: '3', emoji: '⭐' },
              { label: '4 — Bon', value: '4', emoji: '⭐' },
              { label: '5 — Excellent', value: '5', emoji: '⭐' },
            )
        ),
      ],
      ...EPH,
    });
    return true;
  }

  if (id === 'mx_av_server_note') {
    pending.set(i.user.id, { type: 'server', note: parseInt(i.values[0], 10) });
    const modal = new ModalBuilder().setCustomId('mx_modal_avis_server').setTitle(`Avis serveur · ${i.values[0]}/5`);
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('comment')
          .setLabel('Commentaire')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(800)
          .setPlaceholder('Ce que tu aimes, ce qu’il faudrait améliorer…')
      )
    );
    await i.showModal(modal);
    return true;
  }

  if (id === 'mx_sg_create') {
    const modal = new ModalBuilder().setCustomId('mx_modal_suggest').setTitle('💡 Nouvelle suggestion');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('title').setLabel('Titre').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100)
          .setPlaceholder('Ex: Ajouter un salon vocal AFK')
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('body').setLabel('Détails').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(1500)
          .setPlaceholder('Explique ton idée et pourquoi elle serait utile…')
      ),
    );
    await i.showModal(modal);
    return true;
  }

  // Accept / reject
  if (id.startsWith('mx_sg_ok_') || id.startsWith('mx_sg_no_')) {
    if (!canReviewSuggest(i.member, c)) {
      await i.reply({ content: '❌ Tu n’as pas le rôle pour review les suggestions.', ...EPH });
      return true;
    }
    const accept = id.startsWith('mx_sg_ok_');
    const sid = id.replace(/^mx_sg_(ok|no)_/, '');
    const list = bag('suggestions.json', gid) || [];
    const item = list.find((s) => s.id === sid);
    if (item) {
      item.status = accept ? 'accepted' : 'rejected';
      item.reviewedBy = i.user.id;
      item.reviewedAt = Date.now();
      setBag('suggestions.json', gid, list);
    }

    const oldDesc = i.message.embeds[0]?.description || item?.body || '';
    const oldTitle = item?.title || i.message.embeds[0]?.title?.replace(/^💡 Suggestion · /, '') || 'Suggestion';

    await i.update({
      embeds: [
        suggestEmbed({
          title: oldTitle,
          body: oldDesc,
          author: item ? `<@${item.authorId}>` : (i.message.embeds[0]?.fields?.[0]?.value || '—'),
          status: accept ? 'accepted' : 'rejected',
        }).addFields({
          name: accept ? '✅ Acceptée par' : '❌ Refusée par',
          value: `${i.user}`,
          inline: true,
        }),
      ],
      components: [],
    });

    // DM auteur si possible
    if (item?.authorId) {
      try {
        const u = await i.client.users.fetch(item.authorId);
        await u.send({
          embeds: [
            emb(accept ? '✅ Suggestion acceptée' : '❌ Suggestion refusée', accept ? C.success : C.danger)
              .setDescription(`**${item.title}**\nSur **${i.guild.name}**\nPar ${i.user.tag}`),
          ],
        });
      } catch {}
    }
    return true;
  }

  return false;
}

async function handleModal(i) {

  if (i.customId === 'mx_modal_report') {
    const c = getGuild(i.guild.id);
    if (!c.reportChannelId) {
      await i.reply({ content: '❌ Salon report non configuré (/servavisconfig).', ...EPH });
      return true;
    }
    const cible = i.fields.getTextInputValue('cible').trim();
    const raison = i.fields.getTextInputValue('raison').trim();
    const preuve = i.fields.getTextInputValue('preuve')?.trim() || null;
    const ch = await i.guild.channels.fetch(c.reportChannelId).catch(() => null);
    if (!ch?.send) {
      await i.reply({ content: '❌ Salon report introuvable.', ...EPH });
      return true;
    }
    await ch.send({
      embeds: [
        emb(`${E.annonce} Nouveau report`, C.danger)
          .setAuthor({ name: i.user.tag, iconURL: i.user.displayAvatarURL({ size: 64 }) })
          .addFields(
            { name: 'Auteur', value: `${i.user} (\`${i.user.id}\`)`, inline: true },
            { name: 'Cible', value: cible.slice(0, 200), inline: true },
            { name: 'Description', value: raison.slice(0, 1000) },
            ...(preuve ? [{ name: 'Preuve', value: preuve.slice(0, 200) }] : []),
          )
          .setFooter({ text: 'ManageX · Report panel' }),
      ],
    });
    await i.reply({ content: '✅ Report envoyé au staff. Merci.', ...EPH });
    return true;
  }

  const id = i.customId || '';
  const gid = i.guild.id;
  const c = getGuild(gid);

  if (id === 'mx_modal_avis_staff') {
    const p = pending.get(i.user.id);
    pending.delete(i.user.id);
    if (!p || p.type !== 'staff' || !p.target) {
      await i.reply({ content: 'Session expirée — recommence depuis le panel.', ...EPH });
      return true;
    }
    const note = p.note || 3;
    const comment = i.fields.getTextInputValue('comment');
    const list = bag('avisstaff.json', gid) || [];
    list.unshift({
      id: Date.now().toString(36),
      from: i.user.id,
      target: p.target,
      note,
      comment,
      at: Date.now(),
    });
    setBag('avisstaff.json', gid, list.slice(0, 500));

    const embed = avisStaffResultEmbed({
      targetId: p.target,
      note,
      comment,
      author: i.user,
    });

    if (c.avisStaffChannelId) {
      const chn = await i.guild.channels.fetch(c.avisStaffChannelId).catch(() => null);
      if (chn?.send) await chn.send({ embeds: [embed] }).catch(() => null);
    }
    await i.reply({
      embeds: [emb('✅ Avis envoyé', C.success).setDescription(`Merci ! Tu as noté <@${p.target}> ${starLabel(note)}.`)],
      ...EPH,
    });
    return true;
  }

  if (id === 'mx_modal_avis_server') {
    const p = pending.get(i.user.id);
    pending.delete(i.user.id);
    const note = p?.note || 3;
    const comment = i.fields.getTextInputValue('comment');
    const list = bag('avisserver.json', gid) || [];
    list.unshift({
      id: Date.now().toString(36),
      from: i.user.id,
      note,
      comment,
      at: Date.now(),
    });
    setBag('avisserver.json', gid, list.slice(0, 500));

    const embed = avisServerResultEmbed({
      note,
      comment,
      author: i.user,
      guild: i.guild,
    });

    if (c.avisServerChannelId) {
      const chn = await i.guild.channels.fetch(c.avisServerChannelId).catch(() => null);
      if (chn?.send) await chn.send({ embeds: [embed] }).catch(() => null);
    }
    await i.reply({
      embeds: [emb('✅ Merci pour ton avis !', C.cyan).setDescription(starLabel(note))],
      ...EPH,
    });
    return true;
  }

  if (id === 'mx_modal_suggest') {
    const title = i.fields.getTextInputValue('title');
    const body = i.fields.getTextInputValue('body');
    const sid = Date.now().toString(36);
    const list = bag('suggestions.json', gid) || [];
    list.unshift({
      id: sid,
      title,
      body,
      authorId: i.user.id,
      status: 'pending',
      at: Date.now(),
    });
    setBag('suggestions.json', gid, list.slice(0, 300));

    const embed = suggestEmbed({
      title,
      body,
      author: i.user,
      status: 'pending',
    });

    if (c.suggestChannelId) {
      const chn = await i.guild.channels.fetch(c.suggestChannelId).catch(() => null);
      if (chn?.send) {
        await chn.send({
          embeds: [embed],
          components: suggestButtons(sid),
        }).catch(() => null);
      }
    }

    await i.reply({
      embeds: [
        emb('✅ Suggestion envoyée', C.success)
          .setDescription(`**${title}**\nLe staff la recevra dans ${c.suggestChannelId ? `<#${c.suggestChannelId}>` : 'le salon configuré'}.`),
      ],
      ...EPH,
    });
    return true;
  }

  
  if (id === 'mx_av_ch_report') {
    setGuild(i.guild.id, { reportChannelId: i.values[0] || null });
    await i.reply({ content: i.values[0] ? `✅ Reports → <#${i.values[0]}>` : '✅ Salon report retiré.', ...EPH });
    return true;
  }
  if (id === 'mx_av_panel_report') {
    await i.deferReply({ ...EPH });
    const msg = await i.channel.send({
      embeds: [
        emb(`${E.annonce} Panel report`, C.danger)
          .setDescription(
            [
              '### Signaler un problème',
              '',
              'Clique sur **Faire un report** pour envoyer un signalement à l’équipe.',
              'Le staff le recevra dans le salon configuré.',
              '',
              '_Abus de report = sanction possible._',
            ].join("\n")
          )
          .setFooter({ text: 'ManageX · Report' }),
      ],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('mx_report_open').setLabel('Faire un report').setStyle(ButtonStyle.Danger).setEmoji('📣'),
        ),
      ],
    });
    setGuild(i.guild.id, { reportPanelChannelId: i.channel.id, reportPanelMessageId: msg.id });
    await i.editReply({ content: `✅ Panel report → ${msg.url}` });
    return true;
  }
  if (id === 'mx_report_open') {
    const modal = new ModalBuilder().setCustomId('mx_modal_report').setTitle('Nouveau report');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('cible').setLabel('Qui / quoi ? (pseudo, salon…)').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('raison').setLabel('Description du problème').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(1000)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('preuve').setLabel('Preuve / lien (optionnel)').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(200)
      ),
    );
    await i.showModal(modal);
    return true;
  }

  return false;

}

module.exports = { command, handle, handleModal };
