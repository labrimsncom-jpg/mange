console.log('💠 ManageX v4 démarre...');

const {
  Client, GatewayIntentBits, Partials, Collection, MessageFlags,
} = require('discord.js');
const { getGlobal, setGlobal } = require('./storage.js');
const { ensureOwnerFromEnv } = require('./perms.js');

const serverConfig = require('./serverConfig.js');
const staffServer = require('./staffServer.js');
const tickets = require('./tickets.js');
const giveaway = require('./giveaway.js');
const polls = require('./polls.js');
const servavis = require('./servavis.js');
const botStaff = require('./botStaff.js');
const reste = require('./reste.js');
const antiMention = require('./antiMention.js');
const levels = require('./levels.js');
const setup = require('./setup.js');
const formulaire = require('./formulaire.js');
const reglement = require('./reglement.js');
const pickers = require('./pickers.js');

if (!process.env.DISCORD_TOKEN) {
  console.error('❌ DISCORD_TOKEN manquant');
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel, Partials.GuildMember],
});

const slashCommands = [
  serverConfig.command,
  staffServer.command,
  tickets.command,
  giveaway.command,
  polls.command,
  servavis.command,
  ...botStaff.commands,
  reste.command,
  reste.sayCommand,
  levels.command,
  setup.command,
  formulaire.command,
  reglement.command,
];

client.commands = new Collection();
for (const c of slashCommands) client.commands.set(c.data.name, c);

async function deploy() {
  const body = slashCommands.map((c) => c.data.toJSON());
  console.log(`📦 ${body.length} commandes : ${body.map((c) => c.name).join(', ')}`);
  for (const [, g] of client.guilds.cache) {
    try {
      await g.commands.set(body);
      console.log(`   ✅ ${g.name}`);
    } catch (e) {
      console.warn(`   ⚠️ ${g.name}: ${e.message}`);
    }
  }
}

let once = false;
async function onReady() {
  if (once) return;
  once = true;
  ensureOwnerFromEnv();
  console.log(`🟢 ManageX — ${client.user.tag}`);
  staffServer.startServiceWatcher(client);
  console.log(`🌐 ${client.guilds.cache.size} serveur(s)`);
  if (process.env.OWNER_ID) {
    const g = getGlobal();
    if (!g.ownerIds.includes(process.env.OWNER_ID)) {
      setGlobal({ ownerIds: [...new Set([process.env.OWNER_ID, ...g.ownerIds])] });
      console.log(`👑 Owner : ${process.env.OWNER_ID}`);
    }
  }
  await deploy();
  giveaway.resumeAll(client);
  tickets.startInactivityTicker(client);
  serverConfig.startAnnounceTicker(client);
  botStaff.startBilanTicker(client);
  console.log('💠 ManageX opérationnel');
}

client.once('clientReady', onReady);
client.once('ready', onReady);

client.on('guildCreate', async (g) => {
  const glob = getGlobal();
  setGlobal({ stats: { ...glob.stats, serversJoined: (glob.stats?.serversJoined || 0) + 1 } });
  try { await g.commands.set(slashCommands.map((c) => c.data.toJSON())); } catch {}
});
client.on('guildDelete', () => {
  const glob = getGlobal();
  setGlobal({ stats: { ...glob.stats, serversLeft: (glob.stats?.serversLeft || 0) + 1 } });
});

client.on('guildMemberAdd', (m) => serverConfig.onMemberAdd(m).catch(() => null));
client.on('guildMemberRemove', (m) => serverConfig.onMemberRemove(m).catch(() => null));
client.on('messageCreate', (m) => {
  reste.onMessage(m).catch(() => null);
  antiMention.onMessage(m).catch(() => null);
  levels.onMessage(m).catch(() => null);
  tickets.onTicketMessage(m).catch(() => null);
});

client.on('interactionCreate', async (i) => {
  try {
    if (i.isAutocomplete()) {
      const cmd = client.commands.get(i.commandName);
      if (cmd?.autocomplete) await cmd.autocomplete(i);
      return;
    }
    if (i.isChatInputCommand()) {
      const glob = getGlobal();
      setGlobal({ stats: { ...glob.stats, commandsUsed: (glob.stats?.commandsUsed || 0) + 1 } });
      const cmd = client.commands.get(i.commandName);
      if (cmd) await cmd.execute(i, client);
      return;
    }
    if (i.isModalSubmit()) {
      let ok = await serverConfig.handleModal(i);
      if (!ok) ok = await staffServer.handleModal(i);
      if (!ok) ok = await tickets.handleModal(i);
      if (!ok) ok = await giveaway.handleModal(i, client);
      if (!ok) ok = await polls.handleModal(i);
      if (!ok) ok = await servavis.handleModal(i);
      if (!ok) ok = await botStaff.handleModal(i, client);
      if (!ok) ok = await reste.handleModal(i);
      if (!ok) ok = await antiMention.handleModal(i);
      if (!ok) ok = await levels.handleModal(i);
      if (!ok) ok = await formulaire.handleModal(i);
      if (!ok) ok = await reglement.handleModal(i);
      if (!ok && !i.replied) await i.reply({ content: '⚠️ Modal', flags: MessageFlags.Ephemeral }).catch(() => null);
      return;
    }
    if (
      i.isButton() || i.isStringSelectMenu() || i.isChannelSelectMenu() ||
      i.isRoleSelectMenu() || i.isUserSelectMenu()
    ) {
      let ok = await serverConfig.handle(i);
      if (!ok) ok = await staffServer.handle(i);
      if (!ok) ok = await tickets.handle(i);
      if (!ok) ok = await giveaway.handle(i, client);
      if (!ok) ok = await polls.handle(i);
      if (!ok) ok = await servavis.handle(i);
      if (!ok) ok = await botStaff.handle(i, client);
      if (!ok) ok = await reste.handle(i);
      if (!ok) ok = await antiMention.handle(i);
      if (!ok) ok = await levels.handle(i);
      if (!ok) ok = await pickers.handle(i);
      if (!ok) ok = await formulaire.handle(i);
      if (!ok) ok = await reglement.handle(i);
      if (!ok) ok = await setup.handle(i);
      if (!ok && !i.replied && !i.deferred) {
        await i.reply({ content: `⚠️ \`${i.customId}\``, flags: MessageFlags.Ephemeral }).catch(() => null);
      }
    }
  } catch (e) {
    console.error('[interaction]', e);
    if (!i.replied && !i.deferred) {
      await i.reply({ content: `❌ ${e.message}`.slice(0, 150), flags: MessageFlags.Ephemeral }).catch(() => null);
    }
  }
});

client.on('error', (e) => console.error('[client]', e.message));
process.on('unhandledRejection', (e) => console.error('[unhandled]', e?.message || e));

client.login(process.env.DISCORD_TOKEN).catch((e) => {
  console.error('❌ Login', e.message);
  if (/disallowed intents/i.test(e.message)) {
    console.error('Active SERVER MEMBERS INTENT sur le portail Discord.');
  }
  process.exit(1);
});
