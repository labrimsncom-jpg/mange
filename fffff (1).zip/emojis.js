/**
 * Émojis APPLICATION ManageX — version ANIMÉE (<a:nom:id>)
 * Les GIFs du portail s’affichent animés dans les embeds.
 *
 * piste_decollage ≠ piste_atterrissage
 */
const E = {
  couronne: '<a:1000003115:1561479437910802452>',
  maison: '<a:1000003118:1561479436832999746>',
  gemme: '<a:1000003120:1561479435570651246>',
  cent: '<a:1000003119:1561479434329137162>',
  chargement: '<a:1000003121:1561479432888628846>',
  trefle: '<a:1000003122:1561479431246053466>',
  /** Avion DÉCOLLAGE */
  piste_decollage: '<a:1000003123:1561479428603912232>',
  /** ATTERRISSAGE */
  piste_atterrissage: '<a:1000003124:1561479426519208066>',
  ampoule: '<a:1000003125:1561479424442900653>',
  ampoule2: '<a:1000002570:1554458983262326874>',
  engrenage: '<a:1000003126:1561479422442213419>',
  engrenages: '<a:1000002583:1554458972428173373>',
  barre: '<a:1000003127:1561479418529058917>',
  question: '<a:1000003128:1561479416633237635>',
  question_violet: '<a:1000002569:1554458986391273482>',
  croix: '<a:1000003129:1561479414364246149>',
  croix_rouge: '<a:1000003129:1561479414364246149>',
  check: '<a:1000003130:1561479412392796260>',
  check_vert: '<a:1000003130:1561479412392796260>',
  check_rouge: '<a:1000002584:1554458971123879948>',
  ticket: '<a:1000003131:1561479410358419497>',
  chat: '<a:1000003132:1561479407577731112>',
  recherche: '<a:1000002566:1554458997439070268>',
  verifie: '<a:1000002567:1554458994800590848>',
  fleches: '<a:1000002568:1554458989121642566>',
  giro: '<a:1000002579:1554458980183703632>',
  inconnu: '<a:1000002580:1554458978149339217>',
  annonce: '<a:1000002581:1554458975536291940>',
  alerte: '<a:1000002582:1554458974093320322>',
  crayon: '<a:1000002585:1554458967655186442>',
};

const CFG = {
  server: E.maison,
  staff: E.verifie,
  tickets: E.ticket,
  giveaway: E.trefle,
  polls: E.chat,
  servavis: E.ampoule,
  form: E.crayon,
  levels: E.cent,
  owner: E.couronne,
  security: E.giro,
  setup: E.piste_decollage,
  ready: E.piste_atterrissage,
  ok: E.check_vert,
  no: E.croix,
  warn: E.alerte,
  search: E.recherche,
  config: E.engrenages,
  load: E.chargement,
  info: E.ampoule2,
  next: E.fleches,
};

/** Préfixe un titre avec un emoji animé si pas déjà un custom emoji */
function withAnim(title, emoji = CFG.config) {
  const t = String(title || '');
  if (/<a?:[\w~]+:\d+>/.test(t)) return t;
  return `${emoji} ${t}`.trim();
}

module.exports = { E, CFG, withAnim };
