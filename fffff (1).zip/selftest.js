/**
 * selftest.js — suite de tests ManageX (dev)
 * Vérifie modules, commandes slash, embeds, handlers, storage.
 */
const { EmbedBuilder } = require('discord.js');

function ok(msg) { return { ok: true, msg }; }
function fail(msg) { return { ok: false, msg }; }

async function runSelfTest(client) {
  const results = [];
  const t0 = Date.now();

  // 1) Load modules
  const modules = [
    'storage', 'perms', 'design', 'serverConfig', 'staffServer',
    'tickets', 'giveaway', 'polls', 'servavis', 'botStaff',
  ];
  const loaded = {};
  for (const name of modules) {
    try {
      delete require.cache[require.resolve(`./${name}.js`)];
      loaded[name] = require(`./${name}.js`);
      results.push(ok(`Module \`${name}.js\` chargé`));
    } catch (e) {
      results.push(fail(`Module \`${name}.js\` : ${e.message}`));
    }
  }

  // 2) Storage R/W
  try {
    const { getGlobal, setGlobal, getGuild, setGuild, read, write } = loaded.storage || require('./storage.js');
    const g0 = getGlobal();
    if (!g0 || typeof g0 !== 'object') throw new Error('getGlobal invalide');
    setGlobal({ ...g0 });
    const testGid = 'selftest-guild';
    setGuild(testGid, { logChannelId: '0' });
    const g1 = getGuild(testGid);
    if (g1.logChannelId !== '0') throw new Error('setGuild/getGuild KO');
    write('_selftest.json', { ok: true });
    const r = read('_selftest.json', null);
    if (!r?.ok) throw new Error('read/write KO');
    results.push(ok('Storage read/write + guild/global'));
  } catch (e) {
    results.push(fail(`Storage : ${e.message}`));
  }

  // 3) Perms functions
  try {
    const p = loaded.perms || require('./perms.js');
    for (const fn of ['isOwner', 'isCoOwner', 'isDeveloper', 'isBotStaff', 'isServerStaff', 'isAdmin']) {
      if (typeof p[fn] !== 'function') throw new Error(`${fn} manquant`);
    }
    // smoke
    p.isOwner('0');
    p.isCoOwner('0');
    results.push(ok('Perms (6 fonctions)'));
  } catch (e) {
    results.push(fail(`Perms : ${e.message}`));
  }

  // 4) Design embeds
  try {
    const { emb, C } = loaded.design || require('./design.js');
    const e = emb('Test', C.primary).setDescription('desc');
    if (!(e instanceof EmbedBuilder)) throw new Error('emb() ne renvoie pas EmbedBuilder');
    if (!e.data.title) throw new Error('title manquant');
    results.push(ok('Design embeds'));
  } catch (e) {
    results.push(fail(`Design : ${e.message}`));
  }

  // 5) Slash commands — structure Discord
  const commandList = [];
  try {
    if (loaded.serverConfig?.command) commandList.push(loaded.serverConfig.command);
    if (loaded.staffServer?.command) commandList.push(loaded.staffServer.command);
    if (loaded.tickets?.command) commandList.push(loaded.tickets.command);
    if (loaded.giveaway?.command) commandList.push(loaded.giveaway.command);
    if (loaded.polls?.command) commandList.push(loaded.polls.command);
    if (loaded.servavis?.command) commandList.push(loaded.servavis.command);
    if (loaded.botStaff?.commands) commandList.push(...loaded.botStaff.commands);

    let cmdOk = 0;
    const names = new Set();
    for (const cmd of commandList) {
      if (!cmd?.data) {
        results.push(fail('Commande sans `.data`'));
        continue;
      }
      let json;
      try {
        json = cmd.data.toJSON();
      } catch (e) {
        results.push(fail(`toJSON \`${cmd.data?.name}\` : ${e.message}`));
        continue;
      }
      if (!json.name || typeof json.name !== 'string') {
        results.push(fail('Commande sans name'));
        continue;
      }
      if (!json.description || typeof json.description !== 'string') {
        results.push(fail(`/${json.name} description manquante/invalide`));
        continue;
      }
      if (json.description.length < 1 || json.description.length > 100) {
        results.push(fail(`/${json.name} description longueur ${json.description.length}`));
        continue;
      }
      if (names.has(json.name)) {
        results.push(fail(`Doublon /${json.name}`));
        continue;
      }
      names.add(json.name);
      if (typeof cmd.execute !== 'function') {
        results.push(fail(`/${json.name} sans execute()`));
        continue;
      }
      cmdOk++;
    }
    results.push(ok(`Slash commands valides : **${cmdOk}/${commandList.length}** (\`${[...names].join('`, `')}\`)`));
  } catch (e) {
    results.push(fail(`Slash scan : ${e.message}`));
  }

  // 6) Handlers respond to unknown id with false (no throw)
  const handlers = [
    ['serverConfig.handle', loaded.serverConfig?.handle],
    ['serverConfig.handleModal', loaded.serverConfig?.handleModal],
    ['staffServer.handle', loaded.staffServer?.handle],
    ['staffServer.handleModal', loaded.staffServer?.handleModal],
    ['tickets.handle', loaded.tickets?.handle],
    ['tickets.handleModal', loaded.tickets?.handleModal],
    ['giveaway.handle', loaded.giveaway?.handle],
    ['giveaway.handleModal', loaded.giveaway?.handleModal],
    ['polls.handle', loaded.polls?.handle],
    ['polls.handleModal', loaded.polls?.handleModal],
    ['servavis.handle', loaded.servavis?.handle],
    ['servavis.handleModal', loaded.servavis?.handleModal],
    ['botStaff.handle', loaded.botStaff?.handle],
    ['botStaff.handleModal', loaded.botStaff?.handleModal],
  ];

  const fakeInteraction = {
    customId: 'mx_unknown_test_xyz',
    user: { id: '0', tag: 'Test#0' },
    member: null,
    guild: { id: '0', name: 'test' },
    channel: null,
    values: [],
    replied: false,
    deferred: false,
    reply: async () => {},
    update: async () => {},
    deferReply: async () => {},
    editReply: async () => {},
    fields: { getTextInputValue: () => '' },
  };

  for (const [label, fn] of handlers) {
    if (typeof fn !== 'function') {
      results.push(fail(`Handler manquant : ${label}`));
      continue;
    }
    try {
      const ret = await fn(fakeInteraction, client);
      if (ret !== false && ret !== true) {
        results.push(fail(`${label} doit renvoyer true/false (reçu ${ret})`));
      } else if (ret === false) {
        results.push(ok(`${label} ignore id inconnu`));
      } else {
        results.push(ok(`${label} a géré l’id test (true)`));
      }
    } catch (e) {
      results.push(fail(`${label} throw : ${e.message}`));
    }
  }

  // 7) Client state
  if (client) {
    results.push(ok(`Client prêt : **${client.user?.tag || '?'}** · ${client.guilds?.cache?.size ?? 0} serv · ping ${client.ws?.ping ?? '?'}ms`));
    if (client.commands) {
      results.push(ok(`Collection commandes client : **${client.commands.size}**`));
    }
  } else {
    results.push(fail('Client absent'));
  }

  // 8) Critical customId prefixes documented
  const prefixes = ['mx_srv_', 'mx_stf_', 'mx_svc_', 'mx_abs_', 'mx_ban_', 'mx_tk', 'mx_gw_', 'mx_poll_', 'mx_av_', 'mx_sg_', 'mx_ow_', 'mx_dev_', 'mx_bs_', 'mx_bilan_'];
  results.push(ok(`Préfixes composants couverts : ${prefixes.map((p) => `\`${p}\``).join(' ')}`));

  const passed = results.filter((r) => r.ok).length;
  const failed = results.filter((r) => !r.ok).length;
  const ms = Date.now() - t0;

  return { results, passed, failed, ms, total: results.length };
}

function reportEmbed(report) {
  const { results, passed, failed, ms, total } = report;
  const lines = results.map((r) => `${r.ok ? '✅' : '❌'} ${r.msg}`);
  // Discord embed description max 4096
  let desc = lines.join('\n');
  if (desc.length > 3800) desc = desc.slice(0, 3800) + '\n…';

  const color = failed === 0 ? 0x57f287 : failed < 3 ? 0xfee75c : 0xed4245;
  return new EmbedBuilder()
    .setColor(color)
    .setTitle(failed === 0 ? '🧪 Self-test — TOUT OK' : `🧪 Self-test — ${failed} bug(s)`)
    .setDescription(desc)
    .addFields(
      { name: 'Réussis', value: `**${passed}**/${total}`, inline: true },
      { name: 'Échecs', value: `**${failed}**`, inline: true },
      { name: 'Durée', value: `**${ms}** ms`, inline: true },
    )
    .setFooter({ text: 'ManageX · developpeurconfig' })
    .setTimestamp();
}

module.exports = { runSelfTest, reportEmbed };
