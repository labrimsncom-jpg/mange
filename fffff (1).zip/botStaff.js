// ownerconfig · developpeurconfig · botstaffconfig · rej · bilanconfig · managex
const {
  SlashCommandBuilder, PermissionFlagsBits, MessageFlags,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, UserSelectMenuBuilder,
  ChannelSelectMenuBuilder, StringSelectMenuBuilder, ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle,
} = require('discord.js');
const { getGlobal, setGlobal, getGuild } = require('./storage.js');
const { isOwner, isCoOwner, isDeveloper, isBotStaff } = require('./perms.js');
const { emb, C } = require('./design.js');
const { E, CFG } = require('./emojis.js');

const EPH = { flags: MessageFlags.Ephemeral };

const ownerCmd = {
  data: new SlashCommandBuilder()
    .setName('ownerconfig')
    .setDescription('ManageX — Owner / Co-Owner uniquement'),
  async execute(i) {
    if (!isCoOwner(i.user.id)) return i.reply({ content: '❌ Owner / Co-Owner uniquement.', ...EPH });
    const g = getGlobal();
    await i.reply({
      embeds: [emb('👑 Owner Config', C.danger)
        .setDescription('### Gestion de l’équipe **bot** ManageX\nAjoute des co-owners, devs, staff bot · annonces · lien support.')
        .addFields(
          { name: '👑 Owners', value: (g.ownerIds || []).map((id) => `<@${id}>`).join('\n') || '`—`' },
          { name: '🤝 Co-Owners', value: (g.coOwnerIds || []).map((id) => `<@${id}>`).join('\n') || '`—`', inline: true },
          { name: '🛠️ Développeurs', value: (g.developerIds || []).map((id) => `<@${id}>`).join('\n') || '`—`', inline: true },
          { name: '🛡️ Staff bot', value: (g.staffIds || []).map((id) => `<@${id}>`).join('\n') || '`—`', inline: true },
          { name: '💬 Lien support', value: g.supportInvite || '`non défini`' },
        )
        .setFooter({ text: 'ManageX · /ownerconfig' })],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('mx_ow_announce').setLabel('Annonce globale').setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId('mx_ow_support').setLabel('Lien support').setStyle(ButtonStyle.Secondary),
        ),
        new ActionRowBuilder().addComponents(
          new UserSelectMenuBuilder().setCustomId('mx_ow_add_co').setPlaceholder('Ajouter Co-Owner…').setMinValues(1).setMaxValues(1)
        ),
        new ActionRowBuilder().addComponents(
          new UserSelectMenuBuilder().setCustomId('mx_ow_add_dev').setPlaceholder('Ajouter Développeur…').setMinValues(1).setMaxValues(1)
        ),
        new ActionRowBuilder().addComponents(
          new UserSelectMenuBuilder().setCustomId('mx_ow_add_staff').setPlaceholder('Ajouter Staff bot…').setMinValues(1).setMaxValues(1)
        ),
        new ActionRowBuilder().addComponents(
          new UserSelectMenuBuilder().setCustomId('mx_ow_remove').setPlaceholder('Retirer (co/dev/staff)…').setMinValues(1).setMaxValues(1)
        ),
      ],
      ...EPH,
    });
  },
};

const devCmd = {
  data: new SlashCommandBuilder()
    .setName('developpeurconfig')
    .setDescription('ManageX — outils développeur'),
  async execute(i) {
    if (!isDeveloper(i.user.id)) return i.reply({ content: '❌ Dev / Owner uniquement.', ...EPH });
    await i.reply({
      embeds: [emb('🛠️ Développeur Config', C.warn).setDescription(
        `Ping WS **${i.client.ws.ping}ms**\nServeurs **${i.client.guilds.cache.size}**\nUptime **${Math.floor(process.uptime())}s**\nMémoire **${(process.memoryUsage().heapUsed / 1048576).toFixed(1)} Mo**`
      )],
      components: [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('mx_dev_test').setLabel('🧪 Tester tout').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('mx_dev_restart').setLabel('Restart bot').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('mx_dev_guilds').setLabel('Liste serveurs').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('mx_dev_stats').setLabel('Stats globales').setStyle(ButtonStyle.Secondary),
      )],
      ...EPH,
    });
  },
};

const botStaffCmd = {
  data: new SlashCommandBuilder()
    .setName('botstaffconfig')
    .setDescription('ManageX — commandes staff du bot (sûres)'),
  async execute(i) {
    if (!isBotStaff(i.user.id)) return i.reply({ content: '❌ Staff bot uniquement.', ...EPH });
    await i.reply({
      embeds: [emb('🛡️ Bot Staff', C.cyan).setDescription(
        'Outils utiles **sans** actions de raid (pas de ban mass, pas de wipe).'
      )],
      components: [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('mx_bs_servers').setLabel('Nb serveurs').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('mx_bs_ping').setLabel('Ping').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('mx_bs_support').setLabel('Lien support').setStyle(ButtonStyle.Success),
      )],
      ...EPH,
    });
  },
};


function sortedGuilds(client, filter = '') {
  const f = (filter || '').toLowerCase();
  return [...client.guilds.cache.values()]
    .filter((g) => !f || g.name.toLowerCase().includes(f) || g.id.includes(f))
    .sort((a, b) => (b.memberCount || 0) - (a.memberCount || 0));
}

async function sendRejInvite(i, guild) {
  const ch = guild.systemChannel
    || guild.channels.cache.find((c) => c.isTextBased?.() && c.permissionsFor(guild.members.me)?.has('CreateInstantInvite'));
  if (!ch) {
    await i.reply({ content: `❌ Pas de salon invite sur **${guild.name}**.`, ...EPH }).catch(() =>
      i.followUp({ content: `❌ Pas de salon invite sur **${guild.name}**.`, ...EPH })
    );
    return;
  }
  const inv = await ch.createInvite({ maxAge: 3600, maxUses: 1, reason: `ManageX /rej by ${i.user.tag}` });
  const embed = emb('🔗 Invitation serveur', C.primary)
    .setDescription(
      [
        `**${guild.name}**`,
        `👥 Membres : **${guild.memberCount || '?'}**`,
        `🆔 \`${guild.id}\``,
        '',
        inv.url,
      ].join('\n')
    );
  try {
    await i.user.send({ embeds: [embed] });
    const msg = { content: `✅ Lien **${guild.name}** envoyé en MP.`, ...EPH };
    if (i.replied || i.deferred) await i.followUp(msg);
    else await i.reply(msg);
  } catch {
    const msg = { embeds: [embed], ...EPH };
    if (i.replied || i.deferred) await i.followUp(msg);
    else await i.reply(msg);
  }
}

async function showRejList(i, page, filter) {
  const list = sortedGuilds(i.client, filter);
  const PER = 20;
  const maxPage = Math.max(0, Math.ceil(list.length / PER) - 1);
  page = Math.max(0, Math.min(maxPage, page));
  const slice = list.slice(page * PER, page * PER + PER);

  const lines = slice.map((g, n) => {
    const rank = page * PER + n + 1;
    return `**${rank}.** ${g.name} — 👥 **${g.memberCount || 0}**`;
  });

  const embed = emb('🌐 Serveurs ManageX', C.primary)
    .setDescription(
      [
        `Triés par **membres** (décroissant) · **${list.length}** serveur(s)`,
        filter ? `Filtre : \`${filter}\`` : '',
        `Page **${page + 1}/${maxPage + 1}**`,
        '',
        lines.join('\n') || '_Aucun serveur_',
      ].filter(Boolean).join('\n')
    )
    .setFooter({ text: 'Choisis un serveur dans le menu pour recevoir l’invite en MP' });

  const opts = slice.map((g) => ({
    label: g.name.slice(0, 100),
    value: g.id,
    description: `${g.memberCount || 0} membres`.slice(0, 100),
  }));

  const rows = [];
  if (opts.length) {
    rows.push(new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(`mx_rej_sel:${encodeURIComponent(filter || '')}`)
        .setPlaceholder('Choisir un serveur…')
        .addOptions(opts),
    ));
  }
  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`mx_rej_page:${page - 1}:${encodeURIComponent(filter || '')}`)
      .setLabel('Précédent')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('◀️')
      .setDisabled(page <= 0),
    new ButtonBuilder()
      .setCustomId(`mx_rej_page:${page + 1}:${encodeURIComponent(filter || '')}`)
      .setLabel('Suivant')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('▶️')
      .setDisabled(page >= maxPage),
  ));

  const payload = { embeds: [embed], components: rows, ...EPH };
  if (i.isMessageComponent()) await i.update(payload);
  else await i.reply(payload);
}

const rejCmd = {
  data: new SlashCommandBuilder()
    .setName('rej')
    .setDescription('ManageX — liste des serveurs (tri membres) + lien d’invitation')
    .addStringOption((o) =>
      o.setName('filtre')
        .setDescription('Filtrer par nom (optionnel)')
        .setRequired(false)
        .setAutocomplete(true)
    ),
  async execute(i) {
    if (!isBotStaff(i.user.id) && !isCoOwner(i.user.id)) {
      return i.reply({ content: '❌ Staff bot / Owner.', ...EPH });
    }
    const filter = i.options.getString('filtre') || '';
    // Si filtre = id exact → invite directe
    if (filter && i.client.guilds.cache.has(filter)) {
      return sendRejInvite(i, i.client.guilds.cache.get(filter));
    }
    await showRejList(i, 0, filter);
  },
  async autocomplete(i) {
    const focused = i.options.getFocused().toLowerCase();
    const choices = sortedGuilds(i.client, focused)
      .slice(0, 25)
      .map((g) => ({
        name: `${g.name} (${g.memberCount || 0})`.slice(0, 100),
        value: g.id,
      }));
    await i.respond(choices).catch(() => null);
  },
};

const bilanCmd = {
  data: new SlashCommandBuilder()
    .setName('bilanconfig')
    .setDescription('ManageX — bilan auto du bot + MP')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  async execute(i) {
    if (!isCoOwner(i.user.id)) return i.reply({ content: '❌ Owner / Co-Owner.', ...EPH });
    const g = getGlobal();
    await i.reply({
      embeds: [emb('📊 Bilan Config', C.primary).addFields(
        { name: 'Salon bilan', value: g.bilanChannelId ? `<#${g.bilanChannelId}>` : '*—*', inline: true },
        { name: 'Heure', value: `**${g.bilanHour ?? 21}h**`, inline: true },
      ).setDescription('Bilan quotidien (serveurs, tickets, commandes) + MP aux owners.')],
      components: [
        new ActionRowBuilder().addComponents(
          new ChannelSelectMenuBuilder().setCustomId('mx_bilan_ch').setPlaceholder('Salon bilan…')
            .addChannelTypes(ChannelType.GuildText).setMinValues(0).setMaxValues(1)
        ),
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('mx_bilan_now').setLabel('Envoyer bilan maintenant').setStyle(ButtonStyle.Success),
        ),
      ],
      ...EPH,
    });
  },
};

const hubCmd = {
  data: new SlashCommandBuilder()
    .setName('managex')
    .setDescription('ManageX — infos bot, support, stats'),
  async execute(i) {
    const g = getGlobal();
    const members = i.client.guilds.cache.reduce((s, x) => s + (x.memberCount || 0), 0);
    await i.reply({
      embeds: [
        emb('💠 ManageX', C.primary)
          .setAuthor({ name: 'ManageX', iconURL: i.client.user.displayAvatarURL({ size: 64 }) })
          .setDescription(
            [
              '### Bot de gestion multi-serveurs',
              '',
              g.supportInvite ? `💬 **Support** · ${g.supportInvite}` : '💬 **Support** · *à configurer dans /ownerconfig*',
              '',
              '**Configs serveur**',
              '`/serverconfig` · `/staffconfig` · `/ticketsconfig`',
              '`/giveawayconfig` · `/pollsconfig` · `/servavisconfig`',
              '',
              '**Bot & outils**',
              '`/managex` · `/reste` · `/ownerconfig` · `/developpeurconfig`',
            ].join('\n')
          )
          .addFields(
            { name: '🌐 Serveurs', value: `**${i.client.guilds.cache.size}**`, inline: true },
            { name: '👥 Membres', value: `**${members.toLocaleString('fr-FR')}**`, inline: true },
            { name: '🏓 Latence', value: `**${i.client.ws.ping}** ms`, inline: true },
            { name: '🎫 Tickets ouverts', value: `**${g.stats?.ticketsOpened || 0}**`, inline: true },
            { name: '🔒 Tickets fermés', value: `**${g.stats?.ticketsClosed || 0}**`, inline: true },
            { name: '⚡ Commandes utilisées', value: `**${g.stats?.commandsUsed || 0}**`, inline: true },
          )
          .setThumbnail(i.client.user.displayAvatarURL({ size: 256 }))
          .setFooter({ text: 'ManageX · /managex' }),
      ],
      ...EPH,
    });
  },
};

async function buildBilan(client) {
  const g = getGlobal();
  const members = client.guilds.cache.reduce((s, x) => s + (x.memberCount || 0), 0);
  return emb('📊 Bilan ManageX', C.primary).addFields(
    { name: 'Serveurs', value: `**${client.guilds.cache.size}** (join ${g.stats?.serversJoined || 0} / leave ${g.stats?.serversLeft || 0})`, inline: true },
    { name: 'Membres', value: `**${members}**`, inline: true },
    { name: 'Tickets', value: `ouverts **${g.stats?.ticketsOpened || 0}** · fermés **${g.stats?.ticketsClosed || 0}**`, inline: true },
    { name: 'Commandes', value: `**${g.stats?.commandsUsed || 0}**`, inline: true },
  );
}

async function sendBilan(client) {
  const g = getGlobal();
  const embed = await buildBilan(client);
  if (g.bilanChannelId) {
    const ch = await client.channels.fetch(g.bilanChannelId).catch(() => null);
    if (ch?.send) await ch.send({ embeds: [embed] }).catch(() => null);
  }
  for (const oid of [...(g.ownerIds || []), ...(g.coOwnerIds || [])]) {
    const u = await client.users.fetch(oid).catch(() => null);
    if (u) await u.send({ embeds: [embed] }).catch(() => null);
  }
}

function startBilanTicker(client) {
  setInterval(async () => {
    const g = getGlobal();
    const hour = g.bilanHour ?? 21;
    const now = new Date();
    const key = now.toISOString().slice(0, 10);
    if (now.getHours() === hour && g.lastBilanDate !== key) {
      setGlobal({ lastBilanDate: key });
      await sendBilan(client);
    }
  }, 60_000);
}

async function handle(i, client) {
  const id = i.customId || '';
  if (!id.startsWith('mx_ow_') && !id.startsWith('mx_dev_') && !id.startsWith('mx_bs_') && !id.startsWith('mx_bilan_') && !id.startsWith('mx_rej_')) return false;

  if (id.startsWith('mx_rej_page:')) {
    if (!isBotStaff(i.user.id) && !isCoOwner(i.user.id)) {
      await i.reply({ content: '❌', ...EPH });
      return true;
    }
    const parts = id.split(':');
    const page = parseInt(parts[1], 10) || 0;
    const filter = decodeURIComponent(parts.slice(2).join(':') || '');
    await showRejList(i, page, filter);
    return true;
  }
  if (id.startsWith('mx_rej_sel:')) {
    if (!isBotStaff(i.user.id) && !isCoOwner(i.user.id)) {
      await i.reply({ content: '❌', ...EPH });
      return true;
    }
    const guild = i.client.guilds.cache.get(i.values[0]);
    if (!guild) {
      await i.update({ content: 'Serveur introuvable.', embeds: [], components: [] });
      return true;
    }
    await i.update({ content: `⏳ Invitation **${guild.name}**…`, embeds: [], components: [] });
    await sendRejInvite(i, guild);
    return true;
  }


  if (id === 'mx_ow_add_co' && isOwner(i.user.id)) {
    const uid = i.values[0];
    const g = getGlobal();
    setGlobal({ coOwnerIds: [...new Set([...(g.coOwnerIds || []), uid])] });
    await i.reply({ content: `✅ <@${uid}> Co-Owner.`, ...EPH });
    return true;
  }
  if (id === 'mx_ow_add_dev' && isCoOwner(i.user.id)) {
    const uid = i.values[0];
    const g = getGlobal();
    setGlobal({ developerIds: [...new Set([...(g.developerIds || []), uid])] });
    await i.reply({ content: `✅ <@${uid}> Développeur.`, ...EPH });
    return true;
  }
  if (id === 'mx_ow_add_staff' && isCoOwner(i.user.id)) {
    const uid = i.values[0];
    const g = getGlobal();
    setGlobal({ staffIds: [...new Set([...(g.staffIds || []), uid])] });
    await i.reply({ content: `✅ <@${uid}> Staff bot.`, ...EPH });
    return true;
  }
  if (id === 'mx_ow_remove' && isOwner(i.user.id)) {
    const uid = i.values[0];
    const g = getGlobal();
    setGlobal({
      coOwnerIds: (g.coOwnerIds || []).filter((x) => x !== uid),
      developerIds: (g.developerIds || []).filter((x) => x !== uid),
      staffIds: (g.staffIds || []).filter((x) => x !== uid),
    });
    await i.reply({ content: `✅ <@${uid}> retiré.`, ...EPH });
    return true;
  }
  if (id === 'mx_ow_support' && isCoOwner(i.user.id)) {
    const modal = new ModalBuilder().setCustomId('mx_modal_support').setTitle('Lien support');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('url').setLabel('Invite Discord').setStyle(TextInputStyle.Short).setRequired(true)
        .setValue(getGlobal().supportInvite || '')
    ));
    await i.showModal(modal);
    return true;
  }
  if (id === 'mx_ow_announce' && isCoOwner(i.user.id)) {
    const modal = new ModalBuilder().setCustomId('mx_modal_gannounce').setTitle('Annonce owners');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('text').setLabel('Message (MP owners/co)').setStyle(TextInputStyle.Paragraph).setRequired(true)
    ));
    await i.showModal(modal);
    return true;
  }

  if (id === 'mx_dev_test' && isDeveloper(i.user.id)) {
    await i.deferReply({ ...EPH });
    try {
      const { runSelfTest, reportEmbed } = require('./selftest.js');
      const report = await runSelfTest(i.client);
      await i.editReply({ embeds: [reportEmbed(report)] });
      // MP owner un résumé si bugs
      if (report.failed > 0) {
        const bugs = report.results.filter((r) => !r.ok).map((r) => `• ${r.msg}`).join('\n');
        console.error('[selftest] BUGS:\n' + bugs);
      } else {
        console.log(`[selftest] OK ${report.passed}/${report.total} en ${report.ms}ms`);
      }
    } catch (e) {
      await i.editReply({ content: `❌ Self-test crash : ${e.message}` });
    }
    return true;
  }
  if (id === 'mx_dev_restart' && isDeveloper(i.user.id)) {
    await i.reply({ content: '♻️ Restart…', ...EPH });
    setTimeout(() => process.exit(0), 1000);
    return true;
  }
  if (id === 'mx_dev_guilds' && isDeveloper(i.user.id)) {
    const lines = [...i.client.guilds.cache.values()].slice(0, 30).map((g, n) => `**${n + 1}.** ${g.name} (\`${g.id}\`)`).join('\n');
    await i.reply({ embeds: [emb('Serveurs', C.warn).setDescription(lines)], ...EPH });
    return true;
  }
  if (id === 'mx_dev_stats' && isDeveloper(i.user.id)) {
    await i.reply({ embeds: [await buildBilan(i.client)], ...EPH });
    return true;
  }

  if (id === 'mx_bs_servers' && isBotStaff(i.user.id)) {
    await i.reply({ content: `🌐 **${i.client.guilds.cache.size}** serveurs`, ...EPH });
    return true;
  }
  if (id === 'mx_bs_ping' && isBotStaff(i.user.id)) {
    await i.reply({ content: `🏓 **${i.client.ws.ping}ms**`, ...EPH });
    return true;
  }
  if (id === 'mx_bs_support' && isBotStaff(i.user.id)) {
    await i.reply({ content: getGlobal().supportInvite || 'Non configuré.', ...EPH });
    return true;
  }

  if (id === 'mx_bilan_ch' && isCoOwner(i.user.id)) {
    setGlobal({ bilanChannelId: i.values[0] || null });
    await i.reply({ content: '✅ Salon bilan OK.', ...EPH });
    return true;
  }
  if (id === 'mx_bilan_now' && isCoOwner(i.user.id)) {
    await i.deferReply({ ...EPH });
    await sendBilan(i.client);
    await i.editReply({ content: '✅ Bilan envoyé.' });
    return true;
  }
  return false;
}

async function handleModal(i, client) {
  if (i.customId === 'mx_modal_support' && isCoOwner(i.user.id)) {
    setGlobal({ supportInvite: i.fields.getTextInputValue('url') });
    await i.reply({ content: '✅ Lien support OK.', ...EPH });
    return true;
  }
  if (i.customId === 'mx_modal_gannounce' && isCoOwner(i.user.id)) {
    const text = i.fields.getTextInputValue('text');
    const g = getGlobal();
    let n = 0;
    for (const oid of [...new Set([...(g.ownerIds || []), ...(g.coOwnerIds || [])])]) {
      const u = await client.users.fetch(oid).catch(() => null);
      if (u) { await u.send({ embeds: [emb('📢 Annonce ManageX', C.primary).setDescription(text)] }).catch(() => null); n++; }
    }
    await i.reply({ content: `✅ Envoyé à ${n} personne(s).`, ...EPH });
    return true;
  }
  return false;
}

module.exports = {
  commands: [ownerCmd, devCmd, botStaffCmd, rejCmd, bilanCmd, hubCmd],
  handle, handleModal, startBilanTicker, sendBilan,
};
