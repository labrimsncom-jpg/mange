const {
  SlashCommandBuilder, PermissionFlagsBits, MessageFlags, ChannelType,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder,
  ChannelSelectMenuBuilder, RoleSelectMenuBuilder, UserSelectMenuBuilder,
  ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder, AttachmentBuilder,
} = require('discord.js');
// AttachmentBuilder used for transcripts
const { getGuild, setGuild, bag, setBag, getGlobal, setGlobal } = require('./storage.js');
const { isAdmin, isServerStaff } = require('./perms.js');
const { emb, C, PRIORITY, configCard, ch, roles } = require('./design.js');
const { openBtn } = require('./pickers.js');
const { E, CFG } = require('./emojis.js');

const EPH = { flags: MessageFlags.Ephemeral };
const pending = new Map(); // userId -> { categoryId, guildId, priority? }

/** Emoji valide pour StringSelect (sinon Discord rejette le message) */
function selectEmoji(raw) {
  if (!raw) return undefined;
  const s = String(raw).trim();
  if (!s) return undefined;
  const m = s.match(/^<(a?):([a-zA-Z0-9_]+):(\d+)>$/);
  if (m) return { id: m[3], name: m[2], animated: m[1] === 'a' };
  // unicode court uniquement
  const chars = [...s];
  if (chars.length >= 1 && chars.length <= 8 && !s.includes('<') && !s.includes(':')) return s;
  return undefined;
}


function canSupport(member, c, ticket = null) {
  if (!member) return false;
  if (isServerStaff(member)) return true;
  if ((c.ticketSupportRoleIds || []).some((r) => member.roles.cache.has(r))) return true;
  // Rôles de la catégorie du ticket
  if (ticket?.categoryId) {
    const cat = (c.ticketCategories || []).find((x) => x.id === ticket.categoryId);
    if (cat?.supportRoleIds?.some((r) => member.roles.cache.has(r))) return true;
  }
  return false;
}

function panelEmbed(guild) {
  const c = getGuild(guild.id);
  const open = (c.ticketCategories || []).filter((x) => !x.closed);
  const closed = (c.ticketCategories || []).filter((x) => x.closed);

  let body = [
    '### 🎫 Centre d’assistance',
    '',
    'Sélectionne une **catégorie**, puis indique le **sujet** et la **priorité**.',
    'Un salon privé sera créé pour toi et le staff.',
    '',
  ].join('\n');

  if (open.length) {
    body += '**Catégories disponibles**\n';
    body += open.map((x) => {
      const r = (x.supportRoleIds || []).map((id) => `<@&${id}>`).join(' ');
      return r
        ? `> ${x.emoji || '▫️'} **${x.label}** · ${r}`
        : `> ${x.emoji || '▫️'} **${x.label}**`;
    }).join('\n');
  } else {
    body += '⚠️ *Aucune catégorie ouverte pour le moment.*';
  }
  if (closed.length) {
    body += '\n\n**Temporairement fermées**\n';
    body += closed.map((x) => `> 🔒 ~~${x.label}~~`).join('\n');
  }

  return new EmbedBuilder()
    .setColor(C.ticket)
    .setAuthor({ name: guild.name, iconURL: guild.iconURL({ size: 64 }) || undefined })
    .setTitle('🎫 Centre d’assistance')
    .setDescription(body)
    .setThumbnail(guild.iconURL({ size: 256 }))
    .addFields(
      { name: '📌 Comment ça marche', value: '1️⃣ Catégorie → 2️⃣ Priorité → 3️⃣ Sujet & détails → 4️⃣ Salon privé créé', inline: false },
    )
    .setFooter({ text: 'ManageX Tickets · une demande = un ticket' })
    .setTimestamp();
}

function panelComps(gid) {
  const open = (getGuild(gid).ticketCategories || []).filter((x) => !x.closed);
  if (!open.length) {
    return [new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('mx_tk_noop').setLabel('Aucune catégorie — configure d\'abord').setStyle(ButtonStyle.Secondary).setDisabled(true),
    )];
  }
  // Pas d'emoji custom sur les options (Discord rejette souvent) — emoji dans le label seulement
  const options = open.slice(0, 25).map((x) => {
    const em = String(x.emoji || '').trim();
    const unicodeOnly = em && !em.includes('<') && !em.includes(':') ? em + ' ' : '';
    return {
      label: `${unicodeOnly}${x.label || 'Catégorie'}`.slice(0, 100),
      value: String(x.id),
      description: 'Ouvrir un ticket',
    };
  }).filter((o) => o.value && o.label);
  if (!options.length) {
    return [new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('mx_tk_noop').setLabel('Catégories invalides').setStyle(ButtonStyle.Secondary).setDisabled(true),
    )];
  }
  return [new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('mx_tk_open')
      .setPlaceholder('📩 Choisir une catégorie…')
      .addOptions(options),
  )];
}

async function resetPanel(interaction) {
  try {
    if (interaction.message?.editable) {
      await interaction.message.edit({
        embeds: [panelEmbed(interaction.guild)],
        components: panelComps(interaction.guild.id),
      });
      return;
    }
  } catch {}
  const c = getGuild(interaction.guild.id);
  if (c.ticketPanelChannelId && c.ticketPanelMessageId) {
    const chn = await interaction.guild.channels.fetch(c.ticketPanelChannelId).catch(() => null);
    const msg = chn && await chn.messages.fetch(c.ticketPanelMessageId).catch(() => null);
    if (msg) {
      await msg.edit({
        embeds: [panelEmbed(interaction.guild)],
        components: panelComps(interaction.guild.id),
      }).catch(() => null);
    }
  }
}

function ticketControls(t) {
  const pri = PRIORITY[t.priority] || PRIORITY.normal;
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('mx_tk_claim').setLabel(t.claimedBy ? 'Re-claim' : 'Prendre en charge').setStyle(ButtonStyle.Primary).setEmoji('✋'),
      new ButtonBuilder().setCustomId('mx_tk_prio').setLabel('Priorité').setStyle(ButtonStyle.Secondary).setEmoji(selectEmoji(pri.emoji) || '🟡'),
      new ButtonBuilder().setCustomId('mx_tk_add').setLabel('Ajouter').setStyle(ButtonStyle.Secondary).setEmoji('➕'),
      new ButtonBuilder().setCustomId('mx_tk_rename').setLabel('Renommer').setStyle(ButtonStyle.Secondary).setEmoji('✏️'),
      new ButtonBuilder().setCustomId('mx_tk_note').setLabel('Note staff').setStyle(ButtonStyle.Secondary).setEmoji('📝'),
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('mx_tk_close').setLabel('Fermer').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
    ),
  ];
}

function ticketWelcomeEmbed(user, cat, form, num, priority) {
  const pri = PRIORITY[priority] || PRIORITY.normal;
  return new EmbedBuilder()
    .setColor(pri.color)
    .setAuthor({ name: `${user.tag}`, iconURL: user.displayAvatarURL({ size: 64 }) })
    .setTitle(`${cat.emoji || '🎫'} Ticket #${String(num).padStart(4, '0')} — ${cat.label}`)
    .setDescription(
      [
        `### Bienvenue ${user}`,
        '',
        'Un membre du **support** va te répondre ici.',
        'Merci d’être clair et patient.',
        '',
        `**${pri.emoji} Priorité** · ${pri.label}`,
        form.subject ? `**📋 Sujet** · ${form.subject}` : null,
      ].filter(Boolean).join('\n')
    )
    .addFields(
      { name: '👤 Auteur', value: `${user}\n\`${user.id}\``, inline: true },
      { name: '📂 Catégorie', value: `**${cat.label}**\n\`${cat.id}\``, inline: true },
      { name: '🕐 Ouverture', value: `<t:${Math.floor(Date.now() / 1000)}:f>\n<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
      ...(form.details ? [{ name: '📝 Détails de la demande', value: form.details.slice(0, 1000) }] : []),
    )
    .setThumbnail(user.displayAvatarURL({ size: 256 }))
    .setFooter({ text: 'ManageX Tickets · Claim · Priorité · Ajouter · Renommer · Note · Fermer' })
    .setTimestamp();
}

const command = {
  data: new SlashCommandBuilder()
    .setName('ticketsconfig')
    .setDescription('ManageX — configuration complète des tickets')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(i) {
    if (!isAdmin(i.member)) return i.reply({ content: '❌ Administrateur requis.', ...EPH });
    const c = getGuild(i.guild.id);
    const cats = (c.ticketCategories || [])
      .map((x) => {
        const roles = (x.supportRoleIds || []).map((id) => `<@&${id}>`).join(' ') || '*aucun rôle*';
        return `${x.closed ? '🔒' : '🟢'} ${x.emoji || '•'} **${x.label}**\n　　🎭 Support : ${roles}`;
      })
      .join('\n') || '*Aucune — ajoute-en avec + Catégorie*';

    await i.reply({
      embeds: [
        configCard(
          `${E.ticket} Tickets Config`,
          'Configure le panel, les catégories Discord, les rôles support et les options.',
          [
            { name: '📁 Catégorie Discord', value: ch(c.ticketCategoryId), inline: true },
            { name: '📜 Logs', value: ch(c.ticketLogChannelId), inline: true },
            { name: '👥 Max / user', value: (!c.maxTicketsPerUser ? '**Illimité**' : `**${c.maxTicketsPerUser}**`), inline: true },
            { name: '🛡️ Rôles support', value: roles(c.ticketSupportRoleIds) },
            { name: '📂 Catégories panel', value: cats },
          ],
          C.ticket
        ),
      ],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('mx_tkcfg_panel').setLabel('Poster le panel').setStyle(ButtonStyle.Success).setEmoji('📨'),
          new ButtonBuilder().setCustomId('mx_tkcfg_addcat').setLabel('Ajouter').setStyle(ButtonStyle.Primary).setEmoji('➕'),
          new ButtonBuilder().setCustomId('mx_tkcfg_delcat').setLabel('Supprimer').setStyle(ButtonStyle.Danger).setEmoji('🗑️'),
          new ButtonBuilder().setCustomId('mx_tkcfg_toggle').setLabel('Ouvrir/Fermer').setStyle(ButtonStyle.Secondary).setEmoji('🔒'),
          new ButtonBuilder().setCustomId('mx_tkcfg_max').setLabel('Max').setStyle(ButtonStyle.Secondary),
        ),
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('mx_tkcfg_catrole').setLabel('Rôles / cat.').setStyle(ButtonStyle.Primary).setEmoji('🎭'),
          new ButtonBuilder().setCustomId('mx_tkcfg_inactivity').setLabel('Inactivité').setStyle(ButtonStyle.Secondary).setEmoji('⏰'),
        ),
        new ActionRowBuilder().addComponents(
          openBtn('ch', 'tk_cat', '📁 Catégorie Discord tickets'),
          openBtn('ch', 'tk_log', '📜 Salon logs tickets'),
        ),
        new ActionRowBuilder().addComponents(
          openBtn('role', 'tk_roles', '🛡️ Rôles support tickets'),
        ),
      ],
      ...EPH,
    });
  },
};


async function buildTranscript(channel, t, closer) {
  const lines = [];
  lines.push('═══════════════════════════════════════');
  lines.push(' ManageX — Transcript ticket');
  lines.push('═══════════════════════════════════════');
  lines.push(`Salon     : #${channel.name} (${channel.id})`);
  lines.push(`Auteur    : ${t?.openerId || '?'} `);
  lines.push(`Catégorie : ${t?.categoryLabel || t?.categoryId || '—'}`);
  lines.push(`Priorité  : ${t?.priority || 'normal'}`);
  lines.push(`Sujet     : ${t?.subject || '—'}`);
  lines.push(`Claim     : ${t?.claimedBy || '—'}`);
  lines.push(`Fermé par : ${closer?.id || closer || '?'}`);
  lines.push(`Raison    : ${t?.closeReason || '—'}`);
  if (t?.staffNote) lines.push(`Note staff: ${t.staffNote}`);
  lines.push(`Date      : ${new Date().toISOString()}`);
  lines.push('───────────────────────────────────────');
  lines.push('');

  let lastId;
  const all = [];
  for (let i = 0; i < 15; i++) {
    const batch = await channel.messages.fetch({ limit: 100, ...(lastId ? { before: lastId } : {}) }).catch(() => null);
    if (!batch || batch.size === 0) break;
    const arr = [...batch.values()];
    all.push(...arr);
    lastId = arr[arr.length - 1].id;
    if (batch.size < 100) break;
  }
  all.sort((a, b) => a.createdTimestamp - b.createdTimestamp);

  for (const msg of all) {
    const time = new Date(msg.createdTimestamp).toISOString().replace('T', ' ').slice(0, 19);
    const author = `${msg.author?.tag || msg.author?.id || 'inconnu'} (${msg.author?.id || '?'})`;
    let content = (msg.content || '').replace(/\r/g, '');
    if (msg.attachments?.size) {
      content += (content ? '\n' : '') + [...msg.attachments.values()].map((a) => `[fichier] ${a.url}`).join('\n');
    }
    if (msg.embeds?.length && !content) content = `[embed x${msg.embeds.length}]`;
    if (!content) content = '[vide]';
    lines.push(`[${time}] ${author}`);
    lines.push(content);
    lines.push('');
  }
  lines.push('═══════════════════════════════════════');
  lines.push(`Messages : ${all.length}`);
  return lines.join('\n');
}


/** Discord limite 50 salons / catégorie → overflow auto */
async function resolveTicketParent(guild, c) {
  const ids = [];
  if (c.ticketCategoryId) ids.push(c.ticketCategoryId);
  for (const id of c.ticketOverflowParents || []) {
    if (id && !ids.includes(id)) ids.push(id);
  }
  for (const pid of ids) {
    const cat = guild.channels.cache.get(pid) || await guild.channels.fetch(pid).catch(() => null);
    if (!cat) continue;
    const count = guild.channels.cache.filter((ch) => ch.parentId === pid).size;
    if (count < 48) return pid; // marge avant le hard-limit 50
  }
  // Nouvelle catégorie overflow
  let baseName = 'Tickets';
  if (c.ticketCategoryId) {
    const base = guild.channels.cache.get(c.ticketCategoryId) || await guild.channels.fetch(c.ticketCategoryId).catch(() => null);
    if (base?.name) baseName = base.name.replace(/\s*\(\d+\)\s*$/, '');
  }
  const n = (c.ticketOverflowParents || []).length + 2;
  const created = await guild.channels.create({
    name: `${baseName} (${n})`.slice(0, 100),
    type: ChannelType.GuildCategory,
    reason: 'ManageX — débordement tickets (limite 50 salons/catégorie Discord)',
  }).catch(() => null);
  if (!created) return c.ticketCategoryId || undefined;
  const overflow = [...(c.ticketOverflowParents || []), created.id];
  setGuild(guild.id, { ticketOverflowParents: overflow });
  console.log(`[tickets] overflow category ${created.name} on ${guild.name}`);
  return created.id;
}

async function createTicket(guild, user, cat, form, priority = 'normal') {
  const c = getGuild(guild.id);
  const num = (c.ticketCounter || 0) + 1;
  setGuild(guild.id, { ticketCounter: num });

  const pri = PRIORITY[priority] || PRIORITY.normal;
  const slug = `${pri.emoji.replace(/\p{Extended_Pictographic}/gu, '') || 't'}-${num}-${user.username}`
    .toLowerCase()
    .replace(/[^a-z0-9-]/g, '')
    .slice(0, 90) || `ticket-${num}`;

  const perms = [
    PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.ReadMessageHistory,
    PermissionFlagsBits.AttachFiles,
    PermissionFlagsBits.EmbedLinks,
  ];
  const overs = [
    { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
    { id: user.id, allow: perms },
    { id: guild.members.me.id, allow: [...perms, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageMessages] },
  ];
  for (const r of c.ticketSupportRoleIds || []) overs.push({ id: r, allow: perms });
  // Rôles spécifiques à la catégorie
  for (const r of cat.supportRoleIds || []) {
    if (!(c.ticketSupportRoleIds || []).includes(r)) overs.push({ id: r, allow: perms });
  }

  const parentId = await resolveTicketParent(guild, c);
  const channel = await guild.channels.create({
    name: slug.slice(0, 100),
    type: ChannelType.GuildText,
    parent: parentId || undefined,
    permissionOverwrites: overs,
    topic: `ManageX #${num} · ${user.tag} · ${cat.label} · ${pri.label}`,
  });

  const ticket = {
    channelId: channel.id,
    guildId: guild.id,
    number: num,
    openerId: user.id,
    categoryId: cat.id,
    categoryLabel: cat.label,
    subject: form.subject || null,
    details: form.details || null,
    priority,
    claimedBy: null,
    staffNote: null,
    closed: false,
    createdAt: Date.now(),
    lastActivityAt: Date.now(),
    inactivityWarnedAt: null,
    inactivityKeep: false,
  };
  const map = bag('tickets.json', guild.id);
  const data = typeof map === 'object' && !Array.isArray(map) ? map : {};
  data[channel.id] = ticket;
  setBag('tickets.json', guild.id, data);

  const g = getGlobal();
  setGlobal({ stats: { ...g.stats, ticketsOpened: (g.stats?.ticketsOpened || 0) + 1 } });

  const mentionIds = [...new Set([
    ...(c.ticketSupportRoleIds || []),
    ...(cat.supportRoleIds || []),
  ])];
  const mention = mentionIds.map((id) => `<@&${id}>`).join(' ') || null;
  await channel.send({
    content: mention,
    embeds: [ticketWelcomeEmbed(user, cat, form, num, priority)],
    components: ticketControls(ticket),
  });

  if (c.ticketLogChannelId) {
    const log = await guild.channels.fetch(c.ticketLogChannelId).catch(() => null);
    if (log?.send) {
      await log.send({
        embeds: [
          emb('🎫 Ticket ouvert', C.success)
            .addFields(
              { name: 'N°', value: `#${num}`, inline: true },
              { name: 'Auteur', value: `${user}`, inline: true },
              { name: 'Priorité', value: `${pri.emoji} ${pri.label}`, inline: true },
              { name: 'Catégorie', value: cat.label, inline: true },
              { name: 'Salon', value: `${channel}`, inline: true },
              { name: 'Sujet', value: form.subject || '—' },
            ),
        ],
      }).catch(() => null);
    }
  }

  return channel;
}

async function handle(i) {
  const id = i.customId || '';
  if (!id.startsWith('mx_tk')) return false;
  const gid = i.guild.id;
  const c = getGuild(gid);

  // ── Config ──
  if (id.startsWith('mx_tkcfg_')) {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌ Admin.', ...EPH }); return true; }

    if (id === 'mx_tkcfg_panel') {
      await i.deferReply({ ...EPH });
      try {
        const cats = getGuild(gid).ticketCategories || [];
        if (!cats.length) {
          await i.editReply({ content: '❌ Ajoute d’abord **au moins une catégorie** (bouton Catégories) avant de poster le panel.' });
          return true;
        }
        const comps = panelComps(gid);
        const msg = await i.channel.send({
          embeds: [panelEmbed(i.guild)],
          components: comps,
        });
        setGuild(gid, { ticketPanelChannelId: i.channel.id, ticketPanelMessageId: msg.id });
        await i.editReply({ content: `✅ Panel posté → ${msg.url}` });
      } catch (e) {
        console.error('[tickets] panel post', e);
        await i.editReply({
          content: `❌ Impossible de poster le panel : \`${(e.message || e).toString().slice(0, 180)}\`\nVérifie les emojis des catégories (unicode simple) et les permissions **Envoyer des messages / Embeds**.`,
        }).catch(() => null);
      }
      return true;
    }
    if (id === 'mx_tkcfg_cat') {
      setGuild(gid, { ticketCategoryId: i.values[0] });
      await i.reply({ content: `✅ Catégorie Discord : <#${i.values[0]}>`, ...EPH });
      return true;
    }
    if (id === 'mx_tkcfg_log') {
      setGuild(gid, { ticketLogChannelId: i.values[0] || null });
      await i.reply({ content: '✅ Salon logs tickets enregistré.', ...EPH });
      return true;
    }
    if (id === 'mx_tkcfg_roles_clear') {
      setGuild(gid, { ticketSupportRoleIds: [] });
      await i.reply({ content: '✅ Tous les **rôles support globaux** ont été retirés.', ...EPH });
      return true;
    }
    if (id === 'mx_tkcfg_roles') {
      setGuild(gid, { ticketSupportRoleIds: i.values || [] });
      await i.reply({ content: `✅ Rôles support : ${(i.values || []).length}`, ...EPH });
      return true;
    }
    if (id === 'mx_tkcfg_addcat') {
      const modal = new ModalBuilder().setCustomId('mx_modal_tkcat').setTitle('Nouvelle catégorie ticket');
      modal.addComponents(
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('id').setLabel('ID technique (ex: boutique)').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(30)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('label').setLabel('Nom affiché').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(80)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('emoji').setLabel('Emoji').setStyle(TextInputStyle.Short).setValue('💬').setMaxLength(32)),
      );
      await i.showModal(modal);
      return true;
    }
    if (id === 'mx_tkcfg_delcat') {
      const cats = c.ticketCategories || [];
      if (!cats.length) { await i.reply({ content: 'Aucune catégorie.', ...EPH }); return true; }
      await i.reply({
        embeds: [emb('🗑️ Supprimer une catégorie', C.danger)
          .setDescription('La catégorie sera **retirée du panel**. Les tickets déjà ouverts ne sont pas fermés.')],
        components: [new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder().setCustomId('mx_tkcfg_delcat_pick').setPlaceholder('Catégorie à supprimer…')
            .addOptions(cats.slice(0, 25).map((x) => ({
              label: x.label.slice(0, 100),
              value: x.id,
              emoji: x.emoji || undefined,
              description: x.closed ? 'Fermée' : 'Ouverte',
            })))
        )],
        ...EPH,
      });
      return true;
    }
    if (id === 'mx_tkcfg_delcat_pick') {
      const catId = i.values[0];
      const cats = (c.ticketCategories || []).filter((x) => x.id !== catId);
      const removed = (c.ticketCategories || []).find((x) => x.id === catId);
      setGuild(gid, { ticketCategories: cats });
      await i.update({
        content: `🗑️ Catégorie **${removed?.label || catId}** supprimée.`,
        embeds: [],
        components: [],
      });
      // refresh panel
      if (c.ticketPanelChannelId && c.ticketPanelMessageId) {
        const chn = await i.guild.channels.fetch(c.ticketPanelChannelId).catch(() => null);
        const msg = chn && await chn.messages.fetch(c.ticketPanelMessageId).catch(() => null);
        if (msg) await msg.edit({ embeds: [panelEmbed(i.guild)], components: panelComps(gid) }).catch(() => null);
      }
      return true;
    }
    if (id === 'mx_tkcfg_catrole') {
      const cats = c.ticketCategories || [];
      if (!cats.length) { await i.reply({ content: 'Aucune catégorie.', ...EPH }); return true; }
      await i.reply({
        embeds: [emb('🎭 Rôle support par catégorie', C.ticket)
          .setDescription('Choisis une catégorie, puis le(s) rôle(s) qui y ont accès (en plus des rôles support globaux).')],
        components: [new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder().setCustomId('mx_tkcfg_catrole_pick').setPlaceholder('Catégorie…')
            .addOptions(cats.slice(0, 25).map((x) => ({
              label: x.label.slice(0, 100),
              value: x.id,
              description: (x.supportRoleIds || []).length ? `${(x.supportRoleIds || []).length} rôle(s)` : 'Aucun rôle spécifique',
            })))
        )],
        ...EPH,
      });
      return true;
    }
    if (id === 'mx_tkcfg_catrole_pick') {
      // store pending category in custom... use pending map
      const pending = global.__mxTkCatRole || (global.__mxTkCatRole = new Map());
      pending.set(i.user.id, i.values[0]);
      await i.update({
        content: `Catégorie \`${i.values[0]}\` — choisis les rôles support :`,
        embeds: [],
        components: [new ActionRowBuilder().addComponents(
          new RoleSelectMenuBuilder().setCustomId('mx_tkcfg_catrole_roles').setPlaceholder('Rôles pour cette catégorie…')
            .setMinValues(0).setMaxValues(10)
        )],
      });
      return true;
    }
    if (id === 'mx_tkcfg_catrole_roles') {
      const pending = global.__mxTkCatRole || new Map();
      const catId = pending.get(i.user.id);
      pending.delete(i.user.id);
      if (!catId) { await i.reply({ content: 'Session expirée.', ...EPH }); return true; }
      const cats = (c.ticketCategories || []).map((x) =>
        x.id === catId ? { ...x, supportRoleIds: i.values || [] } : x
      );
      setGuild(gid, { ticketCategories: cats });
      const cat = cats.find((x) => x.id === catId);
      await i.update({
        content: `✅ **${cat?.label || catId}** → ${(i.values || []).map((id) => `<@&${id}>`).join(' ') || '*aucun rôle spécifique*'}`,
        components: [],
      });
      return true;
    }
  
    if (id === 'mx_tkcfg_inactivity') {
      const on = c.ticketInactivityEnabled !== false;
      const modal = new ModalBuilder().setCustomId('mx_modal_tkinact').setTitle('Inactivité tickets');
      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('enabled').setLabel('Activé ? (oui/non)').setStyle(TextInputStyle.Short)
            .setValue(on ? 'oui' : 'non').setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('warn').setLabel('Heures avant message « besoin ? »').setStyle(TextInputStyle.Short)
            .setValue(String(c.ticketWarnAfterHours ?? 24)).setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('close').setLabel('Heures après warning → fermeture').setStyle(TextInputStyle.Short)
            .setValue(String(c.ticketCloseAfterWarnHours ?? 24)).setRequired(true)
        ),
      );
      await i.showModal(modal);
      return true;
    }

  if (id === 'mx_tkcfg_max') {
      const modal = new ModalBuilder().setCustomId('mx_modal_tkmax').setTitle('Max tickets / membre');
      modal.addComponents(new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('n').setLabel('Max / membre (0 = illimité)').setStyle(TextInputStyle.Short).setValue(String(c.maxTicketsPerUser ?? 0)).setRequired(true)
      ));
      await i.showModal(modal);
      return true;
    }
    if (id === 'mx_tkcfg_toggle') {
      const cats = c.ticketCategories || [];
      if (!cats.length) { await i.reply({ content: 'Aucune catégorie.', ...EPH }); return true; }
      await i.reply({
        embeds: [emb('🔒 Ouvrir / Fermer une catégorie', C.warn).setDescription('Une catégorie fermée devient **rouge / barrée** sur le panel.')],
        components: [new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder().setCustomId('mx_tkcfg_toggle_pick').setPlaceholder('Catégorie…')
            .addOptions(cats.map((x) => ({
              label: `${x.closed ? '🔒 ' : '🟢 '}${x.label}`.slice(0, 100),
              value: x.id,
            })))
        )],
        ...EPH,
      });
      return true;
    }
    if (id === 'mx_tkcfg_toggle_pick') {
      const cats = (c.ticketCategories || []).map((x) => (x.id === i.values[0] ? { ...x, closed: !x.closed } : x));
      setGuild(gid, { ticketCategories: cats });
      const t = cats.find((x) => x.id === i.values[0]);
      await i.update({
        content: t?.closed ? `🔒 **${t.label}** est maintenant **fermée**.` : `🟢 **${t?.label}** est **ouverte**.`,
        embeds: [],
        components: [],
      });
      if (c.ticketPanelChannelId && c.ticketPanelMessageId) {
        const chn = await i.guild.channels.fetch(c.ticketPanelChannelId).catch(() => null);
        const msg = chn && await chn.messages.fetch(c.ticketPanelMessageId).catch(() => null);
        if (msg) await msg.edit({ embeds: [panelEmbed(i.guild)], components: panelComps(gid) }).catch(() => null);
      }
      return true;
    }
  }

  // ── Open flow ──
  if (id === 'mx_tk_open') {
    const cat = (c.ticketCategories || []).find((x) => x.id === i.values[0]);
    if (!cat || cat.closed) {
      await i.reply({ content: '❌ Catégorie indisponible.', ...EPH });
      await resetPanel(i);
      return true;
    }
    const tickets = bag('tickets.json', gid) || {};
    const openCount = Object.values(tickets).filter((t) => t && !t.closed && t.openerId === i.user.id).length;
    // 0 ou ticketUnlimited = illimité (défaut)
    const maxT = c.maxTicketsPerUser == null ? 0 : Number(c.maxTicketsPerUser);
    const unlimited = c.ticketUnlimited === true || maxT === 0 || maxT < 0;
    if (!unlimited && openCount >= maxT) {
      await i.reply({ content: `❌ Tu as déjà **${openCount}** ticket(s) ouvert(s) (max ${maxT}).`, ...EPH });
      await resetPanel(i);
      return true;
    }
    pending.set(i.user.id, { categoryId: cat.id, guildId: gid });
    // priorité d'abord
    await i.reply({
      embeds: [
        emb(`${cat.emoji || '🎫'} ${cat.label}`, C.ticket)
          .setDescription(
            '**Choisis la priorité** de ta demande.\n\n' +
            '⚠️ *Les tickets troll en priorité haute/urgente peuvent être sanctionnés.*'
          ),
      ],
      components: [new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId('mx_tk_prio_pick').setPlaceholder('Priorité…')
          .addOptions(
            { label: 'Basse', value: 'low', emoji: '🟢', description: 'Pas urgent' },
            { label: 'Normale', value: 'normal', emoji: '🔵', description: 'Demande standard' },
            { label: 'Haute', value: 'high', emoji: '🟠', description: 'Important' },
            { label: 'Urgente', value: 'urgent', emoji: '🔴', description: 'Critique — ne pas abuser' },
          )
      )],
      ...EPH,
    });
    setTimeout(() => resetPanel(i), 1200);
    return true;
  }

  if (id === 'mx_tk_prio_pick') {
    const p = pending.get(i.user.id);
    if (!p || p.guildId !== i.guild.id) {
      await i.update({ content: 'Session expirée — rouvre depuis le panel.', embeds: [], components: [] });
      return true;
    }
    p.priority = i.values[0];
    pending.set(i.user.id, p);
    const modal = new ModalBuilder().setCustomId('mx_modal_tkopen').setTitle('Nouveau ticket');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('subject').setLabel('Sujet').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100)
          .setPlaceholder('Ex: Problème de connexion')
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('details').setLabel('Détails').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(1000)
          .setPlaceholder('Explique clairement ta demande…')
      ),
    );
    await i.showModal(modal);
    return true;
  }

  // ── In-ticket actions ──
  const map = bag('tickets.json', gid) || {};
  const t = map[i.channel?.id];

  if (id === 'mx_tk_claim' || id === 'mx_tk_close' || id === 'mx_tk_prio' || id === 'mx_tk_add' || id === 'mx_tk_rename' || id === 'mx_tk_note') {
    if (!t) { await i.reply({ content: '❌ Ce salon n’est pas un ticket ManageX.', ...EPH }); return true; }
    if (!canSupport(i.member, c) && i.user.id !== t.openerId && id !== 'mx_tk_close') {
      // opener can only close via staff path - only support for claim etc
    }
    if (['mx_tk_claim', 'mx_tk_prio', 'mx_tk_add', 'mx_tk_rename', 'mx_tk_note'].includes(id) && !canSupport(i.member, c, t)) {
      await i.reply({ content: '❌ Réservé au support de cette catégorie / staff.', ...EPH });
      return true;
    }
  }

  if (id === 'mx_tk_claim') {
    t.claimedBy = i.user.id;
    map[i.channel.id] = t;
    setBag('tickets.json', gid, map);
    await i.reply({
      embeds: [emb('✋ Pris en charge', C.success).setDescription(`${i.user} s’occupe de ce ticket.`)],
    });
    await i.message.edit({ components: ticketControls(t) }).catch(() => null);
    return true;
  }

  if (id === 'mx_tk_prio') {
    await i.reply({
      content: 'Nouvelle priorité :',
      components: [new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId('mx_tk_prio_set').setPlaceholder('Priorité…')
          .addOptions(
            { label: 'Basse', value: 'low', emoji: '🟢' },
            { label: 'Normale', value: 'normal', emoji: '🔵' },
            { label: 'Haute', value: 'high', emoji: '🟠' },
            { label: 'Urgente', value: 'urgent', emoji: '🔴' },
          )
      )],
      ...EPH,
    });
    return true;
  }
  if (id === 'mx_tk_prio_set') {
    if (!canSupport(i.member, c) || !t) { await i.reply({ content: '❌', ...EPH }); return true; }
    t.priority = i.values[0];
    map[i.channel.id] = t;
    setBag('tickets.json', gid, map);
    const pri = PRIORITY[t.priority];
    await i.channel.setTopic(`ManageX #${t.number} · ${t.categoryLabel} · ${pri.label}`).catch(() => null);
    await i.update({ content: `${pri.emoji} Priorité → **${pri.label}**`, components: [] });
    return true;
  }

  if (id === 'mx_tk_add') {
    await i.reply({
      content: 'Membre à ajouter au ticket :',
      components: [new ActionRowBuilder().addComponents(
        new UserSelectMenuBuilder().setCustomId('mx_tk_add_user').setPlaceholder('Membre…').setMinValues(1).setMaxValues(1)
      )],
      ...EPH,
    });
    return true;
  }
  if (id === 'mx_tk_add_user') {
    if (!canSupport(i.member, c)) { await i.reply({ content: '❌', ...EPH }); return true; }
    const uid = i.values[0];
    await i.channel.permissionOverwrites.edit(uid, {
      ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true,
    }).catch(() => null);
    await i.update({ content: `➕ <@${uid}> ajouté au ticket.`, components: [] });
    return true;
  }

  if (id === 'mx_tk_rename') {
    const modal = new ModalBuilder().setCustomId('mx_modal_tkrename').setTitle('Renommer le ticket');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('name').setLabel('Nouveau nom (sans espaces)').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(90)
        .setValue(i.channel.name.slice(0, 90))
    ));
    await i.showModal(modal);
    return true;
  }

  if (id === 'mx_tk_note') {
    const modal = new ModalBuilder().setCustomId('mx_modal_tknote').setTitle('Note staff (interne)');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('note').setLabel('Note').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(500)
        .setValue(t?.staffNote || '')
    ));
    await i.showModal(modal);
    return true;
  }

  if (id === 'mx_tk_close') {
    if (!canSupport(i.member, c, t) && i.user.id !== t?.openerId) {
      await i.reply({ content: '❌ Staff ou auteur du ticket.', ...EPH });
      return true;
    }
    const modal = new ModalBuilder().setCustomId('mx_modal_tkclose').setTitle('Fermer le ticket');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('reason').setLabel('Raison (optionnel)').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(200)
    ));
    await i.showModal(modal);
    return true;
  }

  if (id === 'mx_tk_noop') {
    await i.reply({ content: 'Support indisponible.', ...EPH });
    return true;
  }

  
  if (id === 'mx_tk_still_yes' || id === 'mx_tk_still_no') {
    const map = bag('tickets.json', i.guild.id);
    const data = typeof map === 'object' && !Array.isArray(map) ? map : {};
    const tck = data[i.channel.id];
    const cfg = getGuild(i.guild.id);
    if (!tck || tck.closed) {
      await i.reply({ content: 'Ticket introuvable.', ...EPH });
      return true;
    }
    if (i.user.id !== tck.openerId && !canSupport(i.member, cfg, tck)) {
      await i.reply({ content: '❌ Seul l’auteur (ou le staff) peut répondre.', ...EPH });
      return true;
    }
    if (id === 'mx_tk_still_yes') {
      tck.inactivityWarnedAt = null;
      tck.inactivityKeep = true;
      tck.lastActivityAt = Date.now();
      data[i.channel.id] = tck;
      setBag('tickets.json', i.guild.id, data);
      await i.update({
        content: null,
        embeds: [emb('✅ Ticket conservé', C.success)
          .setDescription('Le ticket reste ouvert.\nNouveau rappel seulement après **24h** sans message.')],
        components: [],
      });
      return true;
    }
    // non → close
    await i.update({
      content: null,
      embeds: [emb('🔒 Fermeture demandée', C.danger).setDescription('Fermeture en cours…')],
      components: [],
    });
    await closeTicketBySystem(i.client, i.guild, i.channel.id, `Fermé par ${i.user.tag} (plus besoin du ticket)`);
    return true;
  }

  return false;

}

async function handleModal(i) {
  const id = i.customId || '';

  if (id === 'mx_modal_tkcat') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    const cid = i.fields.getTextInputValue('id').toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 30);
    const label = i.fields.getTextInputValue('label');
    const emoji = i.fields.getTextInputValue('emoji') || '💬';
    const cats = [...(getGuild(i.guild.id).ticketCategories || [])];
    if (!cid) { await i.reply({ content: 'ID invalide.', ...EPH }); return true; }
    if (cats.some((x) => x.id === cid)) { await i.reply({ content: 'Cet ID existe déjà.', ...EPH }); return true; }
    cats.push({ id: cid, label, emoji, closed: false, supportRoleIds: [] });
    setGuild(i.guild.id, { ticketCategories: cats });
    // Enchaîne sur le choix des rôles support
    if (!global.__mxTkCatRole) global.__mxTkCatRole = new Map();
    global.__mxTkCatRole.set(i.user.id, cid);
    await i.reply({
      content: `✅ Catégorie **${emoji} ${label}** créée.\n\n🎭 **Choisis maintenant le(s) rôle(s) support** pour cette catégorie :`,
      components: [new ActionRowBuilder().addComponents(
        new RoleSelectMenuBuilder()
          .setCustomId('mx_tkcfg_catrole_roles')
          .setPlaceholder(`Rôles support · ${label}…`)
          .setMinValues(0)
          .setMaxValues(10)
      )],
      ...EPH,
    });
    return true;
  }

  if (id === 'mx_modal_tkmax') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    const n = Math.min(10, Math.max(1, parseInt(i.fields.getTextInputValue('n'), 10) || 2));
    setGuild(i.guild.id, { maxTicketsPerUser: n, ticketUnlimited: n === 0 || n < 0 });
    await i.reply({ content: `✅ Max tickets / membre : **${n}**`, ...EPH });
    return true;
  }

  if (id === 'mx_modal_tkopen') {
    const p = pending.get(i.user.id);
    pending.delete(i.user.id);
    if (!p || p.guildId !== i.guild.id) {
      await i.reply({ content: 'Session expirée — recommence depuis le panel.', ...EPH });
      return true;
    }
    const cat = (getGuild(i.guild.id).ticketCategories || []).find((x) => x.id === p.categoryId);
    if (!cat || cat.closed) {
      await i.reply({ content: 'Catégorie fermée.', ...EPH });
      return true;
    }
    await i.deferReply({ ...EPH });
    try {
      const channel = await createTicket(
        i.guild,
        i.user,
        cat,
        {
          subject: i.fields.getTextInputValue('subject'),
          details: i.fields.getTextInputValue('details'),
        },
        p.priority || 'normal'
      );
      await i.editReply({
        embeds: [
          emb('✅ Ticket créé', C.success)
            .setDescription(`Ton ticket : ${channel}\nLe staff a été notifié.`),
        ],
      });
    } catch (e) {
      await i.editReply({ content: `❌ Impossible de créer le ticket : ${e.message}` });
    }
    return true;
  }

  if (id === 'mx_modal_tkrename') {
    const name = i.fields.getTextInputValue('name').toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-_]/g, '').slice(0, 100);
    if (!name) { await i.reply({ content: 'Nom invalide.', ...EPH }); return true; }
    await i.channel.setName(name).catch(() => null);
    await i.reply({ content: `✏️ Salon renommé : **${name}**`, ...EPH });
    return true;
  }

  if (id === 'mx_modal_tknote') {
    const map = bag('tickets.json', i.guild.id) || {};
    const t = map[i.channel.id];
    if (!t) { await i.reply({ content: '❌', ...EPH }); return true; }
    t.staffNote = i.fields.getTextInputValue('note');
    map[i.channel.id] = t;
    setBag('tickets.json', i.guild.id, map);
    await i.reply({
      embeds: [emb('📝 Note staff', C.warn).setDescription(t.staffNote).setFooter({ text: `Par ${i.user.tag}` })],
      ...EPH,
    });
    return true;
  }


  if (id === 'mx_modal_tkinact') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    const en = i.fields.getTextInputValue('enabled').toLowerCase().startsWith('o');
    const warn = Math.max(1, parseInt(i.fields.getTextInputValue('warn'), 10) || 24);
    const closeH = Math.max(1, parseInt(i.fields.getTextInputValue('close'), 10) || 24);
    setGuild(i.guild.id, {
      ticketInactivityEnabled: en,
      ticketWarnAfterHours: warn,
      ticketCloseAfterWarnHours: closeH,
    });
    await i.reply({
      content: `✅ Inactivité : **${en ? 'ON' : 'OFF'}** · warning **${warn}h** · close **${closeH}h** après`,
      ...EPH,
    });
    return true;
  }

  if (id === 'mx_modal_tkclose') {
    const map = bag('tickets.json', i.guild.id) || {};
    const t = map[i.channel.id];
    if (!t) { await i.reply({ content: '❌', ...EPH }); return true; }
    const reason = i.fields.getTextInputValue('reason') || 'Aucune raison';
    t.closed = true;
    t.closedAt = Date.now();
    t.closeReason = reason;
    t.closedBy = i.user.id;
    map[i.channel.id] = t;
    setBag('tickets.json', i.guild.id, map);

    const g = getGlobal();
    setGlobal({ stats: { ...g.stats, ticketsClosed: (g.stats?.ticketsClosed || 0) + 1 } });

    const c = getGuild(i.guild.id);
    const duration = t.createdAt ? Math.floor((Date.now() - t.createdAt) / 60000) : 0;

    let transcriptFile = null;
    try {
      const text = await buildTranscript(i.channel, t, i.user);
      transcriptFile = new AttachmentBuilder(Buffer.from(text, 'utf8'), {
        name: `transcript-${t.number || i.channel.id}-${Date.now()}.txt`,
      });
    } catch (e) {
      console.error('[transcript]', e.message);
    }

    if (c.ticketLogChannelId) {
      const log = await i.guild.channels.fetch(c.ticketLogChannelId).catch(() => null);
      if (log?.send) {
        await log.send({
          embeds: [
            emb(`🔒 Ticket #${t.number} fermé`, C.danger)
              .addFields(
                { name: 'Auteur', value: `<@${t.openerId}>`, inline: true },
                { name: 'Fermé par', value: `${i.user}`, inline: true },
                { name: 'Durée', value: `**${duration}** min`, inline: true },
                { name: 'Priorité', value: (PRIORITY[t.priority] || PRIORITY.normal).label, inline: true },
                { name: 'Catégorie', value: t.categoryLabel || '—', inline: true },
                { name: 'Claim', value: t.claimedBy ? `<@${t.claimedBy}>` : '—', inline: true },
                { name: 'Sujet', value: t.subject || '—' },
                { name: 'Raison fermeture', value: reason },
                ...(t.staffNote ? [{ name: 'Note staff', value: t.staffNote.slice(0, 500) }] : []),
                { name: '📜 Transcript', value: transcriptFile ? 'Fichier joint ↓' : '_Échec_' },
              ),
          ],
          files: transcriptFile ? [transcriptFile] : [],
        }).catch(() => null);
      }
    }

    await i.reply({
      embeds: [
        emb('🔒 Ticket fermé', C.danger)
          .setDescription(
            [
              `Par ${i.user}`,
              `**Raison :** ${reason}`,
              transcriptFile ? '📜 Transcript → logs + **MP** à l’auteur.' : '',
              '',
              'Suppression du salon dans **5 secondes**…',
            ].filter(Boolean).join('\n')
          ),
      ],
    });

    
    // Transcript en MP à l'auteur du ticket
    if (transcriptFile && t.openerId) {
      try {
        const opener = await i.client.users.fetch(t.openerId);
        await opener.send({
          embeds: [
            emb(`📜 Transcript ticket #${t.number}`, C.ticket)
              .setDescription(
                `Serveur : **${i.guild.name}**
Catégorie : **${t.categoryLabel || '—'}**
Fermé par : ${i.user.tag}
Raison : ${reason}`
              ),
          ],
          files: [transcriptFile],
        });
      } catch (e) {
        console.warn('[transcript DM]', e.message);
      }
    }

    setTimeout(() => {
      delete map[i.channel.id];
      setBag('tickets.json', i.guild.id, map);
      i.channel.delete('ManageX ticket closed').catch(() => null);
    }, 5000);
    return true;
  }

  return false;
}


/** Met à jour l'activité d'un ticket (annule un warning en cours si nouveau message) */
function touchTicketActivity(guildId, channelId) {
  const map = bag('tickets.json', guildId);
  const data = typeof map === 'object' && !Array.isArray(map) ? map : {};
  const t = data[channelId];
  if (!t || t.closed) return;
  t.lastActivityAt = Date.now();
  // Si le membre a répondu après un warning, on considère qu'il garde le ticket
  if (t.inactivityWarnedAt) {
    t.inactivityWarnedAt = null;
    t.inactivityKeep = true;
  }
  data[channelId] = t;
  setBag('tickets.json', guildId, data);
}

async function onTicketMessage(message) {
  if (!message.guild || message.author?.bot) return;
  const map = bag('tickets.json', message.guild.id);
  const data = typeof map === 'object' && !Array.isArray(map) ? map : {};
  if (!data[message.channel.id] || data[message.channel.id].closed) return;
  touchTicketActivity(message.guild.id, message.channel.id);
}

async function closeTicketBySystem(client, guild, channelId, reason) {
  const map = bag('tickets.json', guild.id);
  const data = typeof map === 'object' && !Array.isArray(map) ? map : {};
  const t = data[channelId];
  if (!t || t.closed) return;
  t.closed = true;
  t.closedAt = Date.now();
  t.closeReason = reason;
  t.closedBy = client.user.id;
  data[channelId] = t;
  setBag('tickets.json', guild.id, data);

  const g = getGlobal();
  setGlobal({ stats: { ...g.stats, ticketsClosed: (g.stats?.ticketsClosed || 0) + 1 } });

  const channel = await guild.channels.fetch(channelId).catch(() => null);
  if (!channel) {
    delete data[channelId];
    setBag('tickets.json', guild.id, data);
    return;
  }

  const c = getGuild(guild.id);
  let transcriptFile = null;
  try {
    const text = await buildTranscript(channel, t, client.user);
    transcriptFile = new AttachmentBuilder(Buffer.from(text, 'utf8'), {
      name: `transcript-${t.number || channelId}-${Date.now()}.txt`,
    });
  } catch (e) {
    console.error('[transcript auto]', e.message);
  }

  if (c.ticketLogChannelId) {
    const log = await guild.channels.fetch(c.ticketLogChannelId).catch(() => null);
    if (log?.send) {
      await log.send({
        embeds: [
          emb(`🔒 Ticket #${t.number} fermé (auto)`, C.danger)
            .addFields(
              { name: 'Auteur', value: `<@${t.openerId}>`, inline: true },
              { name: 'Raison', value: reason },
              { name: '📜 Transcript', value: transcriptFile ? 'Fichier joint ↓' : '_Échec_' },
            ),
        ],
        files: transcriptFile ? [transcriptFile] : [],
      }).catch(() => null);
    }
  }

  await channel.send({
    embeds: [emb('🔒 Ticket fermé automatiquement', C.danger).setDescription(reason)],
  }).catch(() => null);

  setTimeout(() => {
    const m2 = bag('tickets.json', guild.id);
    const d2 = typeof m2 === 'object' && !Array.isArray(m2) ? m2 : {};
    delete d2[channelId];
    setBag('tickets.json', guild.id, d2);
    channel.delete('ManageX auto-close').catch(() => null);
  }, 5000);
}

async function runInactivityCheck(client) {
  for (const [, guild] of client.guilds.cache) {
    const c = getGuild(guild.id);
    if (c.ticketInactivityEnabled === false) continue;
    const warnAfter = (c.ticketWarnAfterHours ?? 24) * 3600_000;
    const closeAfter = (c.ticketCloseAfterWarnHours ?? 24) * 3600_000;
    const map = bag('tickets.json', guild.id);
    const data = typeof map === 'object' && !Array.isArray(map) ? map : {};
    const now = Date.now();

    for (const [channelId, t] of Object.entries(data)) {
      if (!t || t.closed) continue;
      const last = t.lastActivityAt || t.createdAt || now;
      const inactiveFor = now - last;

      // Déjà warning : fermer si pas de réponse depuis closeAfter
      if (t.inactivityWarnedAt) {
        if (now - t.inactivityWarnedAt >= closeAfter) {
          await closeTicketBySystem(
            client,
            guild,
            channelId,
            `Inactif après avertissement (${c.ticketCloseAfterWarnHours ?? 24}h sans réponse)`
          ).catch((e) => console.error('[autoclose]', e.message));
        }
        continue;
      }

      // Pas encore warning : envoyer si inactif assez longtemps
      // Si l'user a dit "oui" (inactivityKeep), il faut quand même 24h d'inactivité depuis le dernier message
      if (inactiveFor < warnAfter) continue;

      const channel = await guild.channels.fetch(channelId).catch(() => null);
      if (!channel?.send) continue;

      t.inactivityWarnedAt = now;
      data[channelId] = t;
      setBag('tickets.json', guild.id, data);

      const hours = c.ticketWarnAfterHours ?? 24;
      await channel.send({
        content: `<@${t.openerId}>`,
        embeds: [
          emb('⏰ Toujours besoin de ce ticket ?', C.warn)
            .setDescription(
              [
                `Aucune activité depuis **${hours}h**.`,
                '',
                '**Oui** → le ticket reste ouvert (se refermera seulement après **24h** d’inactivité encore).',
                '**Non** → fermeture immédiate + transcript.',
                '',
                `_Sans réponse sous **${c.ticketCloseAfterWarnHours ?? 24}h**, fermeture auto._`,
              ].join('\n')
            ),
        ],
        components: [
          new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('mx_tk_still_yes').setLabel('Oui, je garde').setStyle(ButtonStyle.Success).setEmoji('✅'),
            new ButtonBuilder().setCustomId('mx_tk_still_no').setLabel('Non, fermer').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
          ),
        ],
      }).catch(() => null);
    }
  }
}

function startInactivityTicker(client) {
  const tick = () => runInactivityCheck(client).catch((e) => console.error('[inactivity]', e.message));
  setTimeout(tick, 60_000);
  setInterval(tick, 15 * 60_000);
  console.log('⏱️ Tickets inactivité (warning → close) OK');
}


module.exports = { command, handle, handleModal, onTicketMessage, startInactivityTicker };
