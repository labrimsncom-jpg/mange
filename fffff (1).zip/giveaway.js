const {
  SlashCommandBuilder, PermissionFlagsBits, MessageFlags,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, RoleSelectMenuBuilder,
  ModalBuilder, TextInputBuilder, TextInputStyle,
} = require('discord.js');
const { getGuild, setGuild, read, write } = require('./storage.js');
const { isAdmin } = require('./perms.js');
const { emb, C } = require('./design.js');
const { openBtn } = require('./pickers.js');
const { E, CFG } = require('./emojis.js');

const EPH = { flags: MessageFlags.Ephemeral };
const timers = new Map();

function allGW() { return read('giveaways.json', {}); }
function getGW(id) { return allGW()[id]; }
function setGW(id, data) {
  const all = allGW();
  if (data === null) delete all[id]; else all[id] = data;
  write('giveaways.json', all);
}
function parseDur(s) {
  let ms = 0;
  const re = /(\d+)\s*(d|h|m|s)/gi;
  let m;
  while ((m = re.exec(s || ''))) {
    const n = +m[1];
    if (m[2] === 'd') ms += n * 864e5;
    if (m[2] === 'h') ms += n * 36e5;
    if (m[2] === 'm') ms += n * 6e4;
    if (m[2] === 's') ms += n * 1e3;
  }
  return ms || null;
}
function buildEmbed(g) {
  const { card, C: Col } = require('./design.js');
  if (g.ended) {
    return card({
      title: '🏁 Giveaway terminé',
      color: Col.dark,
      description: [
        `### 🎁 ${g.prize}`,
        '',
        '**Gagnant(s)**',
        g.winnersText || '_Aucun participant_',
      ].join('\n'),
      fields: [
        { name: '🏆 Places', value: `**${g.winnerCount}**`, inline: true },
        { name: '👥 Participants', value: `**${(g.participants || []).length}**`, inline: true },
        { name: '🎫 Organisateur', value: g.hostId ? `<@${g.hostId}>` : '—', inline: true },
      ],
      footer: 'ManageX Giveaway · terminé · Reroll possible',
    });
  }
  return card({
    title: '🎉 Giveaway en cours',
    color: Col.giveaway,
    description: [
      `### 🎁 ${g.prize}`,
      '',
      'Clique sur **Participer** pour tenter ta chance !',
      '',
      `⏰ **Fin** <t:${Math.floor(g.endsAt / 1000)}:R>`,
      `📅 <t:${Math.floor(g.endsAt / 1000)}:f>`,
    ].join('\n'),
    fields: [
      { name: '🏆 Gagnants', value: `**${g.winnerCount}**`, inline: true },
      { name: '👥 Inscrits', value: `**${(g.participants || []).length}**`, inline: true },
      { name: '🎫 Organisateur', value: g.hostId ? `<@${g.hostId}>` : '—', inline: true },
      ...(g.requiredRoleId ? [{ name: '🔒 Rôle requis', value: `<@&${g.requiredRoleId}>`, inline: true }] : []),
      ...(g.rewardRoleId ? [{ name: '🎁 Rôle récompense', value: `<@&${g.rewardRoleId}>`, inline: true }] : []),
    ],
    footer: 'ManageX Giveaway · bonne chance !',
  });
}
function btns(mid, g) {
  if (g.ended) return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`mx_gw_reroll_${mid}`).setLabel('Reroll').setStyle(ButtonStyle.Primary)
  )];
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`mx_gw_join_${mid}`).setLabel('Participer').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`mx_gw_leave_${mid}`).setLabel('Quitter').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`mx_gw_end_${mid}`).setLabel('Terminer').setStyle(ButtonStyle.Danger),
  )];
}
function pick(pool, n) {
  const a = [...pool], o = [];
  while (o.length < n && a.length) o.push(a.splice(Math.floor(Math.random() * a.length), 1)[0]);
  return o;
}
async function endGW(client, mid) {
  const g = getGW(mid);
  if (!g || g.ended) return;
  clearTimeout(timers.get(mid));
  const winners = pick(g.participants || [], g.winnerCount || 1);
  g.ended = true;
  g.winnerIds = winners;
  g.winnersText = winners.map((id, i) => `**${i + 1}.** <@${id}>`).join('\n') || '*Aucun*';
  setGW(mid, g);
  try {
    const ch = await client.channels.fetch(g.channelId).catch(() => null);
    const msg = ch && await ch.messages.fetch(mid).catch(() => null);
    if (msg) await msg.edit({ embeds: [buildEmbed(g)], components: btns(mid, g) });
    if (winners.length && ch) {
      await ch.send(`🎉 ${winners.map((id) => `<@${id}>`).join(', ')} gagne **${g.prize}**`).catch(() => null);
      if (g.rewardRoleId) {
        for (const w of winners) {
          const m = await ch.guild.members.fetch(w).catch(() => null);
          if (m) await m.roles.add(g.rewardRoleId).catch(() => null);
        }
      }
    }
  } catch {}
}
function schedule(client, mid, endsAt) {
  clearTimeout(timers.get(mid));
  const d = Math.max(0, endsAt - Date.now());
  if (d > 2147483647) return;
  timers.set(mid, setTimeout(() => endGW(client, mid), d));
}
function resumeAll(client) {
  for (const [id, g] of Object.entries(allGW())) {
    if (!g?.ended && g.endsAt > Date.now()) schedule(client, id, g.endsAt);
    else if (g && !g.ended) endGW(client, id);
  }
}

const command = {
  data: new SlashCommandBuilder()
    .setName('giveawayconfig')
    .setDescription('ManageX — giveaways')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(i) {
    if (!isAdmin(i.member)) return i.reply({ content: '❌', ...EPH });
    const c = getGuild(i.guild.id);
    const { card, C: Col, role } = require('./design.js');
    await i.reply({
      embeds: [card({
        title: '🎉 Configuration Giveaway',
        color: Col.giveaway,
        description: [
          '### Crée des concours stylés',
          '',
          '1. Configure les rôles (optionnel)',
          '2. Clique **Créer giveaway**',
          '3. Les membres participent avec le bouton',
        ].join('\n'),
        fields: [
          { name: '🔒 Rôle requis pour participer', value: role(c.gwRequiredRoleId), inline: true },
          { name: '📣 Rôle ping à la création', value: role(c.gwPingRoleId), inline: true },
          { name: '🎁 Rôle donné au gagnant', value: role(c.gwRewardRoleId), inline: true },
        ],
        footer: 'ManageX · /giveawayconfig',
      })],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('mx_gw_create').setLabel('Créer giveaway').setStyle(ButtonStyle.Success),
        ),
        new ActionRowBuilder().addComponents(
          openBtn('role', 'gw_req', '🔒 Rôle requis')
        ),
        new ActionRowBuilder().addComponents(
          openBtn('role', 'gw_ping', '📣 Rôle ping')
        ),
        new ActionRowBuilder().addComponents(
          openBtn('role', 'gw_reward', '🎁 Rôle récompense')
        ),
      ],
      ...EPH,
    });
  },
};

async function handle(i, client) {
  const id = i.customId || '';
  if (!id.startsWith('mx_gw_')) return false;

  if (id === 'mx_gw_create') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    const modal = new ModalBuilder().setCustomId('mx_modal_gw').setTitle('Giveaway');
    modal.addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('prize').setLabel('Lot').setStyle(TextInputStyle.Short).setRequired(true)),
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('duree').setLabel('Durée (30m, 2h, 1d)').setStyle(TextInputStyle.Short).setRequired(true).setValue('1h')),
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('winners').setLabel('Gagnants').setStyle(TextInputStyle.Short).setValue('1')),
    );
    await i.showModal(modal);
    return true;
  }
  if (id === 'mx_gw_req') { setGuild(i.guild.id, { gwRequiredRoleId: i.values[0] || null }); await i.reply({ content: '✅', ...EPH }); return true; }
  if (id === 'mx_gw_ping') { setGuild(i.guild.id, { gwPingRoleId: i.values[0] || null }); await i.reply({ content: '✅', ...EPH }); return true; }
  if (id === 'mx_gw_reward') { setGuild(i.guild.id, { gwRewardRoleId: i.values[0] || null }); await i.reply({ content: '✅', ...EPH }); return true; }

  const join = id.match(/^mx_gw_join_(.+)$/);
  const leave = id.match(/^mx_gw_leave_(.+)$/);
  const end = id.match(/^mx_gw_end_(.+)$/);
  const reroll = id.match(/^mx_gw_reroll_(.+)$/);

  if (join) {
    const g = getGW(join[1]);
    if (!g || g.ended) { await i.reply({ content: '❌', ...EPH }); return true; }
    if (g.requiredRoleId && !i.member.roles.cache.has(g.requiredRoleId)) {
      await i.reply({ content: '❌ Rôle requis manquant.', ...EPH }); return true;
    }
    const p = g.participants || [];
    if (p.includes(i.user.id)) { await i.reply({ content: 'Déjà inscrit.', ...EPH }); return true; }
    p.push(i.user.id); g.participants = p; setGW(join[1], g);
    await i.update({ embeds: [buildEmbed(g)], components: btns(join[1], g) });
    return true;
  }
  if (leave) {
    const g = getGW(leave[1]);
    if (!g || g.ended) { await i.reply({ content: '❌', ...EPH }); return true; }
    g.participants = (g.participants || []).filter((u) => u !== i.user.id);
    setGW(leave[1], g);
    await i.update({ embeds: [buildEmbed(g)], components: btns(leave[1], g) });
    return true;
  }
  if (end) {
    const g = getGW(end[1]);
    if (!g) { await i.reply({ content: '❌', ...EPH }); return true; }
    if (i.user.id !== g.hostId && !isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    await i.deferUpdate();
    await endGW(client, end[1]);
    return true;
  }
  if (reroll) {
    const g = getGW(reroll[1]);
    if (!g?.ended) { await i.reply({ content: '❌', ...EPH }); return true; }
    if (i.user.id !== g.hostId && !isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    const winners = pick(g.participants || [], g.winnerCount || 1);
    g.winnerIds = winners;
    g.winnersText = winners.map((id, n) => `**${n + 1}.** <@${id}>`).join('\n') || '*Aucun*';
    setGW(reroll[1], g);
    await i.update({ embeds: [buildEmbed(g)], components: btns(reroll[1], g) });
    return true;
  }
  return false;
}

async function handleModal(i, client) {
  if (i.customId !== 'mx_modal_gw') return false;
  if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
  const ms = parseDur(i.fields.getTextInputValue('duree'));
  if (!ms) { await i.reply({ content: 'Durée invalide.', ...EPH }); return true; }
  const c = getGuild(i.guild.id);
  await i.deferReply({ ...EPH });
  const draft = {
    channelId: i.channel.id, guildId: i.guild.id, hostId: i.user.id,
    prize: i.fields.getTextInputValue('prize'),
    winnerCount: Math.max(1, Math.min(20, parseInt(i.fields.getTextInputValue('winners'), 10) || 1)),
    participants: [], endsAt: Date.now() + ms, ended: false,
    requiredRoleId: c.gwRequiredRoleId, rewardRoleId: c.gwRewardRoleId,
  };
  const ping = c.gwPingRoleId ? `<@&${c.gwPingRoleId}>` : undefined;
  const msg = await i.channel.send({ content: ping, embeds: [buildEmbed(draft)], components: btns('tmp', draft) });
  draft.messageId = msg.id;
  setGW(msg.id, draft);
  await msg.edit({ components: btns(msg.id, draft) });
  schedule(client, msg.id, draft.endsAt);
  await i.editReply({ content: `✅ ${msg.url}` });
  return true;
}

module.exports = { command, handle, handleModal, resumeAll };
