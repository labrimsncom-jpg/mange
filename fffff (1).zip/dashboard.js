/**
 * ManageX Dashboard — OAuth Discord
 * Env: DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, DISCORD_REDIRECT_URI
 *      DASHBOARD_PORT, DASHBOARD_SECRET, DISCORD_TOKEN
 */
const express = require('express');
const path = require('path');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const {
  getGlobal, setGlobal, getGuild, setGuild, read, GUILD_DEFAULTS,
} = require('./storage.js');

const CLIENT_ID = process.env.DISCORD_CLIENT_ID || process.env.CLIENT_ID || '';
const CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET || process.env.CLIENT_SECRET || '';
const REDIRECT_URI = process.env.DISCORD_REDIRECT_URI || process.env.REDIRECT_URI || '';
// Hokas / Pterodactyl : utiliser le PORT alloué par le panel (priorité)
const PORT = parseInt(
  process.env.SERVER_PORT || process.env.PORT || process.env.DASHBOARD_PORT || '3000',
  10
);
const DASHBOARD_ENABLED = !['0', 'false', 'off', 'no'].includes(
  String(process.env.DASHBOARD_ENABLED || 'true').toLowerCase()
);
const MANAGE_GUILD = 0x20n; // permission bit

function hasManageGuild(permStr) {
  try {
    return (BigInt(permStr || '0') & MANAGE_GUILD) === MANAGE_GUILD;
  } catch {
    return false;
  }
}

async function discordApi(url, accessToken) {
  const r = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!r.ok) {
    const t = await r.text();
    throw new Error(`Discord API ${r.status}: ${t.slice(0, 200)}`);
  }
  return r.json();
}

function startDashboard(client) {
  if (!DASHBOARD_ENABLED) {
    console.log('🖥️  Dashboard désactivé (DASHBOARD_ENABLED=false)');
    return null;
  }

  const app = express();
  // Derrière reverse proxy Hokas / Cloudflare
  app.set('trust proxy', 1);

  app.use(cookieParser());
  app.use(express.json({ limit: '1mb' }));
  app.use(session({
    secret: process.env.DASHBOARD_SECRET || process.env.SESSION_SECRET || 'managex-oauth-secret-change-me',
    resave: false,
    saveUninitialized: false,
    proxy: true,
    cookie: {
      maxAge: 7 * 24 * 60 * 60 * 1000,
      sameSite: 'lax',
      // secure auto si HTTPS (Hokas domaine custom / proxy)
      secure: process.env.DASHBOARD_SECURE === 'true' || process.env.NODE_ENV === 'production',
    },
  }));

  // Healthcheck panel (ne gêne pas le bot)
  app.get('/health', (req, res) => {
    res.json({
      ok: true,
      bot: client?.user?.tag || null,
      guilds: client?.guilds?.cache?.size ?? 0,
      uptime: Math.floor(process.uptime()),
    });
  });

  function requireAuth(req, res, next) {
    if (req.session?.user && req.session?.accessToken) return next();
    if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'Connecte-toi avec Discord' });
    return res.redirect('/login');
  }

  /** Vérifie que l’user peut config ce serveur */
  function canConfigGuild(req, guildId) {
    const allowed = req.session?.guildIds || [];
    if (allowed.includes(guildId)) return true;
    // Owners bot globaux
    const g = getGlobal();
    const uid = req.session?.user?.id;
    if (uid && (g.ownerIds || []).includes(uid)) return true;
    if (uid && (g.coOwnerIds || []).includes(uid)) return true;
    return false;
  }

  // ── OAuth ──
  app.get('/login', (req, res) => {
    if (req.session?.user) return res.redirect('/');
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
  });

  app.get('/auth/discord', (req, res) => {
    if (!CLIENT_ID || !REDIRECT_URI) {
      return res.status(500).send(
        'OAuth non configuré. Variables : DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, DISCORD_REDIRECT_URI'
      );
    }
    const params = new URLSearchParams({
      client_id: CLIENT_ID,
      redirect_uri: REDIRECT_URI,
      response_type: 'code',
      scope: 'identify guilds',
      prompt: 'none',
    });
    res.redirect(`https://discord.com/api/oauth2/authorize?${params}`);
  });

  app.get('/auth/callback', async (req, res) => {
    const code = req.query.code;
    if (!code) return res.redirect('/login?error=no_code');
    try {
      const body = new URLSearchParams({
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
        grant_type: 'authorization_code',
        code: String(code),
        redirect_uri: REDIRECT_URI,
      });
      const tokenRes = await fetch('https://discord.com/api/oauth2/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
      });
      if (!tokenRes.ok) {
        const err = await tokenRes.text();
        console.error('[oauth token]', err);
        return res.redirect('/login?error=token');
      }
      const token = await tokenRes.json();
      const user = await discordApi('https://discord.com/api/users/@me', token.access_token);
      const userGuilds = await discordApi('https://discord.com/api/users/@me/guilds', token.access_token);

      // Intersection : bot présent + user Manage Guild (ou owner du serveur)
      const botGuildIds = new Set(client.guilds.cache.keys());
      const manageable = userGuilds.filter((ug) => {
        if (!botGuildIds.has(ug.id)) return false;
        if (ug.owner) return true;
        return hasManageGuild(ug.permissions);
      });

      req.session.user = {
        id: user.id,
        username: user.username,
        globalName: user.global_name || user.username,
        avatar: user.avatar
          ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=128`
          : null,
        discriminator: user.discriminator,
      };
      req.session.accessToken = token.access_token;
      req.session.guildIds = manageable.map((g) => g.id);
      req.session.guildMeta = Object.fromEntries(
        manageable.map((g) => [g.id, { name: g.name, icon: g.icon, owner: !!g.owner }])
      );

      console.log(`[dashboard] ${user.username} connecté · ${manageable.length} serveur(s)`);
      res.redirect('/');
    } catch (e) {
      console.error('[oauth]', e);
      res.redirect('/login?error=oauth');
    }
  });

  app.post('/api/logout', (req, res) => {
    req.session.destroy(() => {});
    res.json({ ok: true });
  });

  // ── API ──
  app.get('/api/me', requireAuth, (req, res) => {
    res.json({
      user: req.session.user,
      bot: client.user
        ? { tag: client.user.tag, id: client.user.id, avatar: client.user.displayAvatarURL() }
        : null,
      ping: client.ws.ping,
      guildCount: req.session.guildIds?.length || 0,
    });
  });

  app.get('/api/guilds', requireAuth, (req, res) => {
    const ids = req.session.guildIds || [];
    const meta = req.session.guildMeta || {};
    const list = ids.map((id) => {
      const g = client.guilds.cache.get(id);
      const m = meta[id] || {};
      return {
        id,
        name: g?.name || m.name || id,
        icon: g?.iconURL({ size: 64 })
          || (m.icon ? `https://cdn.discordapp.com/icons/${id}/${m.icon}.png?size=64` : null),
        members: g?.memberCount || 0,
        owner: !!m.owner,
        botPresent: !!g,
      };
    }).sort((a, b) => a.name.localeCompare(b.name));
    res.json(list);
  });

  app.get('/api/guilds/:id', requireAuth, (req, res) => {
    if (!canConfigGuild(req, req.params.id)) {
      return res.status(403).json({ error: 'Pas la permission sur ce serveur' });
    }
    const g = client.guilds.cache.get(req.params.id);
    if (!g) return res.status(404).json({ error: 'Le bot n’est plus sur ce serveur' });

    const cfg = getGuild(req.params.id);
    const channels = [...g.channels.cache.values()]
      .filter((c) => c.isTextBased?.() || c.type === 4)
      .map((c) => ({ id: c.id, name: c.name, type: c.type, parent: c.parentId }))
      .sort((a, b) => a.name.localeCompare(b.name));
    const roles = [...g.roles.cache.values()]
      .filter((r) => r.id !== g.id)
      .map((r) => ({ id: r.id, name: r.name, color: r.hexColor, position: r.position }))
      .sort((a, b) => b.position - a.position);

    res.json({
      guild: {
        id: g.id,
        name: g.name,
        icon: g.iconURL({ size: 128 }),
        members: g.memberCount,
      },
      config: cfg,
      channels,
      roles,
    });
  });

  app.patch('/api/guilds/:id', requireAuth, (req, res) => {
    if (!canConfigGuild(req, req.params.id)) {
      return res.status(403).json({ error: 'Pas la permission sur ce serveur' });
    }
    if (!client.guilds.cache.has(req.params.id)) {
      return res.status(404).json({ error: 'Bot absent de ce serveur' });
    }
    const clean = {};
    for (const [k, v] of Object.entries(req.body || {})) {
      if (v !== undefined) clean[k] = v;
    }
    setGuild(req.params.id, clean);
    res.json({ ok: true, config: getGuild(req.params.id) });
  });

  app.get('/api/guilds/:id/extra', requireAuth, (req, res) => {
    if (!canConfigGuild(req, req.params.id)) return res.status(403).json({ error: 'Forbidden' });
    const gid = req.params.id;
    res.json({
      tickets: read('tickets.json', {})[gid] || {},
      services: read('services.json', {})[gid] || {},
      absences: read('absences.json', {})[gid] || [],
      banreg: read('banreg.json', {})[gid] || [],
      xp: read('xp.json', {})[gid] || {},
    });
  });

  // Global — owners only
  app.get('/api/global', requireAuth, (req, res) => {
    const uid = req.session.user.id;
    const g = getGlobal();
    const isOwner = (g.ownerIds || []).includes(uid) || (g.coOwnerIds || []).includes(uid);
    if (!isOwner) return res.status(403).json({ error: 'Réservé aux owners du bot' });
    res.json(g);
  });

  app.patch('/api/global', requireAuth, (req, res) => {
    const uid = req.session.user.id;
    const g = getGlobal();
    if (!(g.ownerIds || []).includes(uid) && !(g.coOwnerIds || []).includes(uid)) {
      return res.status(403).json({ error: 'Réservé aux owners' });
    }
    const patch = req.body || {};
    if (patch.stats) patch.stats = { ...g.stats, ...patch.stats };
    setGlobal(patch);
    res.json({ ok: true, data: getGlobal() });
  });

  app.get('/api/commands', requireAuth, (req, res) => {
    const cmds = [...(client.commands?.values() || [])].map((c) => ({
      name: c.data.name,
      description: c.data.description,
    }));
    res.json(cmds);
  });

  app.get('/api/oauth-status', (req, res) => {
    res.json({
      configured: !!(CLIENT_ID && CLIENT_SECRET && REDIRECT_URI),
      clientId: CLIENT_ID ? `${CLIENT_ID.slice(0, 6)}…` : null,
      redirect: REDIRECT_URI || null,
    });
  });

  app.use(express.static(path.join(__dirname, 'public')));

  app.get('/', requireAuth, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  });
  app.get('/guild/:id', requireAuth, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'guild.html'));
  });
  app.get('/global', requireAuth, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'global.html'));
  });

  // Écoute non bloquante — erreur port ≠ crash bot
  let server;
  try {
    server = app.listen(PORT, '0.0.0.0', () => {
      console.log(`🖥️  Dashboard ManageX → port ${PORT} (0.0.0.0)`);
      console.log(`   Health : http://0.0.0.0:${PORT}/health`);
      if (!CLIENT_ID || !CLIENT_SECRET || !REDIRECT_URI) {
        console.warn('⚠️  OAuth incomplet — définis sur Hokas :');
        console.warn('   DISCORD_CLIENT_ID / DISCORD_CLIENT_SECRET / DISCORD_REDIRECT_URI');
        console.warn('   Redirect exemple : https://TON-SOUS-DOMAINE.hokas…/auth/callback');
      } else {
        console.log(`   OAuth redirect : ${REDIRECT_URI}`);
      }
    });
    server.on('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        console.error(`⚠️  Dashboard : port ${PORT} déjà pris — bot continue sans web UI`);
      } else {
        console.error('⚠️  Dashboard listen :', err.message, '— bot continue');
      }
    });
  } catch (e) {
    console.error('⚠️  Dashboard non démarré :', e.message, '— le bot tourne quand même');
    return null;
  }

  return server;
}

module.exports = { startDashboard };

