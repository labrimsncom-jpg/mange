const {
  SlashCommandBuilder, PermissionFlagsBits, MessageFlags,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ModalBuilder, TextInputBuilder, TextInputStyle,
} = require('discord.js');
const { read, write } = require('./storage.js');
const { isAdmin } = require('./perms.js');
const { emb, C } = require('./design.js');
const { E, CFG } = require('./emojis.js');

const EPH = { flags: MessageFlags.Ephemeral };
const EMOJIS = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

function all() { return read('polls.json', {}); }
function get(id) { return all()[id]; }
function set(id, d) { const a = all(); if (d === null) delete a[id]; else a[id] = d; write('polls.json', a); }

function build(p) {
  const total = Object.values(p.votes || {}).reduce((s, a) => s + a.length, 0);
  const lines = p.options.map((o, i) => {
    const n = (p.votes[i] || []).length;
    const pct = total ? Math.round((n / total) * 100) : 0;
    const bar = '█'.repeat(Math.round(pct / 10)) + '░'.repeat(10 - Math.round(pct / 10));
    return `${EMOJIS[i]} **${o}**\n> ${bar} · **${n}** vote(s) · **${pct}%**`;
  }).join('\n\n');
  return emb(p.closed ? `📊 Sondage fermé` : `📊 Sondage`, p.closed ? C.dark : C.primary)
    .setDescription(`### ${p.question}\n\n${lines}`)
    .addFields(
      { name: '👥 Votes total', value: `**${total}**`, inline: true },
      { name: '📌 Statut', value: p.closed ? '🔒 Fermé' : '🟢 Ouvert', inline: true },
    )
    .setFooter({ text: p.closed ? 'ManageX Polls · terminé' : 'ManageX Polls · vote avec les boutons' });
}
function btns(mid, p) {
  if (p.closed) return [];
  const rows = [];
  let row = new ActionRowBuilder();
  p.options.forEach((o, i) => {
    if (i > 0 && i % 5 === 0) { rows.push(row); row = new ActionRowBuilder(); }
    row.addComponents(new ButtonBuilder().setCustomId(`mx_poll_v_${mid}_${i}`).setLabel(o.slice(0, 80)).setEmoji(EMOJIS[i]).setStyle(ButtonStyle.Primary));
  });
  rows.push(row);
  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`mx_poll_c_${mid}`).setLabel('Fermer').setStyle(ButtonStyle.Danger)
  ));
  return rows.slice(0, 5);
}

const command = {
  data: new SlashCommandBuilder()
    .setName('pollsconfig')
    .setDescription('ManageX — sondages')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(i) {
    if (!isAdmin(i.member)) return i.reply({ content: '❌', ...EPH });
    await i.reply({
      embeds: [emb('📊 Polls Config', C.primary).setDescription('Crée un sondage avec boutons et barres de %.')],
      components: [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('mx_poll_create').setLabel('Créer un sondage').setStyle(ButtonStyle.Success)
      )],
      ...EPH,
    });
  },
};

async function handle(i) {
  const id = i.customId || '';
  if (!id.startsWith('mx_poll_')) return false;
  if (id === 'mx_poll_create') {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    const modal = new ModalBuilder().setCustomId('mx_modal_poll').setTitle('Sondage');
    modal.addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('q').setLabel('Question').setStyle(TextInputStyle.Short).setRequired(true)),
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('opts').setLabel('Options (1 par ligne, max 10)').setStyle(TextInputStyle.Paragraph).setRequired(true)),
    );
    await i.showModal(modal);
    return true;
  }
  const vote = id.match(/^mx_poll_v_(.+)_(\d+)$/);
  if (vote) {
    const p = get(vote[1]);
    if (!p || p.closed) { await i.reply({ content: 'Fermé.', ...EPH }); return true; }
    const idx = +vote[2];
    const uid = i.user.id;
    for (const k of Object.keys(p.votes)) p.votes[k] = (p.votes[k] || []).filter((u) => u !== uid);
    if (!p.votes[idx]) p.votes[idx] = [];
    p.votes[idx].push(uid);
    set(vote[1], p);
    await i.update({ embeds: [build(p)], components: btns(vote[1], p) });
    return true;
  }
  const close = id.match(/^mx_poll_c_(.+)$/);
  if (close) {
    const p = get(close[1]);
    if (!p) { await i.reply({ content: '❌', ...EPH }); return true; }
    if (i.user.id !== p.hostId && !isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    p.closed = true; set(close[1], p);
    await i.update({ embeds: [build(p)], components: [] });
    return true;
  }
  return false;
}

async function handleModal(i) {
  if (i.customId !== 'mx_modal_poll') return false;
  if (!isAdmin(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
  const opts = i.fields.getTextInputValue('opts').split('\n').map((s) => s.trim()).filter(Boolean).slice(0, 10);
  if (opts.length < 2) { await i.reply({ content: 'Min 2 options.', ...EPH }); return true; }
  await i.deferReply({ ...EPH });
  const votes = {}; opts.forEach((_, n) => { votes[n] = []; });
  const draft = {
    question: i.fields.getTextInputValue('q'), options: opts, votes,
    hostId: i.user.id, guildId: i.guild.id, closed: false,
  };
  const msg = await i.channel.send({ embeds: [build(draft)], components: btns('tmp', draft) });
  draft.messageId = msg.id;
  set(msg.id, draft);
  await msg.edit({ components: btns(msg.id, draft) });
  await i.editReply({ content: `✅ ${msg.url}` });
  return true;
}

module.exports = { command, handle, handleModal };
