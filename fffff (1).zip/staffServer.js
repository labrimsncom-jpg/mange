/**
 * /staffconfig — staff SERVEUR
 * Service (rôles en/hors service) · Absences (rôle) · Registre ban
 */
const {
  SlashCommandBuilder, PermissionFlagsBits, MessageFlags,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  RoleSelectMenuBuilder, UserSelectMenuBuilder,
  ChannelSelectMenuBuilder, ChannelType,
  ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder,
} = require('discord.js');
const { getGuild, setGuild, bag, setBag } = require('./storage.js');
const { isAdmin, isServerStaff } = require('./perms.js');
const { emb, C, configCard, ch, role, DIV } = require('./design.js');
const { openBtn } = require('./pickers.js');
const { E, CFG } = require('./emojis.js');

const EPH = { flags: MessageFlags.Ephemeral };

function fmt(ms) {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 0) return `${h}h ${String(m).padStart(2, '0')}min`;
  return `${m}min`;
}

function fmtTotal(ms) {
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  return `${h}h ${m}min`;
}

// ─── SERVICE EMBEDS ───────────────────────────────────────────
function serviceEmbed(guild) {
  const map = bag('services.json', guild.id) || {};
  const on = Object.entries(map).filter(([, v]) => v?.startedAt);
  const cfg = getGuild(guild.id);

  let body = [
    '### ⚡ Centre de prise de service',
    '',
    `**En service actuellement · ${on.length}**`,
    DIV,
  ];

  if (on.length) {
    for (const [uid, v] of on) {
      const start = Math.floor(v.startedAt / 1000);
      body.push(`🟢 <@${uid}>`);
      body.push(`> Depuis <t:${start}:f> · <t:${start}:R>`);
      body.push(`> Session en cours : **${fmt(Date.now() - v.startedAt)}**`);
      if (v.totalMs) body.push(`> Cumul total : **${fmtTotal(v.totalMs)}**`);
      body.push('');
    }
  } else {
    body.push('_Aucun staff en service pour le moment._');
    body.push('');
  }

  body.push(DIV);
  body.push(`🎭 Rôle **en service** : ${role(cfg.serviceRoleId)}`);
  body.push(`🎭 Rôle **hors service** : ${role(cfg.horsServiceRoleId)}`);

  return new EmbedBuilder()
    .setColor(C.service)
    .setTitle(`${E.verifie} Prise de service — ManageX`)
    .setDescription(body.join('\n'))
    .setThumbnail(guild.iconURL({ size: 128 }))
    .setFooter({ text: 'ManageX · Service · ↻ pour actualiser' })
    .setTimestamp();
}

function serviceBtns() {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('mx_svc_on').setLabel('Prendre service').setStyle(ButtonStyle.Success).setEmoji('🟢'),
    new ButtonBuilder().setCustomId('mx_svc_off').setLabel('Quitter service').setStyle(ButtonStyle.Danger).setEmoji('🔴'),
    new ButtonBuilder().setCustomId('mx_svc_force').setLabel('Forcer fin').setStyle(ButtonStyle.Secondary).setEmoji('⛔'),
    new ButtonBuilder().setCustomId('mx_svc_ref').setLabel('Actualiser').setStyle(ButtonStyle.Secondary).setEmoji('🔄'),
  )];
}

async function applyServiceRoles(member, onDuty) {
  if (!member) return;
  const cfg = getGuild(member.guild.id);
  try {
    if (onDuty) {
      if (cfg.serviceRoleId) await member.roles.add(cfg.serviceRoleId, 'ManageX service ON').catch(() => null);
      if (cfg.horsServiceRoleId) await member.roles.remove(cfg.horsServiceRoleId, 'ManageX service ON').catch(() => null);
    } else {
      if (cfg.serviceRoleId) await member.roles.remove(cfg.serviceRoleId, 'ManageX service OFF').catch(() => null);
      if (cfg.horsServiceRoleId) await member.roles.add(cfg.horsServiceRoleId, 'ManageX service OFF').catch(() => null);
    }
  } catch (e) {
    console.warn('[service roles]', e.message);
  }
}

// ─── ABSENCES ─────────────────────────────────────────────────
function absenceEmbed(guild) {
  const list = bag('absences.json', guild.id) || [];
  const cfg = getGuild(guild.id);
  const active = list.filter((a) => !a.ended);

  let body = [
    '### 🏖️ Planning des absences staff',
    '',
    `**Absences actives · ${active.length}**`,
    DIV,
  ];

  if (active.length) {
    for (const a of active.slice(0, 20)) {
      body.push(`📌 <@${a.userId}>`);
      body.push(`> **Du** ${a.from} **au** ${a.to}`);
      body.push(`> Motif : _${(a.reason || '—').slice(0, 120)}_`);
      if (a.at) body.push(`> Déclarée <t:${Math.floor(a.at / 1000)}:R>`);
      body.push('');
    }
  } else {
    body.push('_Aucune absence en cours._');
    body.push('');
  }

  body.push(DIV);
  body.push(`🎭 Rôle **absence** : ${role(cfg.absenceRoleId)}`);
  body.push('_Ce rôle est donné à la déclaration et retiré à la fin._');

  return new EmbedBuilder()
    .setColor(C.absence)
    .setTitle('🏖️ Absences staff — ManageX')
    .setDescription(body.join('\n'))
    .setThumbnail(guild.iconURL({ size: 128 }))
    .setFooter({ text: 'ManageX · Absences · déclarer ou terminer' })
    .setTimestamp();
}

function absenceBtns() {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('mx_abs_add').setLabel('Déclarer une absence').setStyle(ButtonStyle.Primary).setEmoji('📌'),
    new ButtonBuilder().setCustomId('mx_abs_end').setLabel('Terminer la mienne').setStyle(ButtonStyle.Success).setEmoji('✅'),
    new ButtonBuilder().setCustomId('mx_abs_ref').setLabel('Actualiser').setStyle(ButtonStyle.Secondary).setEmoji('🔄'),
  )];
}

async function applyAbsenceRole(member, absent) {
  if (!member) return;
  const cfg = getGuild(member.guild.id);
  if (!cfg.absenceRoleId) return;
  try {
    if (absent) await member.roles.add(cfg.absenceRoleId, 'ManageX absence ON').catch(() => null);
    else await member.roles.remove(cfg.absenceRoleId, 'ManageX absence OFF').catch(() => null);
  } catch {}
}

// ─── REGISTRE BAN ─────────────────────────────────────────────
function banregEmbed(guild) {
  const list = bag('banreg.json', guild.id) || [];
  const cfg = getGuild(guild.id);
  const salon = cfg.banregChannelId ? `<#${cfg.banregChannelId}>` : '`non défini`';
  const body = [
    '### 🚫 Registre ban',
    '',
    'Utilise **Ajouter un ban** pour enregistrer un bannissement.',
    'Chaque entrée est **publiée uniquement** dans le salon registre (pas sur ce panel).',
    '',
    `📥 Salon registre : ${salon}`,
    `📊 Total enregistrés : **${list.length}**`,
    '',
    '_La liste détaillée n’apparaît pas ici._',
  ].join('\n');

  return new EmbedBuilder()
    .setColor(C.ban)
    .setTitle(`${E.alerte} Registre ban — ManageX`)
    .setDescription(body)
    .setThumbnail(guild.iconURL({ size: 128 }))
    .setFooter({ text: 'ManageX · Panel registre (liste = salon uniquement)' })
    .setTimestamp();
}

function banregBtns() {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('mx_ban_add').setLabel('Ajouter un ban').setStyle(ButtonStyle.Danger).setEmoji('🚫'),
    new ButtonBuilder().setCustomId('mx_ban_list').setLabel('Liste complète').setStyle(ButtonStyle.Secondary).setEmoji('📋'),
    new ButtonBuilder().setCustomId('mx_ban_ref').setLabel('Actualiser').setStyle(ButtonStyle.Secondary).setEmoji('🔄'),
  )];
}

// ─── CONFIG PANEL ─────────────────────────────────────────────
function cfgPanel(gid) {
  const c = getGuild(gid);
  return configCard(`${CFG.staff} Staff Config (serveur)`,
    [
      '### Gestion de l’équipe staff du serveur',
      '',
      '• **Service** — rôle en service / hors service automatique',
      '• **Absences** — rôle absence + planning public',
      '• **Registre ban** — historique avec lien Roblox',
      '',
      '_Ces outils sont réservés aux rôles staff configurés (ou Admin/Modo)._',
    ].join('\n'),
    [
      { name: '👥 Rôles staff serveur', value: (c.serverStaffRoleIds || []).map((id) => `<@&${id}>`).join(' ') || '`Admin / Modo par défaut`' },
      { name: '🟢 Rôle EN service', value: role(c.serviceRoleId), inline: true },
      { name: '🔴 Rôle HORS service', value: role(c.horsServiceRoleId), inline: true },
      { name: '⛔ Rôle FORCE fin service', value: role(c.forceServiceRoleId), inline: true },
      { name: '⏱️ Limite service (h)', value: c.serviceMaxHours ? `**${c.serviceMaxHours}h**` : '`désactivée`', inline: true },
      { name: '⚠️ Rôle WARN dépassement', value: role(c.serviceWarnRoleId), inline: true },
      { name: '🛑 Auto fin si dépassement', value: c.serviceAutoEnd !== false ? '`oui`' : '`non`', inline: true },
      { name: '🏖️ Rôle ABSENCE', value: role(c.absenceRoleId), inline: true },
      { name: '📜 Salon registre ban', value: ch(c.banregChannelId), inline: true },
    ],
    C.cyan
  );
}

const command = {
  data: new SlashCommandBuilder()
    .setName('staffconfig')
    .setDescription('ManageX — service, absences, registre ban (staff serveur)')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(i) {
    if (!isAdmin(i.member)) return i.reply({ content: '❌ Administrateur requis.', ...EPH });
    await i.reply({
      embeds: [cfgPanel(i.guild.id)],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('mx_stf_panel_svc').setLabel('Panel Service').setStyle(ButtonStyle.Success).setEmoji('⚡'),
          new ButtonBuilder().setCustomId('mx_stf_panel_abs').setLabel('Panel Absences').setStyle(ButtonStyle.Primary).setEmoji('🏖️'),
          new ButtonBuilder().setCustomId('mx_stf_panel_ban').setLabel('Panel Registre ban').setStyle(ButtonStyle.Danger).setEmoji('🚫'),
        ),
        new ActionRowBuilder().addComponents(
          openBtn('role', 'stf_roles', '👥 Rôles staff serveur')
        ),
        new ActionRowBuilder().addComponents(
          openBtn('role', 'stf_on', '🟢 Rôle EN service')
        ),
        new ActionRowBuilder().addComponents(
          openBtn('role', 'stf_off', '🔴 Rôle HORS service')
        ),
        new ActionRowBuilder().addComponents(
          openBtn('role', 'stf_abs', '🏖️ Rôle absence')
        ),
      ],
      ...EPH,
    });
    await i.followUp({
      content: '**⛔ Rôle autorisé à forcer la fin de service** (bouton Forcer fin)',
      components: [
        new ActionRowBuilder().addComponents(
          openBtn('role', 'stf_force', '⛔ Force fin service')
        ),
      ],
      ...EPH,
    });
    await i.followUp({
      content: '**⚠️ Rôle WARN si dépassement du temps de service** + limite',
      components: [
        new ActionRowBuilder().addComponents(
          openBtn('role', 'stf_warn', '⚠️ Warn service')
        ),
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('mx_stf_max_hours').setLabel('⏱️ Définir limite (heures)').setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId('mx_stf_auto_end').setLabel('Auto-fin ON/OFF').setStyle(ButtonStyle.Secondary),
        ),
      ],
      ...EPH,
    });

    await i.followUp({
      content: '**📜 Salon registre ban** (optionnel — les ajouts y sont aussi postés)',
      components: [
        new ActionRowBuilder().addComponents(
          openBtn('ch', 'stf_banreg', '📜 Salon registre ban')
        ),
      ],
      ...EPH,
    });
  },
};

async function refreshSvc(guild) {
  const c = getGuild(guild.id);
  if (!c.serviceChannelId || !c.serviceMessageId) return;
  const chn = await guild.channels.fetch(c.serviceChannelId).catch(() => null);
  const msg = chn && await chn.messages.fetch(c.serviceMessageId).catch(() => null);
  if (msg) await msg.edit({ embeds: [serviceEmbed(guild)], components: serviceBtns() }).catch(() => null);
}
async function refreshAbs(guild) {
  const c = getGuild(guild.id);
  if (!c.absenceChannelId || !c.absenceMessageId) return;
  const chn = await guild.channels.fetch(c.absenceChannelId).catch(() => null);
  const msg = chn && await chn.messages.fetch(c.absenceMessageId).catch(() => null);
  if (msg) await msg.edit({ embeds: [absenceEmbed(guild)], components: absenceBtns() }).catch(() => null);
}
async function refreshBan(guild) {
  const c = getGuild(guild.id);
  if (!c.banregChannelId || !c.banregMessageId) return;
  const chn = await guild.channels.fetch(c.banregChannelId).catch(() => null);
  const msg = chn && await chn.messages.fetch(c.banregMessageId).catch(() => null);
  if (msg) await msg.edit({ embeds: [banregEmbed(guild)], components: banregBtns() }).catch(() => null);
}

async function handle(i) {
  const id = i.customId || '';
  if (!id.startsWith('mx_stf_') && !id.startsWith('mx_svc_') && !id.startsWith('mx_abs_') && !id.startsWith('mx_ban_')) return false;

  const gid = i.guild.id;
  const uid = i.user.id;
  const c = getGuild(gid);

  // ── Config admin ──
  if (id.startsWith('mx_stf_')) {
    if (!isAdmin(i.member)) { await i.reply({ content: '❌ Admin.', ...EPH }); return true; }

    if (id === 'mx_stf_roles') {
      setGuild(gid, { serverStaffRoleIds: i.values || [] });
      await i.update({ embeds: [cfgPanel(gid)] });
      return true;
    }
    if (id === 'mx_stf_role_on') {
      setGuild(gid, { serviceRoleId: i.values[0] || null });
      await i.reply({ content: i.values[0] ? `✅ Rôle **en service** : <@&${i.values[0]}>` : '✅ Rôle en service retiré.', ...EPH });
      return true;
    }
    if (id === 'mx_stf_warn_role') {
      setGuild(gid, { serviceWarnRoleId: i.values[0] || null });
      await i.reply({ content: i.values[0] ? `✅ Rôle **warn service** : <@&${i.values[0]}>` : '✅ Rôle warn retiré.', ...EPH });
      return true;
    }
    if (id === 'mx_stf_auto_end') {
      const cur = getGuild(gid).serviceAutoEnd !== false;
      setGuild(gid, { serviceAutoEnd: !cur });
      await i.reply({ content: `✅ Auto-fin de service : **${!cur ? 'ON' : 'OFF'}**`, ...EPH });
      return true;
    }
    if (id === 'mx_stf_max_hours') {
      const modal = new ModalBuilder().setCustomId('mx_modal_svc_max').setTitle('Limite temps de service');
      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('hours').setLabel('Heures max (0 = désactivé)').setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder('ex: 4')
        ),
      );
      await i.showModal(modal);
      return true;
    }
    if (id === 'mx_stf_force_role') {
      setGuild(gid, { forceServiceRoleId: i.values[0] || null });
      await i.reply({ content: i.values[0] ? `✅ Rôle **force fin service** : <@&${i.values[0]}>` : '✅ Rôle force retiré.', ...EPH });
      return true;
    }
    if (id === 'mx_stf_role_off') {
      setGuild(gid, { horsServiceRoleId: i.values[0] || null });
      await i.reply({ content: i.values[0] ? `✅ Rôle **hors service** : <@&${i.values[0]}>` : '✅ Rôle hors service retiré.', ...EPH });
      return true;
    }
    if (id === 'mx_stf_role_abs') {
      setGuild(gid, { absenceRoleId: i.values[0] || null });
      await i.reply({ content: i.values[0] ? `✅ Rôle **absence** : <@&${i.values[0]}>` : '✅ Rôle absence retiré.', ...EPH });
      return true;
    }
    if (id === 'mx_stf_banreg_ch') {
      setGuild(gid, { banregChannelId: i.values[0] || null });
      await i.reply({ content: i.values[0] ? `✅ Salon registre : <#${i.values[0]}>` : '✅ Salon retiré.', ...EPH });
      return true;
    }
    if (id === 'mx_stf_panel_svc') {
      await i.deferReply({ ...EPH });
      const msg = await i.channel.send({ embeds: [serviceEmbed(i.guild)], components: serviceBtns() });
      setGuild(gid, { serviceChannelId: i.channel.id, serviceMessageId: msg.id });
      await i.editReply({ content: `✅ Panel service → ${msg.url}` });
      return true;
    }
    if (id === 'mx_stf_panel_abs') {
      await i.deferReply({ ...EPH });
      const msg = await i.channel.send({ embeds: [absenceEmbed(i.guild)], components: absenceBtns() });
      setGuild(gid, { absenceChannelId: i.channel.id, absenceMessageId: msg.id });
      await i.editReply({ content: `✅ Panel absences → ${msg.url}` });
      return true;
    }
    if (id === 'mx_stf_panel_ban') {
      await i.deferReply({ ...EPH });
      const msg = await i.channel.send({ embeds: [banregEmbed(i.guild)], components: banregBtns() });
      setGuild(gid, { banregChannelId: i.channel.id, banregMessageId: msg.id });
      await i.editReply({ content: `✅ Panel registre ban → ${msg.url}` });
      return true;
    }
  }

  // ── Staff actions ──
  if (!isServerStaff(i.member)) {
    await i.reply({ content: '❌ Réservé au **staff serveur**.', ...EPH });
    return true;
  }

  // Service ON
  if (id === 'mx_svc_on') {
    const map = { ...(bag('services.json', gid) || {}) };
    if (map[uid]?.startedAt) {
      await i.reply({ content: 'Tu es **déjà en service**.', ...EPH });
      return true;
    }
    map[uid] = { startedAt: Date.now(), totalMs: map[uid]?.totalMs || 0 };
    setBag('services.json', gid, map);
    await applyServiceRoles(i.member, true);
    await i.reply({
      embeds: [emb('🟢 Service démarré', C.success)
        .setDescription(`${i.user} est maintenant **en service**.\n<t:${Math.floor(Date.now() / 1000)}:f>`)],
      ...EPH,
    });
    await refreshSvc(i.guild);
    return true;
  }

  // Service OFF
  if (id === 'mx_svc_off') {
    const map = { ...(bag('services.json', gid) || {}) };
    if (!map[uid]?.startedAt) {
      await i.reply({ content: 'Tu n’es **pas** en service.', ...EPH });
      return true;
    }
    const el = Date.now() - map[uid].startedAt;
    map[uid] = { startedAt: null, totalMs: (map[uid].totalMs || 0) + el };
    setBag('services.json', gid, map);
    await applyServiceRoles(i.member, false);
    await i.reply({
      embeds: [emb('🔴 Service terminé', C.danger)
        .setDescription(`Session : **${fmt(el)}**\nCumul : **${fmtTotal(map[uid].totalMs)}**`)],
      ...EPH,
    });
    await refreshSvc(i.guild);
    return true;
  }

  if (id === 'mx_svc_ref') {
    await i.update({ embeds: [serviceEmbed(i.guild)], components: serviceBtns() });
    return true;
  }

  if (id === 'mx_svc_force') {
    const fr = c.forceServiceRoleId;
    const okForce = fr
      ? i.member.roles.cache.has(fr)
      : (isAdmin(i.member) || isServerStaff(i.member, c));
    if (!okForce) {
      await i.reply({
        content: fr
          ? `❌ Seul le rôle <@&${fr}> peut forcer la fin de service.`
          : '❌ Admin / staff serveur uniquement (configure un rôle « force » dans /staffconfig).',
        ...EPH,
      });
      return true;
    }
    const map = bag('services.json', gid) || {};
    const onDuty = Object.entries(map).filter(([, v]) => v?.startedAt);
    if (!onDuty.length) {
      await i.reply({ content: 'Personne en service.', ...EPH });
      return true;
    }
    await i.reply({
      content: '⛔ **Forcer la fin de service** — choisis le membre :',
      components: [new ActionRowBuilder().addComponents(
        new UserSelectMenuBuilder().setCustomId('mx_svc_force_user').setPlaceholder('Staff en service…').setMinValues(1).setMaxValues(1)
      )],
      ...EPH,
    });
    return true;
  }

  if (id === 'mx_svc_force_user') {
    const targetId = i.values[0];
    const map = { ...(bag('services.json', gid) || {}) };
    if (!map[targetId]?.startedAt) {
      await i.update({ content: `<@${targetId}> n’est pas en service.`, components: [] });
      return true;
    }
    const el = Date.now() - map[targetId].startedAt;
    map[targetId] = {
      startedAt: null,
      totalMs: (map[targetId].totalMs || 0) + el,
      forcedBy: uid,
      lastForcedAt: Date.now(),
    };
    setBag('services.json', gid, map);
    const targetMember = await i.guild.members.fetch(targetId).catch(() => null);
    await applyServiceRoles(targetMember, false);
    await i.update({
      content: `⛔ Fin forcée pour <@${targetId}> (**${fmt(el)}**) par ${i.user}.`,
      components: [],
    });
    await refreshSvc(i.guild);
    return true;
  }

  // Absence
  if (id === 'mx_abs_add') {
    const modal = new ModalBuilder().setCustomId('mx_modal_abs').setTitle('Déclarer une absence');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('from').setLabel('Début (AAAA-MM-JJ)').setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder('2026-10-12')
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('to').setLabel('Fin (AAAA-MM-JJ)').setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder('2026-10-15')
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('reason').setLabel('Motif').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(300)
      ),
    );
    await i.showModal(modal);
    return true;
  }

  if (id === 'mx_abs_end') {
    const list = (bag('absences.json', gid) || []).map((a) =>
      a.userId === uid && !a.ended ? { ...a, ended: true, endedAt: Date.now() } : a
    );
    // keep ended ones out of active view - filter active only in embed
    setBag('absences.json', gid, list);
    await applyAbsenceRole(i.member, false);
    await i.reply({
      embeds: [emb('✅ Absence terminée', C.success).setDescription('Ton rôle absence a été retiré (si configuré).')],
      ...EPH,
    });
    await refreshAbs(i.guild);
    return true;
  }

  if (id === 'mx_abs_ref') {
    await i.update({ embeds: [absenceEmbed(i.guild)], components: absenceBtns() });
    return true;
  }

  // Ban registry
  if (id === 'mx_ban_add') {
    const modal = new ModalBuilder().setCustomId('mx_modal_banreg').setTitle('Registre ban');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('pseudo').setLabel('Pseudo exact (Roblox / Discord)').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(50)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('reason').setLabel('Raison du ban').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(500)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('days').setLabel('Durée du ban (jours, 0 = permanent)').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(6).setPlaceholder('ex: 7 ou 0')
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('preuve').setLabel('Preuve / lien (optionnel)').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(200)
      ),
    );
    await i.showModal(modal);
    return true;
  }

  if (id === 'mx_ban_list') {
    const list = bag('banreg.json', gid) || [];
    const salon = c.banregChannelId ? `<#${c.banregChannelId}>` : 'salon non défini';
    const lines = list.slice(0, 15).map((b, n) => {
      const link = `https://www.roblox.com/search/users?keyword=${encodeURIComponent(b.pseudo)}`;
      const dur = b.durationLabel || (b.days === 0 || b.hours === 0 ? 'Permanent' : (b.days != null ? `${b.days}j` : (b.hours != null ? `${b.hours}h` : '—')));
      return `**${n + 1}.** [${b.pseudo}](${link}) · ${dur}\n> ${(b.reason || '').slice(0, 50)}`;
    }).join('\n') || '*Vide*';
    await i.reply({
      embeds: [
        emb('📋 Aperçu staff (privé)', C.ban)
          .setDescription(
            `Les bans publics sont dans ${salon}.\n\n` + lines
          )
          .setFooter({ text: `${list.length} entrée(s) · visible uniquement par toi` }),
      ],
      ...EPH,
    });
    return true;
  }

  if (id === 'mx_ban_ref') {
    await i.update({ embeds: [banregEmbed(i.guild)], components: banregBtns() });
    return true;
  }

  return false;
}

async function handleModal(i) {
  if (i.customId === 'mx_modal_abs') {
    if (!isServerStaff(i.member)) { await i.reply({ content: '❌', ...EPH }); return true; }
    const list = bag('absences.json', i.guild.id) || [];
    // end previous active absences of same user
    for (const a of list) {
      if (a.userId === i.user.id && !a.ended) a.ended = true;
    }
    list.unshift({
      id: Date.now().toString(36),
      userId: i.user.id,
      from: i.fields.getTextInputValue('from'),
      to: i.fields.getTextInputValue('to'),
      reason: i.fields.getTextInputValue('reason'),
      at: Date.now(),
      ended: false,
    });
    setBag('absences.json', i.guild.id, list.slice(0, 100));
    await applyAbsenceRole(i.member, true);
    await i.reply({
      embeds: [
        emb('📌 Absence déclarée', C.absence)
          .setDescription(
            `**${i.fields.getTextInputValue('from')}** → **${i.fields.getTextInputValue('to')}**\n` +
            `_${i.fields.getTextInputValue('reason')}_\n\nRôle absence attribué (si configuré).`
          ),
      ],
      ...EPH,
    });
    await refreshAbs(i.guild);
    return true;
  }

  if (i.customId === 'mx_modal_banreg') {
    if (!isServerStaff(i.member) && !isAdmin(i.member)) { await i.reply({ content: '❌ Staff uniquement.', ...EPH }); return true; }
    const pseudo = i.fields.getTextInputValue('pseudo').trim();
    const reason = i.fields.getTextInputValue('reason');
    let days = 0;
    try {
      days = Math.max(0, parseInt(i.fields.getTextInputValue('days') || i.fields.getTextInputValue('hours') || '0', 10) || 0);
    } catch {}
    const durationLabel = days === 0 ? 'Permanent' : `${days} jour(s)`;
    let preuve = '';
    try { preuve = i.fields.getTextInputValue('preuve') || ''; } catch {}
    const entry = {
      id: Date.now().toString(36),
      pseudo,
      reason,
      days,
      hours: days * 24, // compat
      durationLabel,
      preuve: preuve || null,
      byId: i.user.id,
      at: Date.now(),
    };
    const list = bag('banreg.json', i.guild.id) || [];
    list.unshift(entry);
    setBag('banreg.json', i.guild.id, list.slice(0, 500));

    const link = `https://www.roblox.com/search/users?keyword=${encodeURIComponent(pseudo)}`;
    const embed = new EmbedBuilder()
      .setColor(C.ban)
      .setAuthor({ name: 'Registre des bannissements', iconURL: i.guild.iconURL({ size: 64 }) || undefined })
      .setTitle('🚫 Nouveau ban enregistré')
      .setDescription(
        [
          `### [${pseudo}](${link})`,
          '',
          '> Clique sur le **pseudo** pour ouvrir la recherche Roblox.',
          '',
          `**⏱️ Durée :** ${durationLabel}`,
          '',
          '**📋 Raison**',
          reason.slice(0, 800),
          preuve ? `\n**🔗 Preuve / lien**\n${preuve}` : '',
        ].filter(Boolean).join('\n')
      )
      .addFields(
        { name: '🛡️ Enregistré par', value: `${i.user}\n\`${i.user.id}\``, inline: true },
        { name: '📅 Date', value: `<t:${Math.floor(Date.now() / 1000)}:f>\n<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
        { name: '🆔 Entrée', value: `\`${entry.id}\``, inline: true },
      )
      .setFooter({ text: 'ManageX · Registre ban · profil Roblox via le pseudo' })
      .setTimestamp();

    const c = getGuild(i.guild.id);
    // Post to registry channel if different from panel
    if (c.banregChannelId) {
      const chn = await i.guild.channels.fetch(c.banregChannelId).catch(() => null);
      if (chn?.send) await chn.send({ embeds: [embed] }).catch(() => null);
    }
    await refreshBan(i.guild);
    await i.reply({ embeds: [embed], ...EPH });
    return true;
  }

  return false;
}


/** Vérifie les services trop longs → warn rôle + fin auto */
async function checkServiceOvertime(client) {
  for (const [, guild] of client.guilds.cache) {
    try {
      const cfg = getGuild(guild.id);
      const maxH = Number(cfg.serviceMaxHours) || 0;
      if (maxH <= 0) continue;
      const maxMs = maxH * 3600000;
      const map = { ...(bag('services.json', guild.id) || {}) };
      let changed = false;
      for (const [userId, data] of Object.entries(map)) {
        if (!data?.startedAt) continue;
        if (data.overtimeEnded) continue;
        const elapsed = Date.now() - data.startedAt;
        if (elapsed < maxMs) continue;

        const member = await guild.members.fetch(userId).catch(() => null);

        // 1) Warn une seule fois
        if (!data.overtimeWarned) {
          data.overtimeWarned = true;
          data.overtimeWarnedAt = Date.now();
          changed = true;
          if (cfg.serviceWarnRoleId && member && !member.roles.cache.has(cfg.serviceWarnRoleId)) {
            await member.roles.add(cfg.serviceWarnRoleId, `ManageX service > ${maxH}h`).catch((e) =>
              console.warn('[svc warn role]', guild.name, e.message)
            );
          }
          try {
            const user = await client.users.fetch(userId);
            await user.send({
              embeds: [
                emb('⚠️ Temps de service dépassé', C.warn).setDescription(
                  [
                    `Serveur : **${guild.name}**`,
                    `Limite : **${maxH}h**`,
                    `Session : **${fmt(elapsed)}**`,
                    cfg.serviceWarnRoleId ? `Rôle warn attribué.` : null,
                    cfg.serviceAutoEnd !== false
                      ? 'Tu es **retiré du service** automatiquement.'
                      : 'Pense à **quitter le service**.',
                  ].filter(Boolean).join('\n')
                ),
              ],
            }).catch(() => null);
          } catch {}
          // log panel salon
          if (cfg.serviceChannelId) {
            const chn = await guild.channels.fetch(cfg.serviceChannelId).catch(() => null);
            if (chn?.send) {
              await chn.send({
                embeds: [
                  emb('⚠️ Dépassement service', C.warn).setDescription(
                    `<@${userId}> a dépassé **${maxH}h** (session **${fmt(elapsed)}**).`
                    + (cfg.serviceAutoEnd !== false ? '\n→ Fin de service automatique.' : '')
                  ),
                ],
              }).catch(() => null);
            }
          }
        }

        // 2) Fin auto
        if (cfg.serviceAutoEnd !== false) {
          const el = elapsed;
          map[userId] = {
            startedAt: null,
            totalMs: (data.totalMs || 0) + el,
            overtimeWarned: true,
            overtimeEnded: true,
            lastOvertimeAt: Date.now(),
          };
          changed = true;
          if (member) await applyServiceRoles(member, false);
        } else {
          map[userId] = { ...data, overtimeWarned: true };
        }
      }
      if (changed) {
        setBag('services.json', guild.id, map);
        await refreshSvc(guild);
      }
    } catch (e) {
      console.warn('[service overtime]', guild.id, e.message);
    }
  }
}

function startServiceWatcher(client) {
  const tick = () => checkServiceOvertime(client).catch((e) => console.warn('[svc watch]', e.message));
  setTimeout(tick, 15000);
  setInterval(tick, 60 * 1000);
}

module.exports = { command, handle, handleModal, startServiceWatcher, checkServiceOvertime };

